package hu.angolmagyar.fordito

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Hang-/videófájlok sorozatából SRT készítése előtérben futó szolgáltatásként: másik appra váltva,
 * zárolt képernyővel és az Activity bezárása után is tovább dolgozik (értesítés + wake lock).
 * A fájlok listáját és az állapotot a [SrtJob] tartja, a képernyő azt jeleníti meg.
 */
class SrtJobService : Service() {

    companion object {
        private const val CH_RUN = "srt_job_run"
        private const val CH_DONE = "srt_job_done"
        private const val NOTIF_RUN = 4402
        private const val NOTIF_DONE = 4403
        private const val ACTION_START = "hu.angolmagyar.fordito.SRT_START"
        private const val ACTION_CANCEL = "hu.angolmagyar.fordito.SRT_CANCEL"
        private const val EXTRA_MODE = "mode"
        private const val EXTRA_SRC = "src"
        private const val EXTRA_DIR = "dir"
        private const val EXTRA_TR = "tr"
        private const val EXTRA_DIARIZE = "diarize"
        private const val EXTRA_KIND = "kind"
        private const val EXTRA_LANG = "lang"
        const val KIND_SUBTITLE = "subtitle"
        const val KIND_TRANSCRIPT = "transcript"

        /** Ennyi ideje nincs haladás → figyelmeztetés (valószínűleg a rendszer lelassította a háttérfutást). */
        const val STALL_WARN_MS = 150_000L

        /**
         * Indítás: a [SrtJob.queue] várakozó fájljait dolgozza fel sorban.
         * Az állapot azonnal "fut"-ra vált, így a képernyő rögtön mutatja a lépéseket.
         */
        fun start(
            ctx: Context, mode: SrtExporter.Mode, src: String, dir: String,
            needTranslate: Boolean, diarize: Boolean, kind: String, langTag: String
        ) {
            if (SrtJob.batchRunning) return
            val waiting = SrtJob.queue.filter { it.state == SrtJob.Q_WAIT }
            if (waiting.isEmpty()) return
            SrtJob.startBatch()
            SrtJob.reset(needTranslate)
            val i = Intent(ctx, SrtJobService::class.java)
                .setAction(ACTION_START)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra(EXTRA_MODE, mode.name)
                .putExtra(EXTRA_SRC, src)
                .putExtra(EXTRA_DIR, dir)
                .putExtra(EXTRA_TR, needTranslate)
                .putExtra(EXTRA_DIARIZE, diarize)
                .putExtra(EXTRA_KIND, kind)
                .putExtra(EXTRA_LANG, langTag)
            // a fájlokhoz tartozó olvasási jogot is átadjuk a szolgáltatásnak
            val clip = ClipData.newRawUri("files", waiting[0].uri)
            for (k in 1 until waiting.size) clip.addItem(ClipData.Item(waiting[k].uri))
            i.clipData = clip
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                SrtJob.begin(SrtJob.ST_PREP)
                SrtJob.fail("A háttérszolgáltatás nem indítható: ${e.message}")
                SrtJob.endBatch()
            }
        }

        fun cancel(ctx: Context) {
            try {
                ctx.startService(Intent(ctx, SrtJobService::class.java).setAction(ACTION_CANCEL))
            } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
        }

        fun langName(code: String): String = when (code) {
            "hu" -> "magyar"; "de" -> "német"; "fr" -> "francia"
            "es" -> "spanyol"; "it" -> "olasz"; "uk" -> "ukrán"
            else -> "angol"
        }
    }

    /** Egy kötegre (az összes fájlra) érvényes beállítások. */
    private class Opts(
        val mode: SrtExporter.Mode, val src: String, val dir: String, val needTranslate: Boolean,
        val diarize: Boolean, val kind: String, val langTag: String
    )

    private val cancelFlag = AtomicBoolean(false)
    /** A rendszer időkorlátja miatt állt le: a "pendingJob" és az ellenőrzőpont megmarad a folytatáshoz. */
    @Volatile private var timedOut = false
    private var chunker: ParallelChunker? = null
    private var recRef: FileRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var worker: Thread? = null
    private var lastNotifMs = 0L
    private var lastNotifStep = -2
    private val tickHandler = Handler(Looper.getMainLooper())
    private var tickN = 0
    private val notifTick = object : Runnable {
        override fun run() {
            if (!SrtJob.batchRunning) return
            pushRunNotif()
            // ~30 mp-enként állapotsor a diagnosztikai naplóba (zárolt képernyő alatt is fut: a szolgáltatás előtérben van)
            if (++tickN % 6 == 0) DiagLog.tick(this@SrtJobService)
            tickHandler.postDelayed(this, 5_000)
        }
    }

    /** A képernyő be-/kikapcsolását naplózzuk: így kiderül, hogy zároláskor leáll-e a feldolgozás. */
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> DiagLog.screenChanged(false)
                Intent.ACTION_SCREEN_ON -> DiagLog.screenChanged(true)
            }
        }
    }
    private var screenReg = false

    private val jobListener: () -> Unit = {
        if (SrtJob.batchRunning) {
            val now = System.currentTimeMillis()
            if (now - lastNotifMs >= 1000 || SrtJob.curStep != lastNotifStep) {
                lastNotifMs = now
                lastNotifStep = SrtJob.curStep
                pushRunNotif()
            }
        }
    }

    private fun pushRunNotif() {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_RUN, runNotif())
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannels()
        DiagLog.init(this)
        SrtJob.addListener(jobListener)
        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(screenReceiver, f)
            screenReg = true
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
    }

    override fun onDestroy() {
        if (screenReg) { try { unregisterReceiver(screenReceiver) } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) } }
        SrtJob.removeListener(jobListener)
        tickHandler.removeCallbacks(notifTick)
        releaseWake()
        super.onDestroy()
    }

    /** Android 15: az adatszinkron típusú előtér-szolgáltatásnak ~6 órás korlátja van. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        timedOut = true
        cancelFlag.set(true)
        chunker?.cancel()
        recRef?.abort()
        if (SrtJob.running) SrtJob.fail("A rendszer időkorlátja lejárt (kb. 6 óra). A kész darabok megvannak, a Fájl képernyőn folytathatod.")
        postResultNotif(
            "Időkorlát – a feldolgozás szünetel",
            "A rendszer kb. 6 óra után leállítja a háttérfutást. A kész darabok elmentve; koppints a folytatáshoz."
        )
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startAsForeground()
                if (worker?.isAlive == true) return START_NOT_STICKY
                val mode = try {
                    SrtExporter.Mode.valueOf(intent.getStringExtra(EXTRA_MODE) ?: "")
                } catch (_: Exception) {
                    SrtExporter.Mode.BOTH
                }
                val opts = Opts(
                    mode,
                    intent.getStringExtra(EXTRA_SRC) ?: "en",
                    intent.getStringExtra(EXTRA_DIR) ?: Prefs.DIR_NONE,
                    intent.getBooleanExtra(EXTRA_TR, false),
                    intent.getBooleanExtra(EXTRA_DIARIZE, false),
                    intent.getStringExtra(EXTRA_KIND) ?: KIND_SUBTITLE,
                    intent.getStringExtra(EXTRA_LANG) ?: (intent.getStringExtra(EXTRA_SRC) ?: "en")
                )
                runBatch(opts)
            }
            ACTION_CANCEL -> {
                cancelFlag.set(true)
                chunker?.cancel()
                recRef?.abort()
                if (worker?.isAlive != true) {
                    // nincs mit leállítani (pl. a rendszer újraindította a szolgáltatást)
                    if (SrtJob.running) SrtJob.stopped()
                    SrtJob.stopWaiting()
                    SrtJob.endBatch()
                    stopFg()
                }
            }
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ értesítések

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_RUN, "SRT készítés (fut)", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Folyamatjelző, amíg az átirat / felirat készül a háttérben"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "SRT készítés (eredmény)", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Hang és rezgés, ha elkészült vagy megszakadt a feliratkészítés"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250, 150, 400)
            }
        )
    }

    private fun openPi(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, FileSubtitleActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun cancelPi(): PendingIntent = PendingIntent.getService(
        this, 1,
        Intent(this, SrtJobService::class.java).setAction(ACTION_CANCEL),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun runNotif(): Notification {
        val now = System.currentTimeMillis()
        val pct = SrtJob.overall
        val step = SrtJob.label(SrtJob.curStep.coerceAtLeast(0))
        val files = if (SrtJob.fileTotal > 1) " · ${SrtJob.fileNo}/${SrtJob.fileTotal}. fájl" else ""
        val eta = if (SrtJob.etaAtMs > 0)
            "Várhatóan kész: ${SrtJob.fmtClock(SrtJob.etaAtMs)} körül (hátra kb. ${SrtJob.fmtDur(SrtJob.etaMs)})"
        else "Várható befejezés: az első darab után"
        val stalled = SrtJob.running && !SrtJob.cooling && now - SrtJob.lastProgressMs > STALL_WARN_MS
        val warn = if (stalled) "⚠ Nincs új haladás ${SrtJob.fmtDur(now - SrtJob.lastProgressMs)} ideje – ellenőrizd az akkumulátor-beállítást.\n" else ""
        val text = "$step · ${SrtJob.message}"
        return NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_subtitles)
            .setContentTitle("SRT készül… $pct%$files")
            .setContentText((if (stalled) "⚠ nincs haladás · " else "") + text.take(90))
            .setStyle(NotificationCompat.BigTextStyle().bigText("$warn$text\n$eta"))
            .setContentIntent(openPi())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(true)
            .setWhen(if (SrtJob.batchStartMs > 0) SrtJob.batchStartMs else now)
            .setUsesChronometer(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .addAction(0, "Megszakítás", cancelPi())
            .build()
    }

    private fun startAsForeground() {
        val n = runNotif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_RUN, n)
        }
        tickHandler.removeCallbacks(notifTick)
        tickHandler.postDelayed(notifTick, 5_000)
    }

    private fun stopFg() {
        tickHandler.removeCallbacks(notifTick)
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
        stopSelf()
    }

    private fun postResultNotif(title: String, text: String) {
        try {
            val n = NotificationCompat.Builder(this, CH_DONE)
                .setSmallIcon(R.drawable.ic_subtitles)
                .setContentTitle(title)
                .setContentText(text.take(100))
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(openPi())
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTIF_DONE, n)
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
    }

    private fun acquireWake() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AngolMagyar:SrtJob").also {
                it.setReferenceCounted(false)
                it.acquire(6 * 60 * 60 * 1000L) // max 6 óra
            }
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
        wakeLock = null
    }

    // ---------------------------------------------------------------- a feldolgozás

    private fun errText(e: Throwable): String {
        val parts = ArrayList<String>()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 4) {
            val m = t.message
            parts.add(if (m.isNullOrBlank()) t.javaClass.simpleName else "${t.javaClass.simpleName}: $m")
            t = t.cause
            n++
        }
        return parts.joinToString(" ← ")
    }

    /**
     * A bizonytalan felismerésű sorok újrafuttatása nagyobb nyalábbal; csak akkor cseréli a sort,
     * ha az új eredmény megbízhatósága érdemben jobb. A cserélt sorok fordítását újra elkészíti.
     */
    private fun secondPass(
        input: List<SrtExporter.Cue>, pcm: File, asr: Engines.Asr, lang: String, dir: String,
        needTranslate: Boolean, rec: FileRecognizer
    ): List<SrtExporter.Cue> {
        val flags = try { LineQuality.summarize(input) } catch (_: Exception) { emptyList() }
        val bad = input.indices.filter { input[it].lp < -0.9f || flags.getOrNull(it)?.contains("töredék") == true }
        if (bad.isEmpty()) return input
        // egymás melletti rossz sorok egy szakaszba (legfeljebb 25 mp)
        val groups = ArrayList<IntRange>()
        var gs = bad[0]; var ge = bad[0]
        for (i in bad.drop(1)) {
            if (i == ge + 1 && input[i].endMs - input[gs].startMs <= 25_000) ge = i
            else { groups.add(gs..ge); gs = i; ge = i }
        }
        groups.add(gs..ge)
        // kétmenetes mód: ha van nagyobb (large-v3) modell, a bizonytalan szakaszokat azzal futtatjuk újra
        val big = ModelManager.installedSpecs(this).firstOrNull { it.id == ModelManager.WH_LARGE.id && it.id != asr.whisper?.id }
        val maxSpans = 12
        val picked = groups.sortedBy { g -> input.subList(g.first, g.last + 1).sumOf { it.lp.toDouble() } }.take(maxSpans)
            .sortedBy { it.first }
        SrtJob.progress(99, "Bizonytalan szakaszok pontosítása (${picked.size} szakasz)…")
        DiagLog.log("MÁSODIK MENET: ${picked.size} szakasz")
        val spans = picked.map { g -> maxOf(0L, input[g.first].startMs - 500) to (input[g.last].endMs + 500) }
        val beam = (AsrPrefs.beam(this) + 4).coerceAtMost(10)
        DiagLog.log("MÁSODIK MENET modell: ${(big ?: asr.whisper!!).label}")
        val results = rec.refine(pcm, spans, big ?: asr.whisper!!, lang, beam) { d, t ->
            SrtJob.progress(99, "Bizonytalan szakaszok pontosítása: $d/$t")
        }
        val out = ArrayList(input)
        var replaced = 0
        for (k in picked.indices.reversed()) {
            val g = picked[k]
            val res = results.getOrNull(k)?.takeIf { it.isNotEmpty() } ?: continue
            val oldLp = input.subList(g.first, g.last + 1).map { it.lp.toDouble() }.average()
            val newLp = res.map { it.lp.toDouble() }.average()
            DiagLog.log("MÁSODIK MENET szakasz ${g.first + 1}–${g.last + 1}: régi lp=${"%.2f".format(oldLp)}, új lp=${"%.2f".format(newLp)}")
            if (newLp > oldLp + 0.05) {
                val spk = input[g.first].speaker
                for (i in g.last downTo g.first) out.removeAt(i)
                out.addAll(g.first, res.map { it.copy(speaker = spk) })
                replaced++
            }
        }
        DiagLog.log("MÁSODIK MENET: $replaced szakasz cserélve")
        if (replaced == 0) return input
        if (needTranslate && dir != Prefs.DIR_NONE) {
            val todo = out.indices.filter { out[it].target.isBlank() && out[it].source.isNotBlank() }
            if (todo.isNotEmpty()) return rec.retranslate(out, todo, dir, null) { _, _, _ -> }
        }
        return out
    }

    /** SRT összeállítása a beállítások szerint: olvasható darabolás / időzítés, színes beszélők. */
    private fun buildSrt(cues: List<SrtExporter.Cue>, mode: SrtExporter.Mode): String {
        return SrtBuild.build(this, cues, mode)
    }

    /** A teljes sor feldolgozása egymás után; egy fájl hibája nem állítja meg a többit. */
    private fun runBatch(o: Opts) {
        cancelFlag.set(false)
        timedOut = false
        acquireWake()
        Perf.load(this)
        worker = Thread {
            try {
                while (!cancelFlag.get()) {
                    val item = SrtJob.takeNext() ?: break
                    processOne(item, o)
                }
            } catch (_: Throwable) {
            } finally {
                if (cancelFlag.get()) SrtJob.stopWaiting()
                SrtJob.endBatch()
                chunker = null
                recRef = null
                batchNotif()
                releaseWake()
                stopFg()
            }
        }.also { it.start() }
    }

    private fun batchNotif() {
        val items = SrtJob.queue.filter { it.state != SrtJob.Q_WAIT }
        if (items.isEmpty()) return
        val ok = items.count { it.state == SrtJob.Q_DONE }
        val err = items.count { it.state == SrtJob.Q_ERR }
        val stop = items.count { it.state == SrtJob.Q_STOP }
        if (items.size == 1) {
            val it = items[0]
            when (it.state) {
                SrtJob.Q_DONE -> postResultNotif(
                    "SRT kész – ${it.cueCount} feliratblokk",
                    if (it.saved) it.detail else "Koppints a megnyitáshoz, ott mentheted a telefonra."
                )
                SrtJob.Q_ERR -> postResultNotif("SRT készítés hiba", it.detail)
                else -> postResultNotif("SRT készítés megszakítva", it.detail.ifBlank { "A folyamat leállt." })
            }
        } else {
            val parts = ArrayList<String>()
            parts.add("$ok kész")
            if (err > 0) parts.add("$err hibás")
            if (stop > 0) parts.add("$stop megszakítva")
            postResultNotif("SRT készítés vége – ${items.size} fájl", parts.joinToString(", "))
        }
    }

    private fun processOne(item: SrtJob.QItem, o: Opts) {
        val uri = item.uri
        val prefs = Prefs(this)
        val sourceLang = o.src
        val needTranslate = o.needTranslate
        val dir = o.dir
        val mode = o.mode
        val useDiarization = o.diarize
        val kind = o.kind
        val langTag = o.langTag
        // Az értékeket most olvassuk ki: ha közben a képernyő bezárul, a beállítások változhatnak.
        val meeting = prefs.meetingMode
        val safeMode = prefs.meetingSafeMode
        val chunkMin = prefs.meetingChunkMinutes
        val preferOnnx = prefs.preferOnnx

        SrtJob.reset(needTranslate)
        // ha az app közben leáll, a következő indításkor felajánljuk a folytatást (az ellenőrzőpont megvan)
        try {
            prefs.raw().edit().putString(
                "pendingJob", org.json.JSONObject().put("uri", item.uri.toString()).put("name", item.name).toString()
            ).apply()
        } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
        DiagLog.log("FÁJL INDUL: ${item.name} · ${Perf.describe()} · ${DiagLog.powerState(this)}")

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val base = item.name.takeIf { it.isNotBlank() }?.let { OutputWriter.baseName(it) } ?: "felirat_$stamp"
        val srtFileName = srtNameFor(kind, base, langTag, false)
        val hist = getSharedPreferences("srt_hist", MODE_PRIVATE)
        var partialSupplier: (() -> List<SrtExporter.Cue>)? = null
        var histKey = ""
        var audioMs = 1L

        /** Elmenti az eddigi (részleges) eredményt, ha van; a mentés helyét adja vissza. */
        fun salvage(): String? {
            val cues = try { partialSupplier?.invoke().orEmpty() } catch (_: Exception) { emptyList() }
            if (cues.isEmpty()) return null
            return try {
                saveOutputs(kind, uri, base, langTag, buildSrt(cues, mode), cues, true)
            } catch (_: Exception) {
                null
            }
        }

        var fr: FileRecognizer? = null
        var pcmFile: File? = null
        try {
            // ------------------------------------------------------------ előkészítés
            SrtJob.begin(SrtJob.ST_PREP, "Felismerő kiválasztása…")
            val asr = Engines.asrFor(this, prefs, sourceLang)
            SrtJob.engineLabel = asr.label
            val tgtCode = if (needTranslate) dir.substringAfter("_", "") else ""
            SrtJob.langLabel = langName(sourceLang) +
                (if (tgtCode.isNotBlank()) " → ${langName(tgtCode)} fordítás" else "")
            android.util.Log.i("SrtJob", "Felismerő: ${asr.label} · nyelv: $sourceLang · fájl: ${item.name}")
            when (asr.kind) {
                Engines.K_WHISPER -> if (asr.whisper == null || !ModelManager.isInstalled(this, asr.whisper)) {
                    throw IllegalStateException(
                        if (!WhisperNative.available())
                            "A Whisper nem használható ezen a telefonon: ${WhisperNative.error()}"
                        else "Nincs letöltött Whisper modell. Nyisd meg a Modellek képernyőt, és töltsd le (magyarhoz ajánlott)."
                    )
                }
                Engines.K_VOSK -> if (asr.vosk == null || !ModelManager.isInstalled(this, asr.vosk)) {
                    throw IllegalStateException(
                        "Nincs telepítve a ${asr.vosk?.label ?: "Vosk"} modell. Töltsd le a Modellek képernyőn."
                    )
                }
                else -> {
                    // A rendszer-felismerő csak magyarhoz való; más nyelvnél nem váltunk rá csendben.
                    if (sourceLang != "hu") {
                        throw IllegalStateException(
                            "Nincs ${langName(sourceLang)} nyelvű felismerő modell (Whisper vagy Vosk). " +
                                "Töltsd le a Modellek képernyőn – a rendszer-felismerő csak magyar beszédhez használható."
                        )
                    }
                    if (!SystemAsrSupport.audioSourceSupported()) {
                        throw IllegalStateException(
                            "A magyar felismeréshez Android 13 vagy újabb kell – vagy töltsd le a Whisper modellt a Modellek képernyőn."
                        )
                    }
                    if (!SystemAsrSupport.onDeviceAvailable(this) &&
                        !(prefs.allowOnlineAsr && SystemAsrSupport.anyAvailable(this))
                    ) {
                        throw IllegalStateException(
                            "Nincs magyar felismerő. Töltsd le a Whisper modellt a Modellek képernyőn (offline, pontos)."
                        )
                    }
                }
            }
            val recognizer = FileRecognizer(this, prefs, cancelFlag)
            fr = recognizer
            recRef = recognizer
            recognizer.onStatus = { m -> SrtJob.progress(45, m) }
            recognizer.onNote = { m -> DiagLog.log("FORDÍTÁS: $m"); SrtJob.translateNote = m; SrtJob.changed(false) }
            SrtJob.progress(40, "Felismerő modell betöltése: ${asr.label}…")
            recognizer.prepare(asr, needTranslate, dir)
            if (cancelFlag.get()) throw InterruptedException("Megszakítva")
            SrtJob.finish(asr.label)

            // -------------------------------------------------------- hang kinyerése
            SrtJob.begin(SrtJob.ST_EXTRACT, "Hang dekódolása")
            val pcmTmp = File(cacheDir, "pcm_${System.currentTimeMillis()}.raw")
            pcmFile = pcmTmp
            AudioHelper.decodeUriToPcm16kMono(this, uri, pcmTmp, { cancelFlag.get() }) { p ->
                SrtJob.progress(p, "Hang dekódolása")
            }
            if (cancelFlag.get()) throw InterruptedException("Megszakítva")
            if (!pcmTmp.exists() || pcmTmp.length() < 1000) {
                throw IllegalStateException("Nem sikerült dekódolni a hangot. Próbálj WAV/MP3 fájlt.")
            }
            SrtJob.finish()

            SrtJob.begin(SrtJob.ST_PCM)
            // Ne töltsük be az egész PCM-et a memóriába – hosszú filmeknél OutOfMemoryError.
            val totalSamples = (pcmTmp.length() / 2).toInt().coerceAtLeast(0)
            val durationMin = totalSamples / 16000.0 / 60.0
            audioMs = (totalSamples / 16L).coerceAtLeast(1L)
            SrtJob.waveTotalMs = audioMs
            Thread {
                try {
                    val env = Envelope.compute(totalSamples, 240) { st, en -> ParallelChunker.readPcmRange(pcmTmp, st, en) }
                    SrtJob.waveEnv = env
                    SrtJob.changed(false)
                } catch (_: Throwable) {
                }
            }.start()
            SrtJob.finish(String.format(Locale.US, "%s hang", SrtJob.fmtDur(audioMs)))

            // ------------------------------------------------ felismerés (chunkokban)
            val sequential = asr.kind != Engines.K_VOSK
            val chunkMs = when {
                meeting -> chunkMin * 60 * 1000
                asr.kind == Engines.K_VOSK -> 4 * 60 * 1000
                else -> 3 * 60 * 1000
            }
            val overlapMs = 8_000
            histKey = "${asr.key}|$sourceLang|${if (needTranslate) "t" else "n"}"
            val ratio = hist.getFloat("$histKey|p${Perf.level}", 0f).takeIf { it > 0f } ?: hist.getFloat(histKey, 0f)
            SrtJob.histEstMs = if (ratio > 0f) (ratio * audioMs).toLong() else 0L
            SrtJob.histMsPerWindow = hist.getLong("msPerWindow", 0L)
            val recogStart = System.currentTimeMillis()
            SrtJob.begin(
                SrtJob.ST_RECOG,
                "${asr.label} · ${langName(sourceLang)} beszéd · ${SrtJob.fmtDur(audioMs)} hang"
            )
            if (SrtJob.histEstMs > 0) {
                // kezdeti becslés a korábbi futásokból; utána a mért tempó veszi át (másodpercenként frissül)
                SrtJob.setEta(recogStart + SrtJob.histEstMs, "korábbi futások alapján")
            }

            // beszélők: hosszú felvételnél mindig chunkonként (egész fájl memóriába töltése tilos)
            val perChunkDiar = useDiarization // memóriatakarékos: mindig darabonként
            var globalSegs: List<SpeakerDiarizer.Segment> = emptyList()

            val chunk = ParallelChunker(this, meeting && safeMode)
            chunker = chunk
            partialSupplier = { chunk.merged() }
            var doneAudio = 0L
            val partialFile = File(TranscriptStore.dir(this), "felirat_${stamp}_reszleges.srt")

            // folytatás: a korábban kész darabok (ugyanaz a fájl és beállítás) nem számolódnak újra
            var ckpt: Checkpoint? = null
            var savedChunks: Map<Int, List<SrtExporter.Cue>> = emptyMap()
            var histBasisKey = histKey
            var histBasisMs = audioMs

            val events = object : ParallelChunker.Events {
                override fun onChunkStart(idx: Int, total: Int) {
                    if (SrtJob.chunkState.size != total) SrtJob.initChunks(total)
                    SrtJob.chunkStart(idx)
                }

                override fun onChunkDone(idx: Int, total: Int, cues: List<SrtExporter.Cue>, audioMs: Long) {
                    SrtJob.chunkFinish(idx, cues.size)
                    SrtJob.preview = (SrtJob.preview + cues.map { previewLine(it) }).takeLast(8)
                    SrtJob.previewCues = (SrtJob.previewCues + cues).takeLast(6)
                    doneAudio += audioMs
                    if (!savedChunks.containsKey(idx)) ckpt?.append(idx, cues)
                    // részeredmény mentése a belső tárba (megszakításnál / hibánál megmarad)
                    try {
                        partialFile.writeText(SrtExporter.build(chunk.merged(), mode), Charsets.UTF_8)
                    } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
                }

                override fun onWait(reason: String, cooling: Boolean) {
                    SrtJob.cooling = cooling
                    SrtJob.waitReason = reason
                    if (cooling) SrtJob.message = reason
                    SrtJob.changed()
                }
            }

            // Whisper: intelligens darabolás fájlból (ablakonként) – nincs teljes PCM a memóriában
            val useSmartChunks = asr.kind == Engines.K_WHISPER
            val speechRanges = if (useSmartChunks) {
                SrtJob.progress(0, "Intelligens darabolás (csendek kiszűrése)…")
                val vadModel = VadModel.ensure(this) { SrtJob.progress(0, it) }
                val vadReady = vadModel != null
                // ha a Whisper maga is kihagyja a darabon belüli csendet, nagy darabok kellenek (kontextus)
                val gapMs = if (vadReady) 30_000 else if (meeting) 10_000 else 8000
                SrtJob.progress(0, "Intelligens darabolás (csendek kiszűrése)…")
                val ranges = Vad.speechChunksFromFile(
                    pcmTmp,
                    totalSamples,
                    maxGapMs = gapMs,
                    padMs = 1000,
                    maxChunkMs = if (vadReady) maxOf(chunkMs, 5 * 60 * 1000) else chunkMs,
                    minSpeechMs = 250,
                    neuralModel = vadModel?.absolutePath,
                    threads = 4,
                    minChunkMs = if (vadReady) 90_000 else 25_000,
                    softGapMs = if (vadReady) 90_000 else 20_000,
                    // kevés, szétszórt beszéd: a Whisper darabonként legalább egy teljes 30 mp-es ablakot számol
                    mergeMinSpeechMs = 120_000,
                    mergeMaxSpeechMs = 300_000,
                    mergeMaxSpanMs = 15 * 60_000
                )
                DiagLog.log("VAD mód: ${Vad.lastMethod}")
                val speechMs = ranges.sumOf { (it.end - it.start).toLong() } / 16L
                val pureMs = Vad.lastSpeechMs.takeIf { it > 0 } ?: speechMs
                SrtJob.speechInfo = "Beszéd: ${SrtJob.fmtDur(pureMs)} / ${SrtJob.fmtDur(audioMs)} " +
                    "(${if (audioMs > 0) pureMs * 100 / audioMs else 0}%) · ${ranges.size} darab, csendek nélkül"
                SrtJob.progress(
                    0,
                    "Intelligens darabolás: ${ranges.size} darab, " +
                        "beszéd ${SrtJob.fmtDur(speechMs)} / ${SrtJob.fmtDur(audioMs)}"
                )
                // a becslés a tényleges beszédhossz alapján (a csendeket nem számoljuk): külön előzmény-kulcs
                histBasisKey = "$histKey|sp2"
                histBasisMs = pureMs.coerceAtLeast(1L)
                val spRatio = hist.getFloat("$histBasisKey|p${Perf.level}", 0f).takeIf { it > 0f }
                    ?: hist.getFloat(histBasisKey, 0f)
                if (spRatio > 0f && pureMs > 0) {
                    SrtJob.histEstMs = (spRatio * pureMs).toLong()
                    SrtJob.setEta(recogStart + SrtJob.histEstMs, "korábbi futások és a beszédhossz alapján")
                } else {
                    SrtJob.histEstMs = 0
                    SrtJob.etaAtMs = 0
                }
                if (ranges.isNotEmpty()) {
                    val fine = Vad.lastFine
                    SrtJob.setChunkLens(LongArray(ranges.size) { ri ->
                        val r = ranges[ri]
                        var sum = 0L
                        for (f in fine) {
                            if (f.end <= r.start) continue
                            if (f.start >= r.end) break
                            sum += (minOf(f.end, r.end) - maxOf(f.start, r.start)).toLong()
                        }
                        (if (sum > 0) sum else (r.end - r.start).toLong()) / 16L
                    })
                }
                SrtJob.waveRanges = LongArray(ranges.size * 2) { k ->
                    val r = ranges[k / 2]
                    (if (k % 2 == 0) r.start else r.end).toLong() / 16L
                }
                DiagLog.log("INTELLIGENS DARABOLÁS: ${ranges.size} darab · beszéd ${SrtJob.fmtDur(speechMs)} / ${SrtJob.fmtDur(audioMs)}")
                ranges
            } else emptyList()

            // ellenőrzőpont: kulcs = fájl + motor + modell + nyelv + darabolás
            run {
                val key = Checkpoint.keyOf(
                    uri, asr.key, asr.whisper?.id ?: "", sourceLang, needTranslate, dir, totalSamples,
                    speechRanges.size, speechRanges.firstOrNull()?.start ?: 0, speechRanges.lastOrNull()?.end ?: 0,
                    chunkMs, overlapMs, AsrPrefs.beam(this), useDiarization, SubPrefs.contextTranslate(this),
                    // a javító szabályok és a szótár is az ujjlenyomat része: változásuk után nem használ elavult darabot
                    prefs.enFixes.hashCode(), prefs.customVocab.hashCode(),
                    (prefs.raw().getString("autoRulesEn", "") ?: "").hashCode(), Projects.huRules(this).hashCode()
                )
                val c = Checkpoint.forJob(this, key)
                ckpt = c
                savedChunks = c.load()
                if (savedChunks.isNotEmpty()) {
                    SrtJob.progress(0, "Folytatás: ${savedChunks.size} darab már kész korábbról")
                    DiagLog.log("FOLYTATÁS: ${savedChunks.size} darab ellenőrzőpontból")
                }
            }

            val result = if (useSmartChunks && speechRanges.isEmpty()) {
                SrtJob.progress(100, "Nincs felismerhető beszéd")
                ParallelChunker.Result(emptyList(), 0, 0, false)
            } else {
                chunk.runFromFile(
                    pcmFile = pcmTmp,
                    totalSamples = totalSamples,
                    chunkMs = chunkMs,
                    overlapMs = overlapMs,
                    sequentialOnly = sequential,
                    ranges = speechRanges.takeIf { it.isNotEmpty() },
                    events = events
                ) { slice, offsetMs, idx ->
                    val sliceMs = slice.size / 16L
                    SrtJob.chunkSize(idx, sliceMs, sliceMs)
                    // folytatás: ezt a darabot korábban már kiszámoltuk
                    savedChunks[idx]?.let { prev ->
                        SrtJob.chunkProgress(idx, 1.0, "korábbi eredmény (folytatás)", sliceMs, audioMs)
                        return@runFromFile prev
                    }
                    if (asr.kind == Engines.K_WHISPER && Vad.isMostlySilent(slice)) {
                        SrtJob.chunkProgress(idx, 1.0, "csend – kihagyva", sliceMs, audioMs)
                        return@runFromFile emptyList()
                    }
                    var segs = globalSegs
                    var base0 = 0.0
                    if (perChunkDiar) {
                        SrtJob.chunkProgress(idx, 0.01, "beszélők elkülönítése…", sliceMs, audioMs)
                        val raw = DiarizerFactory.create(this, preferOnnx = preferOnnx).diarize(slice, 16000)
                        segs = raw.map { it.copy(startMs = it.startMs + offsetMs, endMs = it.endMs + offsetMs) }
                        base0 = 0.1
                    }
                    SrtJob.chunkProgress(idx, base0, "felismerés indul…", sliceMs, audioMs)

                    /**
                     * Egy (rész)darab felismerése elakadás-őrrel (csak Whisper): ha a felismerés hosszú ideig nem lép előre,
                     * megszakítjuk, és a hívó újra próbálja kisebb darabokkal. Null = elakadt.
                     */
                    fun part(pcm: ShortArray, off: Long, f0: Double, f1: Double, tm: TimeMap? = null): List<SrtExporter.Cue>? {
                        val guard = asr.kind == Engines.K_WHISPER
                        val tick = AtomicLong(System.currentTimeMillis())
                        val inWhisper = AtomicBoolean(true)
                        val fired = AtomicBoolean(false)
                        val done = AtomicBoolean(false)
                        val limit = maxOf(300_000L, sliceMs * 2)
                        var wd: Thread? = null
                        if (guard) {
                            wd = Thread(Runnable {
                                while (!done.get() && !cancelFlag.get()) {
                                    try { Thread.sleep(5_000) } catch (_: InterruptedException) { return@Runnable }
                                    val idle = System.currentTimeMillis() - tick.get()
                                    // zárolt képernyőn a rendszer lassíthat: ott türelmesebbek vagyunk
                                    val lim = if (DiagLog.screenOn) limit else limit * 3
                                    if (inWhisper.get() && idle > lim) {
                                        fired.set(true)
                                        DiagLog.log("ELAKADÁS-ŐR: darab ${idx + 1} · ${idle / 1000}s nincs haladás → megszakítás")
                                        recognizer.abort()
                                        return@Runnable
                                    }
                                }
                            }, "srt-watchdog").also { it.isDaemon = true; it.start() }
                        }
                        try {
                            val res = recognizer.recognize(
                                pcm, sourceLang, asr, needTranslate, dir, off,
                                { t -> speakerAt(prefs, segs, t) },
                                timeMap = tm
                            ) { pct, msg ->
                                tick.set(System.currentTimeMillis())
                                inWhisper.set(msg.startsWith("Whisper"))
                                SrtJob.chunkProgress(
                                    idx, base0 + (1.0 - base0) * (f0 + (f1 - f0) * pct / 100.0), msg, sliceMs, audioMs
                                )
                            }
                            return if (fired.get() && !cancelFlag.get()) null else res
                        } catch (e: Exception) {
                            if (fired.get() && !cancelFlag.get()) return null
                            throw e
                        } finally {
                            done.set(true)
                            wd?.interrupt()
                        }
                    }

                    // Whispernél csak a beszédrészeket dolgozzuk fel (csendek nélkül összefűzve); az időket visszaképezzük
                    val startSample = speechRanges.getOrNull(idx)?.start ?: (offsetMs * 16L).toInt()
                    val comp = if (asr.kind == Engines.K_WHISPER) Compact.build(slice, startSample, Vad.lastFine) else null
                    val basePcm = comp?.first ?: slice
                    val tm = comp?.second
                    if (comp != null) {
                        SrtJob.chunkSize(idx, basePcm.size / 16L, sliceMs)
                        DiagLog.log("DARAB ${idx + 1}: csendek nélkül ${SrtJob.fmtDur(basePcm.size / 16L)} (eredeti ${SrtJob.fmtDur(sliceMs)})")
                    }
                    val full = part(basePcm, offsetMs, 0.0, 1.0, tm)
                    if (full != null) return@runFromFile full

                    // elakadt: két félre bontva újra
                    SrtJob.message = "Elakadt darab újrapróbálása kisebb részekben…"
                    SrtJob.changed()
                    val half = basePcm.size / 2
                    val a = part(basePcm.copyOfRange(0, half), offsetMs, 0.0, 0.5, tm)
                    val b = part(
                        basePcm.copyOfRange(half, basePcm.size),
                        if (tm == null) offsetMs + half / 16L else offsetMs, 0.5, 1.0,
                        tm?.shifted(half / 16L)
                    )
                    if (a == null || b == null) {
                        DiagLog.log("ELAKADÁS-ŐR: darab ${idx + 1} részben kihagyva (${if (a == null) "első" else "második"} fele elakadt)")
                        SrtJob.skippedParts++
                    }
                    val merged = ArrayList<SrtExporter.Cue>()
                    a?.let { merged.addAll(it) }
                    b?.let { merged.addAll(it) }
                    merged
                }
            }
            if (cancelFlag.get() && result.stoppedEarly) throw InterruptedException("Megszakítva")
            var cues = result.cues
            // önjavító szótár: a felvételen belül ritkán, hibásan leírt nevek a gyakori alakra javulnak (és megjegyződnek)
            if (sourceLang == "en" && VocabLearner.auto(prefs)) try {
                val map = SpellCluster.find(cues.map { it.source })
                if (map.isNotEmpty()) {
                    val before = cues
                    cues = cues.map { c -> c.copy(source = SpellCluster.apply(c.source, map), target = SpellCluster.apply(c.target, map)) }
                    VocabLearner.addAutoRules(prefs, map)
                    DiagLog.log("ÖNJAVÍTÓ SZÓTÁR: " + map.entries.joinToString { "${it.key}→${it.value}" })
                    // a javított forrású sorok fordítása újra lefut (a név a mondatban is jól ragozódjon)
                    if (needTranslate && dir != Prefs.DIR_NONE && !cancelFlag.get()) {
                        val changed = cues.indices.filter { cues[it].source != before[it].source }
                        if (changed.isNotEmpty()) {
                            SrtJob.progress(99, "Szótár-javított sorok újrafordítása (${changed.size})…")
                            try { cues = recognizer.retranslate(cues, changed, dir, null) { _, _, _ -> } } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            var filteredNote = ""
            var droppedCues: List<SrtExporter.Cue> = emptyList()
            if (SubPrefs.hallucFilter(this) && cues.size >= 2) {
                val hf = Hallucination.clean(cues)
                if (hf.dropped > 0 || hf.flagged > 0) {
                    DiagLog.log(
                        "HALLUCINÁCIÓ-ELLENŐRZÉS: eltávolítva=${hf.dropped}, ismétlődő=${hf.repeats}, " +
                            "ellenőrzendő magányos=${hf.isolated}, alacsony logprob=${hf.lowConf}"
                    )
                    cues = hf.cues
                    droppedCues = hf.removed
                    filteredNote = buildString {
                        if (hf.dropped > 0) append(" · ${hf.dropped} ismétlődő blokk kiszűrve")
                        if (hf.flagged > 0) append(" · ${hf.flagged} blokk ellenőrzést igényel")
                    }
                }
            }
            if (SubPrefs.secondPass(this) && asr.kind == Engines.K_WHISPER && cues.isNotEmpty() && !cancelFlag.get()) {
                try {
                    cues = secondPass(cues, pcmTmp, asr, sourceLang, dir, needTranslate, recognizer)
                } catch (e: Throwable) {
                    DiagLog.log("MÁSODIK MENET HIBA: ${errText(e)}")
                }
            }
            SrtJob.cooling = false
            SrtJob.etaAtMs = 0
            SrtJob.finish("${cues.size} blokk")
            SrtJob.chunkDone = SrtJob.chunkTotal
            if (cancelFlag.get()) throw InterruptedException("Megszakítva")

            // a felismerés tényleges sebessége (idő / hanghossz) a következő becsléshez
            try {
                val recMs = SrtJob.steps[SrtJob.ST_RECOG].durMs
                // folytatott futás ideje nem reprezentatív → nem frissítjük az előzményt
                if (recMs > 0 && histBasisKey.isNotEmpty() && savedChunks.isEmpty()) {
                    val key = "$histBasisKey|p${Perf.level}"
                    val newRatio = recMs.toFloat() / histBasisMs.coerceAtLeast(1L)
                    val old = hist.getFloat(key, 0f)
                    hist.edit().putFloat(key, if (old > 0f) (old + newRatio) / 2f else newRatio)
                        .putFloat(histBasisKey, if (hist.getFloat(histBasisKey, 0f) > 0f) (hist.getFloat(histBasisKey, 0f) + newRatio) / 2f else newRatio)
                        .apply()
                }
            } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            try {
                // mért ablak-idő a következő becsléshez (csak teljes, nem folytatott futásból)
                if (savedChunks.isEmpty()) {
                    var w = 0L; var ms = 0L
                    for (ci in SrtJob.chunkInfo) if (ci.tookMs >= 2000) { w += EtaModel.windows(ci.speechMs); ms += ci.tookMs }
                    if (w >= 3) {
                        val m = ms / w
                        val old = hist.getLong("msPerWindow", 0L)
                        hist.edit().putLong("msPerWindow", if (old > 0) (old + m) / 2 else m).apply()
                        asr.whisper?.id?.let { wid ->
                            val oldM = hist.getLong("mpw_$wid", 0L)
                            hist.edit().putLong("mpw_$wid", if (oldM > 0) (oldM + m) / 2 else m).apply()
                        }
                    }
                }
            } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            SrtJob.preview = cues.takeLast(8).map { previewLine(it) }
            SrtJob.previewCues = cues.takeLast(6)

            // -------------------------------------------------------------- mentés
            SrtJob.begin(SrtJob.ST_SAVE, "SRT összeállítása…")
            val srt = buildSrt(cues, mode)

            // mentés a belső tárba mindig
            SrtJob.progress(20, "Mentés az alkalmazás tárolójába…")
            val name = "felirat_$stamp.srt"
            File(TranscriptStore.dir(this), name).writeText(srt, Charsets.UTF_8)
            val md = ExportHelper.toMarkdown(cues, "Tárgyalási átirat")
            ExportHelper.write(File(TranscriptStore.dir(this), "jegyzokonyv_$stamp.md"), md)
            val plain = ExportHelper.toPlainMinutes(cues)
            ExportHelper.write(File(TranscriptStore.dir(this), "jegyzokonyv_$stamp.txt"), plain)
            try { partialFile.delete() } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }

            // …és a beállított helyre (a videó mellé / alapértelmezett mappába)
            SrtJob.progress(60, "Mentés a beállított helyre…")
            val where = saveOutputs(kind, uri, base, langTag, srt, cues, false)

            SrtJob.complete(cues.size, srt, name, where)
            // az ellenőrzőpont megmarad (7 nap): ugyanazon fájl és beállítás újrafuttatása a kész darabokat újrahasznosítja
            DiagLog.log("FÁJL KÉSZ: ${item.name} · ${cues.size} blokk · ${SrtJob.fmtDur(System.currentTimeMillis() - SrtJob.startMs)}")
            item.srt = srt
            item.srtName = srtFileName
            item.saved = where != null
            item.cueCount = cues.size
            item.cues = cues
            item.localFile = name
            if (needTranslate) try { TranslationMemoryStore.record(this, cues) } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            // sorozat-mód: a felismert szereplőnevek bekerülnek a projekt szereplői közé, a következő rész már ismeri őket
            try {
                val known = Projects.get(this, "cast")
                val have = NameFix.parseNames(known).map { it.lowercase() }.toSet()
                val add = SrtJob.names.filter { it.lowercase() !in have }.take(8)
                if (add.isNotEmpty()) Projects.set(this, "cast", (known.trimEnd() + "\n" + add.joinToString("\n")).trim())
            } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            item.dropped = droppedCues
            item.mode = mode
            item.dir = dir
            val flaggedN = try { LineQuality.summarize(cues).count { it.isNotEmpty() } } catch (_: Exception) { 0 }
            item.detail = (if (where != null) "Mentve $where"
            else "Nincs elérhető mentési hely – használd a Mentés gombot.") + filteredNote +
                (if (flaggedN > 0) " · $flaggedN sor ellenőrzésre jelölve (Átnézés)" else "") +
                (if (SrtJob.engineText().isNotBlank()) "\n${SrtJob.engineText()}" else "") +
                (if (SrtJob.names.isNotEmpty()) "\nFelismert nevek: ${SrtJob.names.joinToString(", ")}" else "") +
                (if (SrtJob.translateNote.isNotBlank()) "\n${SrtJob.translateNote}" else "")
            item.state = SrtJob.Q_DONE
            SrtJob.changed()
        } catch (e: InterruptedException) {
            DiagLog.log("FÁJL MEGSZAKÍTVA: ${item.name} · a kész darabok az ellenőrzőpontban maradnak (újraindításkor folytatódik)")
            val where = salvage()
            SrtJob.partialWhere = where
            SrtJob.stopped()
            item.detail = if (where != null) "Megszakítva · a kész rész elmentve $where" else "Megszakítva"
            item.state = SrtJob.Q_STOP
            SrtJob.changed()
        } catch (e: Throwable) {
            DiagLog.log("FÁJL HIBA: ${item.name} · ${errText(e)}")
            val where = salvage()
            SrtJob.partialWhere = where
            val txt = errText(e)
            SrtJob.fail(txt)
            item.detail = txt + if (where != null) "\nA kész rész elmentve $where" else ""
            item.state = SrtJob.Q_ERR
            SrtJob.changed()
        } finally {
            // időkorlát esetén a folytatási ajánlat megmarad (az ellenőrzőpont sem törlődik)
            if (!timedOut) try { prefs.raw().edit().remove("pendingJob").apply() } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            try { fr?.close() } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            try { pcmFile?.delete() } catch (e: Exception) { DiagLog.swallow("SrtJobService", e) }
            chunker = null
            recRef = null
        }
    }

    private fun previewLine(c: SrtExporter.Cue): String {
        val t = SrtExporter.formatTime(c.startMs).take(8)
        val txt = c.source.ifBlank { c.target }
        val tr = if (c.target.isNotBlank() && c.target != c.source) " → ${c.target}" else ""
        val spk = if (c.speaker.isNotBlank()) "${c.speaker}: " else ""
        return "[$t] $spk$txt$tr"
    }

    private fun srtNameFor(kind: String, base: String, langTag: String, partial: Boolean): String {
        val suffix = if (partial) ".reszleges" else ""
        return if (kind == KIND_TRANSCRIPT) "${base}_atirat$suffix.srt"
        else "$base${if (langTag.isNotBlank()) ".$langTag" else ""}$suffix.srt"
    }

    /**
     * Egy fájl mentése a kiválasztott módon:
     *  - "videó mellé" (alapértelmezett): oda, ahonnan a videót betöltöttük; ha ez nem megy, az alapértelmezett mappába,
     *  - "alapértelmezett mappa": csak oda.
     * Ad: ember-olvasható hely, vagy null.
     */
    private fun saveFile(video: Uri, name: String, mime: String, bytes: ByteArray): String? {
        val tree = OutputPrefs.defaultTree(this)
        val beside = OutputPrefs.saveMode(this) == OutputPrefs.SAVE_BESIDE
        if (beside) {
            OutputWriter.saveBesideVideo(this, video, name, mime, bytes)?.let { return it }
        }
        if (tree != null) {
            val label = OutputWriter.saveInTree(this, tree, name, mime, bytes)
            if (label != null) {
                return (if (beside) "az alapértelmezett mappába (a videó mellé nem sikerült): " else "az alapértelmezett mappába: ") +
                    "$label/$name"
            }
        }
        return null
    }

    /**
     * Kimenet mentése a beállított helyre.
     *  - átirat: SRT + TXT,
     *  - felirat: SRT.
     * Null = nincs beállított / elérhető hely; ilyenkor a képernyő mentés-ablakot kínál.
     */
    private fun saveOutputs(
        kind: String, video: Uri, base: String, langTag: String, srt: String,
        cues: List<SrtExporter.Cue>, partial: Boolean
    ): String? {
        val srtBytes = srt.toByteArray(Charsets.UTF_8)
        val name = srtNameFor(kind, base, langTag, partial)
        val w = saveFile(video, name, OutputWriter.MIME_SRT, srtBytes)
        if (w != null && kind == KIND_TRANSCRIPT) {
            val suffix = if (partial) ".reszleges" else ""
            val txt = ExportHelper.toPlainMinutes(cues, "Átirat – $base").toByteArray(Charsets.UTF_8)
            saveFile(video, "${base}_atirat$suffix.txt", "text/plain", txt)
        }
        return w
    }

    private fun speakerAt(prefs: Prefs, segments: List<SpeakerDiarizer.Segment>, timeMs: Long): String {
        if (segments.isEmpty()) return ""
        val seg = segments.firstOrNull { timeMs >= it.startMs && timeMs < it.endMs }
            ?: segments.minByOrNull { kotlin.math.abs(it.startMs - timeMs) }
        if (seg == null) return ""
        val map = SpeakerNames.fromPrefs(prefs)
        return SpeakerNames.label(seg.speakerId, map)
    }
}
