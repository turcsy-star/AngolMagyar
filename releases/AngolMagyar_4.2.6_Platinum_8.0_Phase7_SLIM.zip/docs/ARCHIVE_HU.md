# Fejlesztési archívum (összevont állapot-, changelog- és terv-dokumentumok)

Az eredeti különálló fájlok ide lettek összevonva. Tartalom: 180 dokumentum.

## Tartalomjegyzék

- ALL_RECOMMENDATIONS_IMPLEMENTATION_HU.md
- ALL_RECOMMENDATIONS_STATUS_HU.md
- BUILD_FIX_V24_HU.md
- BUILD_STATUS_2.44.0_HU.md
- BUILD_STATUS_2.56.0_HU.md
- BUILD_STATUS_2.57.0_HU.md
- BUILD_STATUS_2.59.0_HU.md
- BUILD_STATUS_2.60.0_HU.md
- BUILD_STATUS_2.62.0_HU.md
- BUILD_STATUS_2.63.0_HU.md
- BUILD_STATUS_2.64.0_HU.md
- BUILD_STATUS_2.65.0_HU.md
- BUILD_STATUS_2.66.0_HU.md
- BUILD_STATUS_2.67.0_HU.md
- BUILD_STATUS_3.00.0_HU.md
- BUILD_STATUS_3.01.0_HU.md
- BUILD_STATUS_3.02.0_HU.md
- BUILD_STATUS_3.03.0_HU.md
- BUILD_STATUS_3.04.0_HU.md
- BUILD_STATUS_3.05.0_HU.md
- BUILD_STATUS_3.06.0_HU.md
- BUILD_STATUS_3.10.0_HU.md
- BUILD_STATUS_3.11.0_HU.md
- BUILD_STATUS_3.12.0_HU.md
- BUILD_STATUS_3.13.0_HU.md
- BUILD_STATUS_4.0.0_HU.md
- BUILD_STATUS_4.0.1_HU.md
- BUILD_STATUS_4.1.0_HU.md
- BUILD_STATUS_4.1.1_HU.md
- BUILD_STATUS_4.2.0_HU.md
- BUILD_STATUS_4.2.1_HU.md
- BUILD_STATUS_4.2.2_HU.md
- BUILD_STATUS_4.2.3_HU.md
- BUILD_STATUS_4.2.6_HU.md
- BUILD_STATUS_DIAMOND_V10_HU.md
- BUILD_STATUS_DIAMOND_V11_HU.md
- BUILD_STATUS_HU.md
- BUILD_STATUS_PLATINUM_8.0_PHASE7_FIX_HU.md
- CHANGELOG_PLATINUM_7.0_ENGINEERING_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE2_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE3_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE4_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE5_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE6_HU.md
- CHANGELOG_PLATINUM_8.0_PHASE7_HU.md
- CHANGELOG_V19_HU.md
- CHANGELOG_V2.58.0_HU.md
- CHANGELOG_V2.59.0_HU.md
- CHANGELOG_V2.60.0_HU.md
- CHANGELOG_V2.61.0_HU.md
- CHANGELOG_V2.62.0_HU.md
- CHANGELOG_V2.63.0_HU.md
- CHANGELOG_V2.64.0_HU.md
- CHANGELOG_V2.65.0_HU.md
- CHANGELOG_V2.66.0_HU.md
- CHANGELOG_V2.67.0_HU.md
- CHANGELOG_V20_HU.md
- CHANGELOG_V21_HU.md
- CHANGELOG_V22_HU.md
- CHANGELOG_V23_HU.md
- CHANGELOG_V24_HU.md
- CHANGELOG_V3.00.0_HU.md
- CHANGELOG_V3.01.0_HU.md
- CHANGELOG_V3.02.0_HU.md
- CHANGELOG_V3.03.0_HU.md
- CHANGELOG_V3.04.0_HU.md
- CHANGELOG_V3.05.0_HU.md
- CHANGELOG_V3.06.0_HU.md
- CHANGELOG_V3.10.0_HU.md
- CHANGELOG_V3.11.0_HU.md
- CHANGELOG_V3.12.0_HU.md
- CHANGELOG_V3.13.0_HU.md
- CHANGELOG_V4.0.0_HU.md
- CHANGELOG_V4.0.1_HU.md
- CHANGELOG_V4.1.0_EN.md
- CHANGELOG_V4.1.0_HU.md
- CHANGELOG_V4.1.1_HU.md
- CHANGELOG_V4.2.0_HU.md
- CHANGELOG_V4.2.1_HU.md
- CHANGELOG_V4.2.2_HU.md
- CHANGELOG_V4.2.3_HU.md
- CHANGELOG_V4.2.4_HU.md
- CHANGELOG_V4.2.5_HU.md
- CHANGELOG_V4.2.6_HU.md
- CHANGELOG_V4.2.6_PLATINUM_6.0_ENGINEERING_HU.md
- CHANGELOG_V56_HU.md
- CHANGELOG_v2.30.0_HU.md
- COMPOSE_COMPILER_FIX_HU.md
- DIAMOND_BLUE_V10_HU.md
- DIAMOND_BLUE_V11_HU.md
- DIAMOND_CINEMA_ULTIMATE_V3.10_HU.md
- FEATURE_MATRIX_5.0_HU.md
- IMPLEMENTATION_AND_TEST_PLAN_5.0_HU.md
- IMPLEMENTATION_NOTES_HU.md
- INFINITY_AI_INTELLIGENCE_WAVE_V2.57.0_HU.md
- INFINITY_AI_VOICE_MASTER_V2.58.0_HU.md
- MIGRATION_4.2.0_TO_4.2.1_HU.md
- NEXT_WAVE_V2.55.0_HU.md
- NEXT_WAVE_V2.56.0_HU.md
- NEXT_WAVE_V2.63_3.00_HU.md
- PHASE4_FILE_MATRIX_HU.md
- PHASE4_VALIDATION_HU.md
- PHASE5_FILE_MATRIX_HU.md
- PHASE5_VALIDATION_HU.md
- PHASE6_FILE_MATRIX_HU.md
- PHASE6_VALIDATION_HU.md
- PHASE7_FILE_MATRIX_HU.md
- PHASE7_VALIDATION_HU.md
- PLATINUM_6.0_ENGINEERING_FILE_INVENTORY_HU.md
- PLATINUM_7.0_PHASE1_VALIDATION_HU.md
- PLATINUM_INFINITY_AI_MASTER_V2.60.0_HU.md
- PLATINUM_INFINITY_SOVEREIGN_AI_V2.59.0_HU.md
- PLATINUM_INFINITY_SOVEREIGN_V19_HU.md
- PLATINUM_INFINITY_SOVEREIGN_V20_HU.md
- PLATINUM_INFINITY_SOVEREIGN_V21_HU.md
- PLATINUM_INFINITY_V22_HU.md
- PLATINUM_INFINITY_V23_INTELLIGENCE_SUITE_HU.md
- PLATINUM_INTELLIGENCE_6.0_FILE_MATRIX_HU.md
- PLATINUM_INTELLIGENCE_6.0_IMPLEMENTATION_PLAN_HU.md
- PLATINUM_INTELLIGENCE_6.0_STATUS_HU.md
- PLATINUM_INTELLIGENCE_6.0_TEST_PLAN_HU.md
- PLATINUM_INTELLIGENCE_7.0_FILE_MATRIX_HU.md
- PLATINUM_INTELLIGENCE_7.0_MASTER_PLAN_HU.md
- PLATINUM_INTELLIGENCE_7.0_STATUS_HU.md
- PLATINUM_INTELLIGENCE_7.0_TEST_PLAN_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE2_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE2_STATUS_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE2_VALIDATION_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE3_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE4_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE5_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE6_HU.md
- PLATINUM_INTELLIGENCE_8.0_PHASE7_HU.md
- PLATINUM_ULTRA_EXTREME_V12_HU.md
- PLATINUM_ULTRA_EXTREME_V13_HU.md
- PLATINUM_ULTRA_EXTREME_V14_HU.md
- PLATINUM_ULTRA_EXTREME_V15_HU.md
- PLATINUM_ULTRA_EXTREME_V16_HU.md
- PLATINUM_ULTRA_EXTREME_V17_HU.md
- PLATINUM_ULTRA_EXTREME_V18_HU.md
- PREMIUM_INTELLIGENCE_5.0_SPEC_HU.md
- PREMIUM_ROADMAP_HU.md
- PREMIUM_UI_BLUE_CINEMATIC_HU.md
- PREMIUM_UI_BLUE_CINEMATIC_V3_HU.md
- PREMIUM_UI_BLUE_CINEMATIC_V4_HU.md
- PREMIUM_UI_PLATINUM_V5_HU.md
- PREMIUM_UI_PLATINUM_V6_HU.md
- PREMIUM_UI_PLATINUM_V7_HU.md
- QUALITY_CHECK_HU.md
- QUALITY_CHECK_V17_HU.md
- QUALITY_IMPROVEMENTS_HU.md
- RELEASE_CHECKLIST_6.0_RC_HU.md
- RELEASE_NOTES_4.2.3_HU.md
- SECURE_BACKUP_DIAMOND_V2.61.0_HU.md
- SECURITY_HARDENING_4.2.1_HU.md
- SILVER_GOLD_ULTIMATE_UPDATE_HU.md
- SOURCE_AUDIT_4.2.6_HU.md
- ULTIMATE_2.33.0_HU.md
- ULTIMATE_2.34.0_HU.md
- ULTIMATE_2.35.0_HU.md
- ULTIMATE_2.36.0_HU.md
- ULTIMATE_2.37.0_HU.md
- ULTIMATE_2.38.0_HU.md
- ULTIMATE_2.39.0_HU.md
- ULTIMATE_2.40.0_HU.md
- ULTIMATE_2.41.0_HU.md
- ULTIMATE_2.42.0_HU.md
- ULTIMATE_2.43.0_HU.md
- ULTIMATE_2.44.0_HU.md
- ULTIMATE_ECOSYSTEM_4.0_HU.md
- UPDATE10_HU.md
- UPDATE11_HU.md
- UPDATE12_HU.md
- UPDATE13_HU.md
- UPDATE8_HU.md
- VALIDATION_REPORT_4.2.2_HU.md
- VALIDATION_REPORT_4.2.3_HU.md
- VALIDATION_REPORT_4.2.4_HU.md
- VALIDATION_REPORT_4.2.5_HU.md
- VALIDATION_REPORT_4.2.6_HU.md


---

<!-- forrás: ALL_RECOMMENDATIONS_IMPLEMENTATION_HU.md -->

## [ALL_RECOMMENDATIONS_IMPLEMENTATION_HU.md]

## AngolMagyar – összes fejlesztési javaslat megvalósítási terve

### v2.28.8-dev frissítés

- A `ReviewIntelligence` már az `SrtEditorActivity` eszközei között is megjelenik.
- Az „Ellenőrzési javaslatok” megnyitja a felismert jelzések listáját, súlyossággal és indoklással.
- Egy listaelem kiválasztásával a szerkesztő az adott feliratblokk oldalára navigál.
- A jelzések nem végeznek automatikus tartalmi javítást.
- Az Android APK-build és az eszközteszt továbbra sincs igazolva.

### Ebben a fejlesztési csomagban elkészült

#### 1. Offline ellenőrzési motor (új, tiszta Kotlin API)
- `core/review/ReviewIntelligence.kt`: nem módosítja az átiratot, kizárólag ellenőrzési jelzéseket ad.
- Külön jelzi az alacsony confidence-ot, számokat, tagadást/kizárást, dátumokat/időpontokat, rövid töredékeket, ismétlődő szöveget és üres sorokat.
- Súlyosság alapján rangsorol: a tagadások kritikus jelzést kapnak; számok, dátumok és nagyon alacsony confidence magas prioritásúak.
- A célzott ellenőrzési terv betartja a sorszám- és időkeretet; nem indít felismerést, csak sorindexeket javasol.
- SHA-256 fingerprint azonosítja azonos bemenetek ismételt feldolgozását; a részek hosszát is kódolja, így a `("ab", "c")` és `("a", "bc")` nem ütközik.
- `ReviewAuditEntry` tárolható modellt ad a visszavonható javítások naplózásához.
- `RecognitionBenchmark` a WER-től külön kezeli a kritikus hibaszámot és a feldolgozási időt.

#### 2. Biztonsági elv
- A program sem számot, sem nevet, sem tagadást nem javít át automatikusan e modul alapján.
- A „kritikus” jelzés ellenőrzési prioritás, nem annak állítása, hogy a felismert szó biztosan hibás.
- A WER nem tekinthető fordításminőségnek vagy jogi hitelességi mutatónak.

### Teljes megvalósítási lista és státusz

| Javaslat | Státusz ebben a csomagban |
|---|---|
| Célzott újrafelismerés idő-/darabkerettel | A prioritás- és kerettervező API elkészült; az SRT-szerkesztő és az audio-vágó motor összekötése még szükséges. |
| Kritikus szavak ellenőrzése | Az offline jelzőmotor elkészült; a soronkénti UI-integráció még szükséges. |
| Referenciaalapú benchmark | Benchmark adatmodell elkészült; a 20–50 kézzel címkézett hangminta és a futtató UI/projekt még szükséges. |
| Kontextusérzékeny, konzervatív javítás | A kritikus jelzések és a nem automatikus működés alapja elkészült; a szótár-javaslatok megerősítési munkafolyamata még szükséges. |
| Modern minőségellenőrző felület | A meglévő felületet meg kell tartani; az új motor bekötése és a kritikus szűrők UI-ja még szükséges. |
| Visszavonható auditnapló | Az adatmodell elkészült; a tartós tárolás és a meglévő szerkesztő Undo funkciójának összekötése még szükséges. |
| Idő- és erőforrás-kezelés | Kerettervező és fingerprint elkészült; feldolgozási pipeline-integráció és eszközfüggő mérés még szükséges. |
| Kiadási és adatbiztonsági ellenőrzés | Ez a tervdokumentum és a tesztek bekerültek; teljes Android-buildet ebben a környezetben nem igazoltunk. |
| Hibatípus-alapú felismerés | A típusozott jelzések alapja elkészült; a felismerési stratégiákkal való összekötés még szükséges. |
| Bizonytalansági térkép | A soronkénti jelzések és a forrásidő mezői rendelkezésre állnak; hullámforma/UI-integráció még szükséges. |
| Javítás eredményességének visszamérése | Benchmark modell elkészült; az újrafelismerési eredmény automatikus összehasonlítása még szükséges. |

### Tesztelés

A `ReviewIntelligence.kt` fájl önálló Kotlin-fordítása sikeres volt. A hozzáadott JUnit tesztek a kritikus jelzéseket, a kereteket, a fingerprintet és a benchmark számítását fedik le. A teljes JUnit csomag és az Android APK nem tekinthető igazoltnak: ehhez helyreállított Gradle Wrapper, Android SDK és teljes build szükséges.

Javasolt ellenőrzés Android Studio-ban:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

A teljes kiadást csak akkor szabad késznek tekinteni, ha a tesztek és az APK-build is sikeresek, valamint a célzott hangrészlet-visszajátszást tényleges Android-eszközön kipróbálták.


---

<!-- forrás: ALL_RECOMMENDATIONS_STATUS_HU.md -->

## [ALL_RECOMMENDATIONS_STATUS_HU.md]

## Fejlesztési javaslatok – státusz 2.43.0

Ez a dokumentum elkülöníti a ténylegesen bekerült fejlesztéseket a további munkát igénylő ötletektől.

| Terület | Státusz | Megjegyzés |
|---|---|---|
| Platinum/Gold központi Compose-tokenek | Részben megvalósítva | A központi tokenek és komponensek megvannak; a teljes View-képernyőmigráció nincs kész. |
| Prémium fordítási kártya | Megvalósítva a Compose élő kártyában | Forrás/fordítás, másolás, felolvasás, mentés. |
| Online LLM stílusválasztás | Megvalósítva | Természetes/Pontos/Hivatalos/Közvetlen; offline/DeepL nem módosul. |
| Saját helyi szókincstár | Megvalósítva alapfunkciókkal | Mentés, keresés, másolás, törlés; nincs felhőszinkron. |
| Magyar felolvasás | Megvalósítva alapfunkcióval | Android TTS; elérhetőség a telepített beszédhangtól függ. |
| Beszédállapotok és kétirányú élő fordítás | Meglévő alapok, további validáció szükséges | Valódi eszközteszt és megszakítási/életciklus-tesztek szükségesek. |
| Kontextusmagyarázat és többértelműség jelzése | További fejlesztés | A meglévő online háttér/hint nem teljes kontextusmagyarázó funkció. |
| Ismétléses tanulóalgoritmus | További fejlesztés | A mentett kifejezések még nem ütemeznek ismétlést. |
| Kiejtéslabor, brit/amerikai hang és kiejtési pontszám | További fejlesztés | Pontozáshoz valódi fonetikai/ASR-alapú mérés szükséges. |
| Adatvédelem | Részben megvalósítva | A szókincstár helyi és csak manuálisan ment; a hálózati szolgáltatók adatkezelését külön ellenőrizni kell. |
| Performance és akkumulátor | Részben megvalósítva | Üresjárati frissítések csökkentése megvan; mért benchmark nincs. |
| Build/CI | Automatizálás konfigurálva, eredmény nem igazolt | Gradle 8.9 letöltése hálózati hibán elbukott. |
| Vizuális regresszióteszt | Részben megvalósítva | Screenshot smoke teszt van; jóváhagyott golden-baseline összehasonlítás hiányzik. |

**Kiadási állapot:** forráscsomag elkészítve, de build- és tesztigazolás nélkül nem tekinthető bizonyítottan buildelhető kiadásnak.


### 2.44.0 kiegészítés

- Elkészült: helyi szókincsismétlés, fordítás felfedése, „Tudtam” / „Nem tudtam” értékelés és fokozatos időzítés. Részletek: `ULTIMATE_2.44.0_HU.md`.
- Továbbra is hátralévő tételek: kontextusmagyarázat, kiejtéslabor, teljes Compose-migráció, valódi golden screenshot összehasonlítás és fizikai eszközös ellenőrzés.


### 2.55.0 – következő fejlesztési hullám

- Smart Context Translation: első, szabályalapú kontextus-brief eszköz elkészült; teljes szemantikai elemzés és generatív alternatívák még nincsenek.
- Translation Quality: meglévő ellenőrző motor UI-integrációja elkészült; teljes nyelvtani/terminológiai ellenőrzés nem állítható.
- Infinity Global UI és Platinum Motion: meglévő infrastruktúra megjelenítve, teljes képernyőmigráció és profilintegráció továbbra is hátralék.
- Build és fizikai Android-eszközteszt: külön igazolandó.
\n\n## 2.56.0 – Ultimate Intelligence\n\n- Dual Translation: két változat összehasonlítása a meglévő auditmotor figyelmeztetéseivel; nincs automatikus minőségi rangsor.\n- Dictionary Pro Offline: 26 gyakori többjelentésű szó helyi keresése példamondatokkal.\n- Pronunciation Master: Android TextToSpeech, US/UK locale választással; telepített hangadat szükséges.\n- Infinity Quality Dashboard: szó- és karakterszám, szóarány, auditjelzések.\n- Generatív Infinity AI Engine: csak integrációs előkészítés; külső AI-szolgáltatás nincs bekapcsolva.\n- Build és fizikai eszközteszt: igazolandó.\n


---

<!-- forrás: BUILD_FIX_V24_HU.md -->

## [BUILD_FIX_V24_HU.md]

## CI build fix – v24

A javított fájlok:
- `app/src/main/java/hu/angolmagyar/fordito/ui/processing/PlatinumDial.kt`
- `app/src/main/java/hu/angolmagyar/fordito/ui/processing/PlatinumProgressBar.kt`

A naplóban látható hibaokok: hiányzó `getValue` import a `by animateFloatAsState(...)` kifejezéshez, hiányzó `@Composable` annotáció, illetve a Compose-verzióban nem elérhető `Role.ProgressBar` szimbólum.


---

<!-- forrás: BUILD_STATUS_2.44.0_HU.md -->

## [BUILD_STATUS_2.44.0_HU.md]

## Build státusz – 2.44.0

- Verzió: `2.44.0` (`versionCode = 4400`).
- Új funkció: helyi, időzített szókincsismétlés a Saját szókincstár képernyőn.
- Új teszt: ismétlési intervallum és következő esedékesség ellenőrzése.
- Megőrzött adatkompatibilitás: a korábbi mentésekhez hiányzó ismétlési mezők alapértelmezett értékekkel töltődnek be.
- Teljes Gradle build/APK státusz: **nem igazolt**; a korábbi buildkísérlet a Gradle disztribúció letöltésénél DNS-hibába ütközött.


---

<!-- forrás: BUILD_STATUS_2.56.0_HU.md -->

## [BUILD_STATUS_2.56.0_HU.md]

## Build status – v2.56.0

- Forrásmódosítások: elkészültek.
- Verzió: 2.56.0 (versionCode 5600).
- Manifest: a NextWaveToolsActivity regisztrációja megmaradt.
- Platinum Intelligence Hub: a négy roadmap-kártya az új eszközoldalra navigál.
- Kotlin/Android build: NEM IGAZOLT.
- Próbált parancs: `./gradlew :app:compileDebugKotlin --offline`.
- Eredmény: a Gradle Wrapper a 8.9-es disztribúciót próbálta letölteni, de a környezet DNS-feloldási hibája miatt a `services.gradle.org` nem volt elérhető (`UnknownHostException`).
- Fizikai Android-eszközteszt: nem történt.
- TTS: Android platform API; a brit/amerikai hang elérhetősége a készülék telepített TTS hangadataitól függ.

A csomag módosított forrásprojekt, nem előre lefordított vagy tesztelt APK.


---

<!-- forrás: BUILD_STATUS_2.57.0_HU.md -->

## [BUILD_STATUS_2.57.0_HU.md]

## Build státusz – v2.57.0
- Forrásfejlesztések: elkészültek.
- Új modulok: SynonymEngine, PronunciationAssessment, DictionaryCsv, LearningStats.
- NextWaveToolsActivity: szinonimakereső és átirat-összevető UI.
- Verzió: 2.57.0 / 5700.
- Unit tesztek hozzáadva, de Gradle-futtatás még nem igazolt.
- APK és fizikai eszközteszt: nem igazolt.


---

<!-- forrás: BUILD_STATUS_2.59.0_HU.md -->

## [BUILD_STATUS_2.59.0_HU.md]

## Build állapot – v2.59.0

- Forráscsomag és Room 2 → 3 migráció elkészítve.
- Intelligens ismétlő Compose-képernyő és központi navigáció elkészítve.
- Spaced-repetition ütemező egységtesztjei hozzáadva.
- ZIP-integritás ellenőrizhető csomagolás után.
- Gradle tesztparancs megkísérelve: `./gradlew :app:testDebugUnitTest --offline --no-daemon`.
- A Gradle wrapper 8.9 disztribúciója hiányzik a helyi cache-ből; a letöltés DNS-hiba (`UnknownHostException: services.gradle.org`) miatt nem sikerült.
- Kotlin fordítás, Room KSP generálás, unit teszt, APK és eszközteszt ezért nincs igazolva.


---

<!-- forrás: BUILD_STATUS_2.60.0_HU.md -->

## [BUILD_STATUS_2.60.0_HU.md]

## Build állapot – v2.60.0

- [x] Backup JSON codec elkészült.
- [x] Formátum-, verzió-, méret- és rekordszám-ellenőrzés.
- [x] Room DAO export/clear/bulk restore műveletek.
- [x] Tranzakciós visszaállítás a három adatkörre.
- [x] SAF-alapú export és import képernyő.
- [x] Backup Center regisztrálva a manifestben és az Intelligence Suite-ban.
- [x] Verzióemelés: 6000 / 2.60.0.
- [x] Backup codec unit tesztek hozzáadva.
- [ ] Gradle Kotlin fordítás és KSP ellenőrzés.
- [ ] Unit tesztek futtatása.
- [ ] APK build és fizikai Android-eszköz teszt.

A build/test státuszt nem jelöljük sikeresnek futtatás nélkül. Korábbi környezetben a Gradle wrapper letöltése DNS-hiba miatt nem volt elérhető; ebben a csomagban a build eredménye külön ellenőrzendő.


---

<!-- forrás: BUILD_STATUS_2.62.0_HU.md -->

## [BUILD_STATUS_2.62.0_HU.md]

## Build állapot – v2.62.0

- [x] WorkManager napi periódikus feladat.
- [x] WorkManager heti periódikus feladat.
- [x] Ütemezés be/ki kapcsolása a Backup Center felületén.
- [x] Helyi AES-256-GCM titkosítás Android Keystore kulccsal.
- [x] Automatikus mentés rotáció (14 legfrissebb fájl).
- [x] Konzisztens adatbázis-pillanatkép Room-tranzakcióval.
- [x] Atomi fájlírás ideiglenes fájllal és fsync művelettel.
- [x] Titkosítási fejléc hitelesítése AES-GCM AAD használatával.
- [x] Titkosított puffer törlése a feldolgozás után.
- [x] Utolsó sikeres futás / hiba állapotának tárolása.
- [x] Verzióemelés 6200 / 2.62.0.
- [ ] Gradle Kotlin fordítás és KSP ellenőrzés.
- [ ] Unit tesztek és Android-eszköz teszt.

A Gradle ellenőrzés megkísérelve: a wrapper a Gradle 8.9 disztribúciót próbálta letölteni, de a környezet DNS-hibája miatt (`UnknownHostException: services.gradle.org`) nem volt elérhető. A build ezért nem minősíthető sikeresnek. A csomag ZIP-integritásellenőrzése sikeres; Kotlin-fordítás, tesztfuttatás és fizikai Android-eszközön végzett ellenőrzés nem történt.


---

<!-- forrás: BUILD_STATUS_2.63.0_HU.md -->

## [BUILD_STATUS_2.63.0_HU.md]

## Build státusz – v2.63.0

- [x] v2.62.0 FIXED forrásból induló teljes projektfrissítés
- [x] Learning Analytics Store (dátum szerinti helyi számlálók)
- [x] Napi cél és célkövetés
- [x] 7 napos trendgrafikon
- [x] 30 napos aktivitási és pontossági mutatók
- [x] Szókincstár gyakorlási eseményeinek bekötése
- [x] Intelligens ismétlő eseményeinek bekötése
- [x] Platinum Intelligence Suite navigációs bekötés
- [x] Manifest és verziószám frissítése (6300 / 2.63.0)
- [x] ZIP archívum integritásellenőrzése
- [ ] Gradle/Kotlin fordítás – blokkolja a Gradle disztribúció DNS-letöltési hibája
- [ ] Fizikai Android-eszközön UI- és tartós tárolási teszt

Megjegyzés: a statisztika a funkció telepítése után gyűjt adatot, visszamenőleges adatimport nincs.


---

<!-- forrás: BUILD_STATUS_2.64.0_HU.md -->

## [BUILD_STATUS_2.64.0_HU.md]

## Build állapot – v2.64.0 (Smart Context + Translation Quality)

### Elvégzett
- [x] `SmartContextTranslation.kt` – kontextus, kétértelműség, hangnem alternatívák (offline).
- [x] `TranslationQuality.kt` – összefogó minőségellenőrző (szám, név, tagadás, hossz, keveredés, ékezet, struktúra, ambiguitás).
- [x] `PlatinumIntelligenceActivity` – Next Wave státuszok frissítve: „Kész (core) · v2.64.0”.
- [x] `NextWaveToolsActivity` – Smart Context és Translation Quality bekötve az új core API-kra.
- [x] `app/build.gradle.kts` – versionCode 6400, versionName 2.64.0.
- [x] `CHANGELOG_V2.64.0_HU.md` és `NEXT_WAVE_V2.63_3.00_HU.md` frissítve.
- [x] ZIP-csomag újraépítve a teljes forrással.

### Nem elvégzett ebben a környezetben
- [ ] Gradle Kotlin fordítás és KSP ellenőrzés (DNS / services.gradle.org korlát).
- [ ] Unit tesztek futtatása.
- [ ] Android-eszközös teljes UI- és adatmegmaradási teszt.
- [ ] Infinity Global UI és Platinum Motion Engine teljes lezárása (v3.00-ra ütemezve).

### Ajánlott verziószámok
- versionCode: 6400
- versionName: 2.64.0


---

<!-- forrás: BUILD_STATUS_2.65.0_HU.md -->

## [BUILD_STATUS_2.65.0_HU.md]

## Build állapot – v2.65.0

### Elvégzett
- [x] HybridTranslationEngine (core)
- [x] PremiumMotion profilok és skálázás
- [x] InfinityGlobalUi tokenek és migrációs checklist
- [x] PlatinumIntelligenceActivity + NextWaveToolsActivity frissítve
- [x] versionCode 6500 / versionName 2.65.0
- [x] Dokumentáció (CHANGELOG, BUILD_STATUS, NEXT_WAVE)

### Nem elvégzett ebben a környezetben
- [ ] Gradle fordítás / unit tesztek / eszközteszt
- [ ] OnlineTranslator tényleges adapter-bekötés a hívó pipeline-ban
- [ ] Teljes Infinity Global UI View→Compose migráció (v3.00)


---

<!-- forrás: BUILD_STATUS_2.66.0_HU.md -->

## [BUILD_STATUS_2.66.0_HU.md]

## Build állapot – v2.66.0

- [x] SystemStatusSnapshot (core)
- [x] PlatinumGlobalDashboardActivity + Manifest
- [x] PlatinumIntelligenceActivity hub bekötés
- [x] versionCode 6600 / versionName 2.66.0
- [ ] Gradle fordítás / eszközteszt ebben a környezetben


---

<!-- forrás: BUILD_STATUS_2.67.0_HU.md -->

## [BUILD_STATUS_2.67.0_HU.md]

## Build állapot – v2.67.0
- [x] PerformanceRegressionSuite + unit test
- [x] NextWaveToolsActivity futtató UI
- [x] Hub státusz frissítve
- [x] versionCode 6700 / 2.67.0
- [ ] Gradle futtatás ebben a környezetben


---

<!-- forrás: BUILD_STATUS_3.00.0_HU.md -->

## [BUILD_STATUS_3.00.0_HU.md]

## Build állapot – v3.00.0 Diamond
- [x] DiamondIntegration checklist + evaluate()
- [x] Hub + Next Wave bekötés
- [x] InfinityGlobalUi v3.00 checklist
- [x] Unit test
- [x] versionCode 30000 / 3.00.0
- [ ] Eszközös QA / teljes View migráció / CI Gradle


---

<!-- forrás: BUILD_STATUS_3.01.0_HU.md -->

## [BUILD_STATUS_3.01.0_HU.md]

## Build állapot – v3.01.0
- [x] DiamondProcessTheater
- [x] PlatinumPanel integráció
- [x] version 3.01.0 / 30100
- [ ] Eszközös vizuális QA


---

<!-- forrás: BUILD_STATUS_3.02.0_HU.md -->

## [BUILD_STATUS_3.02.0_HU.md]

## Build állapot – v3.02.0
- [x] DiamondLiveTheater + DiamondLiveView
- [x] LiveTranslateActivity platinum bekötés
- [x] version 3.02.0 / 30200
- [ ] Eszközös vizuális QA


---

<!-- forrás: BUILD_STATUS_3.03.0_HU.md -->

## [BUILD_STATUS_3.03.0_HU.md]

## Build állapot – v3.03.0
- [x] MainActivity JobCard + DiamondProcessTheater
- [x] WaveView platinum színek
- [x] version 3.03.0 / 30300
- [ ] Eszközös vizuális QA


---

<!-- forrás: BUILD_STATUS_3.04.0_HU.md -->

## [BUILD_STATUS_3.04.0_HU.md]

## Build állapot – v3.04.0
- [x] JobFinishedCard + CompletionBurst a kezdőlapon
- [x] version 3.04.0 / 30400
- [ ] Eszközös vizuális QA


---

<!-- forrás: BUILD_STATUS_3.05.0_HU.md -->

## [BUILD_STATUS_3.05.0_HU.md]

## Build állapot – v3.05.0
- [x] DiamondExperiencePanel aktív állapot finomítás
- [x] Header v3.05 badge
- [x] version 3.05.0 / 30500


---

<!-- forrás: BUILD_STATUS_3.06.0_HU.md -->

## [BUILD_STATUS_3.06.0_HU.md]

## Build állapot – v3.06.0
- [x] motionProfile Prefs + PremiumMotion
- [x] Settings mozgásprofil gombok
- [x] LiveFullscreen DiamondLiveView
- [x] version 3.06.0 / 30600


---

<!-- forrás: BUILD_STATUS_3.10.0_HU.md -->

## [BUILD_STATUS_3.10.0_HU.md]

## Build állapot – v3.10.0 Ultimate
- [x] Cinema mode + lower-third + silence + haptics
- [x] Process/Live/Home integráció
- [x] version 3.10.0 / 31000
- [ ] Eszközös vizuális QA / Gradle CI


---

<!-- forrás: BUILD_STATUS_3.11.0_HU.md -->

## [BUILD_STATUS_3.11.0_HU.md]

## Build állapot – v3.11.0
- [x] Dual chronograph arcs in DiamondProcessTheater
- [x] Elapsed/remaining labels
- [x] version 3.11.0 / 31100


---

<!-- forrás: BUILD_STATUS_3.12.0_HU.md -->

## [BUILD_STATUS_3.12.0_HU.md]

## Build állapot – v3.12.0
- [x] Task portal navigation JobCard → FileSubtitle
- [x] Pipeline focus + pulse on portal entry
- [x] version 3.12.0 / 31200


---

<!-- forrás: BUILD_STATUS_3.13.0_HU.md -->

## [BUILD_STATUS_3.13.0_HU.md]

## Build állapot – v3.13.0
- [x] DiamondDepthStack
- [x] Process Theater parallax integráció
- [x] version 3.13.0 / 31300


---

<!-- forrás: BUILD_STATUS_4.0.0_HU.md -->

## [BUILD_STATUS_4.0.0_HU.md]

## Build állapot – v4.0.0 Platinum Infinity Diamond Ultimate Ecosystem

### Elkészült
- Új Ultimate Ecosystem képernyő és Intelligence Suite integráció.
- Diamond Intelligence: helyi CEFR önértékelési profil és mentés.
- Language Mastery: kompetenciafejlesztési útmutató és szintbecslés.
- Speech Intelligence: Android rendszer beszédfelismerő indítása, eredmény megjelenítése.
- Document Intelligence: SAF dokumentumkiválasztás, helyi szövegbeolvasás, szó- és olvasásiidő-becslés.
- Memory Universe: helyben mentett személyes kifejezés.
- Scenario Simulator: öt angol élethelyzet, válaszmező és gyakorlási számláló.
- Privacy Center: moduladatok törlése, helyi tárolás átlátható jelzése.
- Performance Engine: JVM memória pillanatfelvétel.
- Global Experience: meglévő Material 3 és Platinum komponensek használata.
- Achievement Universe: helyi gyakorlási mérföldkő és előrehaladás.
- Manifest-regisztráció, verzióemelés 4.0.0 / 40000.

### Képességhatárok
- A CEFR mutató önértékelési becslés, nem hivatalos nyelvvizsga.
- A beszédbevitel a telepített Android beszédfelismerő szolgáltatástól függ; nincs fonémaszintű kiejtésértékelés.
- A dokumentumfunkció a kiválasztott fájlból olvasható szöveg előnézetét készíti; PDF OCR és formázott DOCX-fordítás nincs ebben a hullámban.
- Nincs új felhő-AI, biometrikus zárolás vagy automatikus felhőszinkron.

### Ellenőrzés
- Forrás- és manifest-ellenőrzés elvégezve.
- Android Gradle build futtatása szükséges Android SDK/NDK-val rendelkező környezetben.


---

<!-- forrás: BUILD_STATUS_4.0.1_HU.md -->

## [BUILD_STATUS_4.0.1_HU.md]

## Build állapot – v4.0.1 Platinum Infinity Diamond Ultimate Ecosystem

### Integráció és javítások
- [x] UltimateEcosystemActivity regisztrálva az AndroidManifest.xml fájlban.
- [x] Közvetlen belépési pont az Intelligence Suite képernyőről.
- [x] A szituációs gyakorlás csak nem üres válasz után számít teljesített körnek.
- [x] A dokumentumválasztó olvasható szöveges formátumokra korlátozva (TXT, CSV, JSON, Markdown MIME-típusok).
- [x] Compose RowScope mérőszám-elrendezés javítva.
- [x] Verzió: 4.0.1 / versionCode 40100.

### A tíz pillér állapota
1. Diamond Intelligence Core – helyi CEFR önértékelési profil.
2. Platinum Language Mastery – kompetenciafejlesztési útmutató.
3. Infinity Speech Intelligence – Android rendszer beszédfelismerő indítása; nem fonémaszintű értékelés.
4. Diamond Document Intelligence – SAF-alapú szöveges fájlbeolvasás és szó/olvasásiidő-becslés.
5. Platinum Memory Universe – helyi kifejezésmentés.
6. Infinity Scenario Simulator – öt helyzet, válaszbevitel és gyakorlási számláló.
7. Platinum Privacy & Security – helyi tárolás átláthatósága és a modul saját adatainak törlése.
8. Diamond Performance Engine – JVM memória-pillanatfelvétel.
9. Platinum Global Experience – meglévő Material 3 / Platinum komponensek használata.
10. Infinity Achievement Universe – gyakorlási mérföldkövek.

### Korlátozások
- A CEFR pontszám önértékelési becslés, nem hivatalos nyelvvizsga.
- A beszédfelismerés az eszközön elérhető szolgáltatástól függ; fonéma-, akcentus- és intonációpontozás nincs.
- A PDF OCR, DOCX formázásmegőrzés, külső AI, biometrikus alkalmazászár és felhőszinkron nem része ennek a buildnek.
- A teljes Android build nem futott le: a Gradle Wrapper 8.9 disztribúció letöltéséhez internetkapcsolat szükséges, a buildkörnyezetben a services.gradle.org nem volt elérhető. Ezért sikeres APK-buildet nem állítunk.

### Ellenőrzés
- AndroidManifest.xml XML-szintaxis ellenőrizve.
- ZIP archívum integritás ellenőrizve.
- Forráskód- és integrációs módosítások ellenőrizve.


---

<!-- forrás: BUILD_STATUS_4.1.0_HU.md -->

## [BUILD_STATUS_4.1.0_HU.md]

## Build státusz – 4.1.0

- Forrásmódosítás: elkészült.
- Verzió: 4.1.0 (40200).
- Integráció: Ultimate Ecosystem ↔ Room Dictionary ↔ Review Schedule.
- Beszédértékelés: referencia/átirat WER-alapú összehasonlítása a meglévő PronunciationAssessment komponenssel.
- Adatvédelmi szövegek: pontosítva a rendszer beszédfelismerőjének lehetséges hálózati adatkezeléséről.
- ZIP-integritás: ellenőrzendő a csomagolás után.
- Gradle build: ebben a környezetben nem igazolt; a Gradle 8.9 disztribúció és Android SDK lokális elérhetősége hiányzik.


---

<!-- forrás: BUILD_STATUS_4.1.1_HU.md -->

## [BUILD_STATUS_4.1.1_HU.md]

## Build státusz – 4.1.1

- Forrásmódosítás: elkészült (lásd CHANGELOG_V4.1.1_HU.md).
- Verzió: 4.1.1 (40300).
- Gradle build és unit tesztek: nem futottak (nincs hálózati hozzáférés a Gradle disztribúcióhoz / Android SDK-hoz). Sikeres build nem állítható; a CI ellenőrzése szükséges.


---

<!-- forrás: BUILD_STATUS_4.2.0_HU.md -->

## [BUILD_STATUS_4.2.0_HU.md]

## Build státusz – 4.2.0
- core: fordul, 75/75 teszt zöld (helyi Kotlin-fordítóval ellenőrizve).
- app (Android-független részek): 18/18 teszt zöld.
- app (Android-függő módosítások) és Gradle/APK build: nem ellenőrzött itt; CI szükséges.


---

<!-- forrás: BUILD_STATUS_4.2.1_HU.md -->

## [BUILD_STATUS_4.2.1_HU.md]

## Build státusz – 4.2.1

### Elvégzett forrásmódosítások

- Release aláírás: debug kulcs fallback eltávolítva; saját kulcs nélkül unsigned release.
- API-kulcs tárolás: Android Keystore AES-GCM fail-closed viselkedés; plaintext fallback eltávolítva.
- Online beállítófelület: biztonságos mentési hiba visszajelzése.
- Egyedi végpontok: HTTPS vagy lokális/privát HTTP szabály, `EndpointPolicy` unit teszt hozzáadva.
- UI: Forest Graphite paletta; Compose prémium téma világos/sötét rendszerbeállítást követ.
- Verzió: `versionName=4.2.1`, `versionCode=40401`.
- Dokumentáció: teljes v5.0 cél-specifikáció, státuszmátrix, tesztterv, biztonsági és migrációs útmutató.

### Környezeti ellenőrzés

- Java: OpenJDK 21 elérhető.
- Kotlin CLI: 1.9.0 elérhető.
- Gradle wrapper: a projekt Gradle 8.9-et igényel.
- Android SDK/NDK: ebben a végrehajtási környezetben nem volt konfigurálva.
- A `./gradlew --version` megkísérelte a Gradle 8.9 letöltését, de a környezet DNS/hálózati korlátozása miatt `UnknownHostException: services.gradle.org` hibával leállt.

### Nem igazolt

- Gradle Kotlin DSL fordítás.
- `:core:test` és `:app:testDebugUnitTest` futtatása ebben a munkamenetben.
- Android APK és Wear APK build.
- Valós eszközteszt, kamera/dokumentum integráció és kiadás-aláírás.

A v4.2.0 dokumentált korábbi tesztállapota: core 75/75 és Android-független app tesztek 18/18 sikeresek voltak a korábbi ellenőrzési környezetben. Ezek nem tekinthetők a 4.2.1 módosítások újrafuttatott tesztjének.

### Következő kötelező ellenőrzés

```bash
./gradlew :core:test :app:testDebugUnitTest
./gradlew :app:assembleDebug :wear:assembleDebug
./gradlew :app:assembleRelease
```

A release build csak saját release kulccsal tekinthető terjesztésre késznek. A teljes v5.0 kiadási kaput az `IMPLEMENTATION_AND_TEST_PLAN_5.0_HU.md` tartalmazza.


---

<!-- forrás: BUILD_STATUS_4.2.2_HU.md -->

## [BUILD_STATUS_4.2.2_HU.md]

## Build státusz – 4.2.2

### Elkészült
- Verzió: `4.2.2` (`versionCode=40402`).
- EndpointPolicy RFC1918 határérték- és URL-ambiguitás tesztek bővítve.
- Statikus kiadási biztonsági ellenőrzés: `tools/verify_release_security.py`.
- GitHub Actions: statikus ellenőrzés, core/app unit tesztek, app debug, Wear OS debug és unsigned app release build.
- CI artifactok: app debug/release, Wear OS debug APK és tesztjelentések.

### Ebben a munkamenetben ténylegesen ellenőrizve
- ZIP CRC/integritás: sikeres.
- Statikus kiadási biztonsági ellenőrzés: sikeres.
- XML fájlok: 38/38 sikeresen parse-olva.
- Verzióadatok: `versionName=4.2.2`, `versionCode=40402` ellenőrizve.

### Nem igazolt
- Gradle/Kotlin fordítás és unit tesztek.
- APK-k létrehozása.
- Fizikai Android és Wear OS eszközteszt.

A helyi környezetben nincs Android SDK, és nincs gyorsítótárazott Gradle 8.9. A wrapper letöltése `UnknownHostException: services.gradle.org` hibával meghiúsult. Ezért a forráscsomag nem tekinthető kiadásra kész APK-nak.

### GitHub Actions parancsai
```bash
python tools/verify_release_security.py
./gradlew :core:test :app:testDebugUnitTest
./gradlew :app:assembleDebug :wear:assembleDebug
./gradlew :app:assembleRelease
```

A release kulcs nélküli release APK szándékosan aláíratlan. Terjesztéshez saját release keystore és sikeres készülékes ellenőrzés szükséges.


---

<!-- forrás: BUILD_STATUS_4.2.3_HU.md -->

## [BUILD_STATUS_4.2.3_HU.md]

## Build státusz – 4.2.3

### Elkészült
- Verzió: `4.2.3` (`versionCode=40403`).
- A `tools/verify_release_security.py` ellenőrzései megerősítve: release aláírási blokk, hiányos kulcsbeállítás, AES-GCM titoktárolás, endpoint-szabályzat, manifest exported komponensek, backup, FileProvider, QuickTile jogosultság és kulcsfájlok kizárása.
- A korábbi 4.2.2-es CI build- és tesztlépések változatlanul megmaradtak.

### Ebben a munkamenetben ellenőrizve
- Statikus biztonsági guardrail: sikeres.
- AndroidManifest XML parse: sikeres.
- Verzióadatok: `4.2.3` / `40403`.
- ZIP CRC/integritás: a végleges csomagolás után ellenőrizendő.

### Nem igazolt
- Gradle/Kotlin build és unit tesztek.
- App és Wear OS APK létrehozása.
- Fizikai eszközteszt, dinamikus biztonsági teszt és penetrációs teszt.

A helyi munkakörnyezetben korábban a Gradle wrapper letöltése hálózati DNS-hibán meghiúsult, és Android SDK sem volt elérhető. Ezért a csomag forráskód-csomag, nem igazolt telepíthető kiadás.


---

<!-- forrás: BUILD_STATUS_4.2.6_HU.md -->

## [BUILD_STATUS_4.2.6_HU.md]

## Build státusz – 4.2.6 (Platinum Intelligence 6.0 Engineering)

### Alkalmazásverzió
- versionName: **4.2.6**
- versionCode: **40406**
- applicationId: hu.angolmagyar.fordito
- minSdk 29 / targetSdk 35 / compileSdk 35
- NDK: 27.2.12479018

### Modulok
- `:app` – fő alkalmazás
- `:core` – platformfüggetlen logika (memória, minőség, kontextus, WER stb.)
- `:wear` – Wear OS

### Elvégzett ellenőrzések ebben a csomagban
| Ellenőrzés | Eredmény |
|---|---|
| `python tools/verify_release_security.py` | **PASS** |
| Forrásstruktúra / ZIP integritás | OK |
| Gradle wrapper jelenléte | OK |
| Android SDK / NDK / teljes Gradle build | Ebben a környezetben **nem futtatható** (nincs offline Gradle cache / SDK) |
| Unit tesztek futtatása | Forrásban megvannak; futtatás nem igazolt |
| APK előállítás | Nincs |
| Fizikai eszköz / offline / mikrofon / TTS | Nincs |

### Kiadási osztályozás
**FORRÁSSZINTŰ JAVÍTOTT MÉRNÖKI CSOMAG – NEM RELEASE**

A csomag buildelhetőnek tekinthető, amint egy teljes Android fejlesztői környezetben a CI workflow sikeresen lefut. Production release csak a teljes tesztterv és aláírt APK után.

### Következő kötelező lépések (helyi környezetben)
1. `./gradlew :core:test`
2. `./gradlew :app:testDebugUnitTest`
3. `./gradlew :app:assembleDebug :wear:assembleDebug`
4. (opcionális) aláírt release keystore-ral: `./gradlew :app:assembleRelease`
5. Valós eszköz: telepítés, frissítés 4.2.x-ről, offline mód, memória megőrzés Keystore-hiba szimulációval.


---

<!-- forrás: BUILD_STATUS_DIAMOND_V10_HU.md -->

## [BUILD_STATUS_DIAMOND_V10_HU.md]

## Diamond Blue UI v10 – build állapot

- Forráscsomag: elkészült.
- ZIP integritás: ellenőrzendő a kiadott archívumon.
- Kotlin/Android build: nem igazolt.
- Blokkoló környezeti hiba: a Gradle 8.9 disztribúció letöltése DNS-hibával leállt (`UnknownHostException: services.gradle.org`).
- A fordítási és beszédfelismerési forráskód nem módosult.


---

<!-- forrás: BUILD_STATUS_DIAMOND_V11_HU.md -->

## [BUILD_STATUS_DIAMOND_V11_HU.md]

## Diamond Blue UI v11 – build állapot

- Forráscsomag: elkészült.
- ZIP teszt: sikeres, `ZipFile.testzip()` nem talált sérült bejegyzést.
- Android Gradle build: nem igazolt.
- Környezeti akadály: a Gradle 8.9 letöltése DNS-hibával leállt (`UnknownHostException: services.gradle.org`).
- A fordítási és beszédfelismerési üzleti logika nem módosult.
- Készülékes vizuális és teljesítményteszt még szükséges.


---

<!-- forrás: BUILD_STATUS_HU.md -->

## [BUILD_STATUS_HU.md]

## Build- és tesztállapot – AngolMagyar v2.29.0

### Ellenőrizve
- Kódolvasás és kézi átnézés minden módosított fájlon; Gradle wrapper (8.9) a csomagban.

### NEM igazolt (nem volt Kotlin-fordító, Android SDK, Maven-elérés)
- Kotlin-fordítás, JUnit-futtatás, APK build, eszközteszt.
- Telefonon kipróbálandó: minőségellenőrző lap, célzott újrafelismerés (hosszú videón), éjszakai értesítés, időkorlát utáni folytatás, Keystore-os kulcs, mappa-engedélyes mentés release buildben.
- R8 (`-Pminify`) csak telefonos próba után használd (Vosk/JNA/ONNX/Whisper).

### Futtatás
```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug :wear:assembleDebug
```

### Gyémánt Edition – második fejlesztési kör
- Sikeres: a `ReviewIntelligence.kt` és `TranslationCheck.kt` önálló Kotlin-fordítása.
- Sikeres: célzott smoke teszt a rövid természetes válaszokra, üres sorokra és nulla hosszúságú időzítésre.
- Nem futtatható: teljes Gradle/JUnit és APK build, mert a Gradle 8.9 disztribúció nincs helyben, a hálózati letöltés DNS-hibával leállt.
- A képernyőn látható index továbbra is jelzésekből számított ellenőrzési mutató, nem ténylegesen mért beszédfelismerési pontosság.


### Update 11 – prémium terminológiai alapok
- Sikeres: `core/.../GlossaryGovernance.kt` önálló Kotlin-fordítása.
- Sikeres: izolált smoke teszt a globális/projekt-szótár prioritására, pontos hatás-előnézetre és TSV import/export körútra.
- Új JUnit tesztfájl: `GlossaryGovernanceTest.kt` (a teljes JUnit futás ebben a környezetben nincs igazolva).
- Új Platina kiemelőszín-téma és magyar prémium fejlesztési specifikáció.
- NEM igazolt: teljes Gradle build, Android APK, Wear APK, teljes tesztcsomag és készülékes UI teszt. A szótárgovernance API még nincs a meglévő Android UI-/tárolási-/fordítási pipeline-ba bekötve.


---

<!-- forrás: BUILD_STATUS_PLATINUM_8.0_PHASE7_FIX_HU.md -->

## [BUILD_STATUS_PLATINUM_8.0_PHASE7_FIX_HU.md]

## Build állapot – Platinum Intelligence 8.0 Phase 7 javítócsomag

**Javítás tárgya:** Kotlin IR backend `No mapping for symbol: reduced` hiba a `DiamondLiveTheater.kt` fájlban.

A `DiamondLiveView` többé nem zár be konstruktor-lokális Boolean változót a Compose `setContent` lambda-jába. A reduced-motion érték a kompozíción belül, a `LocalContext.current` alapján kerül lekérésre. A meglévő preferencia- és rendszerbeállítási logika változatlan.

A javítás részletes leírása: `COMPOSE_COMPILER_FIX_HU.md`.

**Nem állítjuk sikeresnek** az Android buildet vagy a teljes tesztcsomagot, amíg azok ténylegesen nem futottak le. A GitHub Actions workflow új statikus regresszióőrt futtat.


---

<!-- forrás: CHANGELOG_PLATINUM_7.0_ENGINEERING_HU.md -->

## [CHANGELOG_PLATINUM_7.0_ENGINEERING_HU.md]

## Változásnapló – Platinum Intelligence 7.0 Engineering csomag

### Hozzáadva
- `PLATINUM_INTELLIGENCE_7.0_MASTER_PLAN_HU.md` – mind a tíz prémium fejlesztési terület részletes célja, működési szabályai és fő fájljai.
- `PLATINUM_INTELLIGENCE_7.0_FILE_MATRIX_HU.md` – meglévő belépési pontok és célzott új fájlok.
- `PLATINUM_INTELLIGENCE_7.0_TEST_PLAN_HU.md` – funkcionális, offline, adatvédelmi, UI és release tesztmátrix.
- `PLATINUM_INTELLIGENCE_7.0_STATUS_HU.md` – pontos átadási státusz és nem igazolt tételek.

### Megőrizve
- Az eredeti 4.2.6 app/core/wear forrás és konfiguráció.
- `applicationId`, `versionName`, `versionCode`, SDK és meglévő adatkezelési határok.
- Az eredeti 6.0 biztonsági ellenőrző és release checklist.

### Fontos
Ez Engineering tervcsomag, nem teljesen implementált 7.0 alkalmazás. A build, tesztek és eszköztesztek nem állíthatók PASS-nak, ha nem futottak le.

### W1/W2 folytatás – tényleges core implementáció
- `core/.../PlatinumWorkflow.kt`: offline-first workflow állapotgép, definíció-validáció, DAG ciklusellenőrzés, capability/network gate, start/complete/fail/retry/cancel.
- `core/.../TranslationWorkspace.kt`: stílusváltozatok, append-only revíziótár, visszaállítás új revízióként, token diff és minőség-audit adapter.
- `PlatinumWorkflowTest.kt` és `TranslationWorkspaceTest.kt`: 11 új unit teszteset.
- Core Kotlin compile és smoke harness: PASS. A Gradle/JUnit/Android build környezeti korlát miatt továbbra sem igazolt.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE2_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE2_HU.md]

## Platinum Intelligence 8.0 – Phase 2 változásnapló

### Hozzáadva
- Stream-alapú SHA-256 és méretellenőrző modellintegritás-kapu.
- Offline képességmátrix a telepített és ellenőrzött helyi komponensek megkülönböztetésére.
- 9 új core unit teszteset.
- Fájlszintű specifikáció és validációs korlátok.

### Megőrizve
- Android 4.2.6 / versionCode 40406, applicationId és SDK-beállítások.
- `:app`, `:core`, `:wear` modulok.
- Offline/online útvonalak és meglévő adatkezelési, titkosítási és permission határok.

### Státusz
Core forrás implementálva. Gradle/JUnit, Android build, modellletöltési adapter és fizikai eszközteszt ebben a környezetben nem igazolt.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE3_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE3_HU.md]

## Changelog – Platinum Intelligence 8.0 Phase 3

- ZIP kibontási útvonalak és archívum-erőforrások központi ellenőrzése.
- Kibontási méret-, bejegyzésszám- és tömörítési aránykorlátok.
- Modelltelepítés staging könyvtárral és korábbi verziót védő visszaállítási útvonallal.
- Új ArchiveSafetyPolicy unit tesztek.
- A teljes Gradle/Android validáció a hálózati korlátozás miatt nem futott le.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE4_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE4_HU.md]

## Changelog – Platinum Intelligence 8.0 Phase 4

- Offline fordítási invariáns-audit: szám- és tagadáseltérés figyelmeztetése.
- Adaptív, helyi ismétlési ütemező SM-2 ihletésű szabályokkal.
- Határérték-kezelés és determinisztikus egységtesztek.
- Nem történt automatikus UI/adatbázis bekötés, hálózati adatküldés vagy meglévő funkció eltávolítása.
- Validációs korlát: Gradle 8.9 letöltése DNS-hiba miatt sikertelen; JUnit/Android build nem futott.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE5_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE5_HU.md]

## Phase 5 változásnapló
- Offline terminológiai auditmotor bevezetése.
- Offline fordítási memória lexikai rangsorolójának bevezetése.
- 8 célzott JUnit teszt hozzáadása.
- Magyar integrációs és korlátozási dokumentáció.
- Nincs hálózati függőség, automatikus fordítás-átírás vagy adatbázis-sémamódosítás.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE6_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE6_HU.md]

## Changelog – Platinum Intelligence 8.0 Phase 6

- Új közös `OfflineIntelligencePipeline` API a három offline intelligencia-komponenshez.
- Új Room-alapú `OfflineIntelligenceRepository` a meglévő szótár-, memória- és ismétlési DAO-khoz.
- IO dispatcher, bemeneti kulcshossz-ellenőrzés és lekérdezési limitek.
- 4 új core JUnit teszt.
- Room séma és verzió változatlan; migráció nem szükséges.
- A fordítások automatikus módosítása nem történik.


---

<!-- forrás: CHANGELOG_PLATINUM_8.0_PHASE7_HU.md -->

## [CHANGELOG_PLATINUM_8.0_PHASE7_HU.md]

## Phase 7 változásnapló

- Új, felhasználó által elérhető Offline Intelligence Center Compose képernyő.
- Offline fordításminőség-ellenőrzés és terminológiai figyelmeztetések megjelenítése.
- Helyi fordítási memória lexikai keresése és rangsorolt találatok.
- Helyi szótár-/memória-/ismétlési darabszámok és esedékes ismétlések áttekintése.
- Navigáció és belső, nem exportált Activity regisztráció.
- Korlátozott szótári audit-lekérdezés a memóriahasználat mérséklésére.
- Room séma, verzió, migrációk és jogosultságok változatlanok.


---

<!-- forrás: CHANGELOG_V19_HU.md -->

## [CHANGELOG_V19_HU.md]

## v19 / 2.49.0 — Infinity Sovereign Edition

- Öt választható Infinity Luxury paletta.
- Új `LuxuryPalettes` közös szín-token készlet.
- A Compose prémium kártyák a kiválasztott palettához igazítják a felületi gradienst, a keretet és a fényhatást.
- A választás tartósan mentődik.
- Megőrizve a korábbi funkciók és a csökkentett animációs mód beállítása.
- Részletes magyar fejlesztési és build-megjegyzések: `PLATINUM_INFINITY_SOVEREIGN_V19_HU.md`.


---

<!-- forrás: CHANGELOG_V2.58.0_HU.md -->

## [CHANGELOG_V2.58.0_HU.md]

## Változásnapló – v2.58.0

- Tartós, Room-alapú saját szótár bevezetése.
- Biztonságos, adatvesztés nélküli Room 1 → 2 migráció a fordítási memória megtartásával.
- CSV import/export Android dokumentumválasztóval.
- Importált szótárbejegyzések bekötése az offline keresőbe.
- Angol beszédfelismerés indítása Android rendszer-szolgáltatással.
- A beszédfelismerési átirat automatikus betöltése a meglévő WER ellenőrzőbe.
- Verzióemelés 2.58.0 / 5800.


---

<!-- forrás: CHANGELOG_V2.59.0_HU.md -->

## [CHANGELOG_V2.59.0_HU.md]

## Változásnapló – v2.59.0

- Room adatbázis migráció 2 → 3: ismétlési ütemezés külön táblában, a meglévő szótár- és fordítási adatok megőrzésével.
- SM-2 ihletésű, determinisztikus szókártya-ütemező (Újra / Nehéz / Jó / Könnyű értékelés).
- Új Intelligens ismétlő képernyő a saját szótár esedékes szavaival.
- A szókártyák és az ismétlési állapot helyben tárolódik.
- Új egységtesztek az ütemezési szabályokhoz.
- Intelligence Suite központi menüjéből elérhető új tanulási modul.
- Verzió: 2.59.0 / 5900.


---

<!-- forrás: CHANGELOG_V2.60.0_HU.md -->

## [CHANGELOG_V2.60.0_HU.md]

## Változásnapló – v2.60.0

### Infinity Backup Center
- Verziózott, JSON-alapú biztonsági mentési formátum.
- Saját szótár, fordítási memória és ismétlési ütemezés exportja.
- Android Storage Access Framework: a felhasználó választja ki a mentés helyét és a visszaállítandó fájlt.
- Importálás előtti formátum-, verzió-, méret- és rekordvalidáció.
- Tranzakciós visszaállítás: a szótár, fordítási memória és ismétlési ütemezés együtt cserélődik.
- Új Backup Center képernyő az Intelligence Suite központban.
- Kerekítési és formátumtesztek a backup codec-hez.

### Verzió
- versionCode: 6000
- versionName: 2.60.0

### Korlátok
- A mentés jelenleg a három Room-adatkört tartalmazza; médiafájlokat, letöltött modelleket, API-kulcsokat és alkalmazásbeállításokat nem.
- A visszaállítás felülírja a három mentett adatkört; előtte javasolt aktuális mentést exportálni.
- Android build és eszközteszt csak a megfelelő Gradle/SDK környezetben igazolható.


---

<!-- forrás: CHANGELOG_V2.61.0_HU.md -->

## [CHANGELOG_V2.61.0_HU.md]

## v2.61.0 – Secure Backup Diamond

- Titkosított `.pibackup` export AES-256-GCM-mel.
- PBKDF2-HMAC-SHA256 alapú jelszóból kulcsszármaztatás.
- Visszaállítás előtti adat-előnézet.
- Titkosított mentés tesztjei.
- Verziófrissítés 2.61.0-ra.
- A Gradle build hálózati korlátozás miatt nem volt futtatható.


---

<!-- forrás: CHANGELOG_V2.62.0_HU.md -->

## [CHANGELOG_V2.62.0_HU.md]

## v2.62.0 – Automatic Diamond Backup

- Napi automatikus biztonsági mentés WorkManager ütemezéssel.
- Heti automatikus biztonsági mentés WorkManager ütemezéssel.
- Eszközön belüli AES-256-GCM titkosítás, nem exportálható Android Keystore kulccsal.
- Offline működés; akkumulátorkímélő feltétel.
- Egyedi WorkManager feladatok, bekapcsolás/kikapcsolás és állapotjelzés a Backup Centerben.
- Automatikus mentési rotáció: legfeljebb 14 fájl marad meg.
- Verziófrissítés: versionCode 6200 / versionName 2.62.0.

### Biztonsági megjegyzés
Az automatikus mentés kulcsa az adott Android-eszköz Keystore-ához kötött. A fájl másik eszközön önmagában nem állítható vissza. Eszközváltáshoz továbbra is a jelszóval védett, hordozható `.pibackup` exportot használd.

### Javítási kör – teljes csomag
- Az automatikus mentés adatbázis-olvasása egyetlen Room-tranzakcióban történik.
- A mentés fájlba írása atomi: előbb ideiglenes fájl készül, majd fsync és végleges átnevezés következik.
- Az AES-GCM fejléc AAD-ként is hitelesített.
- A titkosítatlan és titkosított byte pufferek a feldolgozás után törlésre kerülnek.
- A rotáció kizárólag a kész automatikus mentésfájlokat érinti.
- A mentés csak megfelelő akkumulátor- és tárhelyállapot mellett indul.


---

<!-- forrás: CHANGELOG_V2.63.0_HU.md -->

## [CHANGELOG_V2.63.0_HU.md]

## v2.63.0 – Learning Analytics Diamond

### Új funkciók
- Új, Platinum Intelligence Suite-ból megnyitható Learning Analytics Diamond áttekintő.
- Napi aktivitási cél, állítható 1–500 közötti célszámmal.
- 7 napos aktivitási trend és 30 napos összesített mutatók.
- Gyakorlási pontosság, aktív napok, keresések, gyakorlások és ismétlések számlálása.
- Helyi, adatvédelmi szempontból minimalizált tárolás: csak dátumonkénti számlálók, nincs begépelt szó vagy mondat eltárolva.
- A szókincstár és az Intelligens ismétlő gyakorlási eredményei automatikusan frissítik az analitikát.

### Verzió
- Android versionCode: 6300
- Android versionName: 2.63.0

### Korlátozások és ellenőrzés
- A számlálók az új analitika bekapcsolásától gyűlnek; korábbi aktivitás nem rekonstruálható.
- A fordítási keresések minden belépési pontjáról történő teljes eseménybekötés további iterációban bővíthető.
- A Gradle/Kotlin fordítás ebben a környezetben nem futott le: a Gradle 8.9 disztribúció letöltéséhez szükséges DNS-feloldás sikertelen volt.
- ZIP-integritás ellenőrizhető; Android-eszközös UI- és adatmegmaradási teszt kiadás előtt szükséges.


---

<!-- forrás: CHANGELOG_V2.64.0_HU.md -->

## [CHANGELOG_V2.64.0_HU.md]

## v2.64.0 – Smart Context + Translation Quality (hátralévő hullám)

### Cél
A „Következő fejlesztési hullám” képernyőn még „Fejlesztendő” státuszú két elem teljes implementációja a core modulban, valamint a részben kész elemek dokumentációs lezárása.

### Új / befejezett elemek

#### Smart Context Translation (korábban: Fejlesztendő)
- Új `SmartContextTranslation` objektum a core modulban.
- Kontextus-, kétértelműség- és hangnem-alapú alternatívák (offline, szabályalapú).
- Gyakori kétértelmű angol szavak (bank, light, right, set, run, charge, match, check, order…) felismerése.
- Hangnem-érzékelés: semleges / formális / informális / műszaki / barátságos.
- Soha nem írja felül automatikusan a fordítást – csak javaslatokat ad.
- `hasAmbiguity()` gyors ellenőrzés a minőségmodul számára.

#### Translation Quality (korábban: Fejlesztendő)
- Új `TranslationQuality` objektum, amely összefogja:
  - a meglévő `TranslationCheck` (szám, név, tagadás),
  - a `TranslationQualityAudit` hossz-arány logikáját,
  - új heurisztikákat: angol maradványszavak, ékezet-hiány, kérdőjel-struktúra, ambiguitás-jelzés.
- Súlyozott figyelmeztetések (CRITICAL / WARNING / REVIEW / INFO).
- Heurisztikus tájékoztató pontszám (0–100), nem AI-pontszám.
- `summaryLine()` a felületi megjelenítéshez.

#### Infinity Global UI & Platinum Motion Engine
- Státusz: részben kész (a korábbi v2.60–v2.63 UI-tokenek és animációs előkészületek megmaradtak).
- A teljes paletta-migráció és egységes Motion Engine a v3.00 Diamond integráció keretében zárul.

### Verzió
- Ajánlott Android versionCode: 6400
- Ajánlott versionName: 2.64.0

### Korlátozások
- A Smart Context lista nem teljes lexikai adatbázis – csak a leggyakoribb kétértelműségeket fedi.
- A Translation Quality nem helyettesít emberi lektorálást és nem ad valószínűségi pontosságot.
- A main app UI (PlatinumIntelligenceActivity / NextWave képernyő) a core-t használja; a felületi bekötés a teljes app-modulban történik.
- Gradle/Kotlin fordítás ebben a környezetben a korábbi DNS-korlát miatt nem futott le.

### Ellenőrzési javaslat
1. `SmartContextTranslation.suggest("Please check the bank balance and the light on the right.")`
2. `TranslationQuality.analyze(source, target)` – üres fordítás, számeltérés, angol maradvány.
3. A Next Wave képernyőn a két elem státuszát „Kész” / „Részben kész” értékre állítani a UI oldalon.


---

<!-- forrás: CHANGELOG_V2.65.0_HU.md -->

## [CHANGELOG_V2.65.0_HU.md]

## v2.65.0 – Hybrid Translation Engine + UI/Motion előrelépés

### Új / továbbfejlesztett elemek

#### Hybrid Translation Engine (core) – Kész
- Új `HybridTranslationEngine` objektum.
- Módok: OFFLINE_ONLY, PREFER_OFFLINE, PREFER_ONLINE, ONLINE_ONLY.
- Adatvédelmi kapcsolók: allowNetwork, redactLogs, minimizePayload.
- Egységes `Result` / `SegmentResult` formátum, forrásmotor jelöléssel (OFFLINE / ONLINE / FALLBACK_*).
- Szótár-előtöltés exact match-el; offline és online adapter interfészek.
- A meglévő `OnlineTranslator` adapterként csatlakoztatható.

#### Platinum Motion Engine – Részben kész (előrelépés)
- `PremiumMotion` bővítve: Profile (FULL / SUBTLE / REDUCED / NONE), scale(), allowLoops(), statusLabel().
- Automatikus animációcsökkentés app- és rendszerbeállítás alapján.

#### Infinity Global UI – Részben kész (előrelépés)
- Új `InfinityGlobalUi`: központi paletták (Platinum Dark, Diamond Blue), migrációs checklist és progressLabel().
- A teljes View→Compose migráció a v3.00-ra marad.

#### UI
- `PlatinumIntelligenceActivity`: Hybrid elem felvéve „Kész (core) · v2.65.0”; Motion/Global státuszok frissítve.
- `NextWaveToolsActivity`: Hybrid és Motion/Global kártyák frissítve.

### Verzió
- versionCode: 6500
- versionName: 2.65.0


---

<!-- forrás: CHANGELOG_V2.66.0_HU.md -->

## [CHANGELOG_V2.66.0_HU.md]

## v2.66.0 – Platinum Global Dashboard

### Új
- `SystemStatusSnapshot` (core): egységes modul-/rendszerállapot modell, gyorsművelet-sablonok.
- `PlatinumGlobalDashboardActivity`: Compose állapotközpont – modulok szintjei, összefoglaló, gyorsgombok (Diagnosztika, Modellek, Mentés, Next Wave, Adatvédelem, Beállítások).
- Manifest regisztráció + bekötés a Platinum Intelligence Suite hubba („Új · v2.66.0”).

### Verzió
- versionCode: 6600
- versionName: 2.66.0


---

<!-- forrás: CHANGELOG_V2.67.0_HU.md -->

## [CHANGELOG_V2.67.0_HU.md]

## v2.67.0 – Performance & Regression Suite

### Új
- `PerformanceRegressionSuite` (core): latency mérések, heap, beépített regressziós készlet (Smart Context, Translation Quality, Hybrid, Snapshot, TranslationCheck).
- `PerformanceRegressionSuiteTest` unit tesztek.
- Next Wave Tools: „Regressziós készlet futtatása” gomb és eredménykijelzés.
- Intelligence hub: Performance & Regression Suite státusz „Kész (core) · v2.67.0”.

### Verzió
- versionCode: 6700
- versionName: 2.67.0


---

<!-- forrás: CHANGELOG_V20_HU.md -->

## [CHANGELOG_V20_HU.md]

## v20 / 2.50.0 — Infinity Sovereign Global Theme

- Az öt Infinity Luxury paletta a teljes Compose Material 3 színsémát vezérli.
- A Platinum téma kikapcsolásakor megmarad a Blue Cinematic / rendszerfüggő téma.
- OLED fekete mód támogatása megmaradt.
- Csökkentett animáció esetén a kártyabelépési animáció is kikapcsol.
- Verzióemelés: 2.50.0 / 5000.


---

<!-- forrás: CHANGELOG_V21_HU.md -->

## [CHANGELOG_V21_HU.md]

## v21 / 2.51.0 — Infinity Theme Live Refresh

- A fő Compose-felület a Beállításokból visszatérve automatikusan újraalkalmazza a módosított Luxury palettát, Platinum kapcsolót és OLED fekete módot.
- A téma-összehasonlítási állapotot az újraindítás előtt frissíti, elkerülve az ismételt `recreate()` hívásokat.
- A Beállítások témaleírása pontosítva: a paletta a Compose Material 3 színsémát vezérli; a klasszikus View-képernyők külön témázása nem változik.
- Verzióemelés: 2.51.0 / versionCode 5100.

### Ellenőrzés

A forráscsomag módosítva és ZIP-ként ellenőrizve. Android Gradle buildet csak olyan környezetben lehet véglegesíteni, ahol a Gradle wrapper és a szükséges Android függőségek elérhetők.


---

<!-- forrás: CHANGELOG_V22_HU.md -->

## [CHANGELOG_V22_HU.md]

## Változásnapló — v22 / 2.52.0

- Új, három színt megjelenítő paletta-előnézetek a Beállításokban.
- Jobb érinthetőség a palettaválasztóknál.
- Akadálymentességi tartalomleírás a színpaletta-opciókhoz.
- Verziófrissítés 2.52.0-ra.
- Nem állítjuk teszteltnek az APK-t: a buildet külön kell futtatni.


---

<!-- forrás: CHANGELOG_V23_HU.md -->

## [CHANGELOG_V23_HU.md]

## Változásnapló — v23 Infinity Intelligence Suite

- Új központi Intelligence Suite képernyő a főoldalról.
- Közvetlen navigáció a meglévő fordítási, szókincstár-, átirat-, modell-, adatvédelmi és diagnosztikai eszközökhöz.
- A központban a részleges és tervezett képességek egyértelmű státuszt kapnak.
- A kiválasztott Infinity Luxury paletta a régi View-képernyők közös színsegédjére is kiterjed.
- Verzió: 2.53.0 (5300).
- A Gradle 8.9 letöltésének hálózati hibája miatt az Android build eredménye nem igazolt.


---

<!-- forrás: CHANGELOG_V24_HU.md -->

## [CHANGELOG_V24_HU.md]

## Platinum Ultra Extreme v24 – CI fordítási hibajavítás

### Javítások
- `PlatinumDial.kt`: hozzáadva a Compose `getValue` delegált állapotolvasáshoz, így az `animateFloatAsState` eredménye helyesen használható `by` szintaxissal.
- `PlatinumProgressBar.kt`: a `PlatinumProgressBar` függvény `@Composable` annotációt kapott.
- Eltávolítva a nem támogatott `Role.ProgressBar` hivatkozás; az akadálymentesítési állapotot a `ProgressBarRangeInfo` és a `contentDescription` továbbra is közli.
- Verzió: 2.54.0, versionCode 5400.

### Ellenőrzési megjegyzés
A javítás a megadott GitHub Actions fordítási napló konkrét Kotlin-hibáira készült. Teljes Gradle build és unit teszt csak a GitHub Actions futtatásával igazolható; a csomag önmagában nem tekinthető sikeresen lefordított APK-nak.


---

<!-- forrás: CHANGELOG_V3.00.0_HU.md -->

## [CHANGELOG_V3.00.0_HU.md]

## v3.00.0 – Teljes Diamond integráció

### Cél
A 2.63–2.67 hullám moduljainak összefogása kiadási kapuval, közös navigáció/tokenek dokumentálásával és regressziós ellenőrzéssel.

### Új
- `DiamondIntegration` (core): kiadási checklist, kapuállapot (OPEN/PARTIAL/CLOSED), modul-térkép, opcionális regresszió.
- Next Wave: „Diamond kapu értékelése” gomb.
- Intelligence hub: Diamond Integration Gate bejegyzés.
- InfinityGlobalUi migrációs checklist bővítve (v3.00).
- Unit test: `DiamondIntegrationTest`.

### Még nem zárult (tudatos)
- Teljes klasszikus View → Compose migráció
- Fizikai eszközös QA
- Reprodukálható Gradle CI ebben a környezetben

### Verzió
- versionCode: 30000
- versionName: 3.00.0


---

<!-- forrás: CHANGELOG_V3.01.0_HU.md -->

## [CHANGELOG_V3.01.0_HU.md]

## v3.01.0 – Diamond Process Theater (prémium folyamat UI)

### Új
- `DiamondProcessTheater`: részletgazdag, animált folyamatvizualizáció feldolgozás közben
  - aktuális művelet „hős” panele orbit progress gyűrűvel és mikro progress sávval
  - lépés-energia sín (flow particle az aktív szakaszon)
  - lépésenkénti státuszsorok (kész / fut / vár / hiba)
  - élő felismerés és fordítás szövegpanel
  - meta chipek (szegmens, fájl, összes %, fordított sorok)
  - teljes `reduceMotion` támogatás
- Bekötés a `PlatinumPanel` feldolgozó kártyába (CinematicPipelineView / platinum téma)

### Verzió
- versionCode: 30100
- versionName: 3.01.0


---

<!-- forrás: CHANGELOG_V3.02.0_HU.md -->

## [CHANGELOG_V3.02.0_HU.md]

## v3.02.0 – Diamond Live Theater (élő fordítás UI)

### Új
- `DiamondLiveTheater` / `DiamondLiveView`: prémium élő folyamat-színház
  - fázisok: Készenlét → Figyelés → Felismerés → Fordítás (Szünet)
  - orbit progress orb valós hangszinttel
  - 56 oszlopos spektrum (AppState.level történet, nem kitalált hullám)
  - fázis-lépés chipek animált kiemeléssel
  - élő EN/HU szövegcsík
  - reduceMotion támogatás
- Élő fordítás képernyő (Platinum téma): a sima szintmérő helyett Diamond Live Theater

### Verzió
- versionCode: 30200
- versionName: 3.02.0


---

<!-- forrás: CHANGELOG_V3.03.0_HU.md -->

## [CHANGELOG_V3.03.0_HU.md]

## v3.03.0 – Kezdőlap aktív feladat + WaveView Diamond

### Új / továbbfejlesztett
- **Kezdőlap JobCard**: Diamond stílusú aktív-feladat kártya
  - valós `SrtJobAdapter` lépésállapot
  - beágyazott `DiamondProcessTheater` (aktuális művelet, energia-sín, élő jel)
  - tartalék cinematic stage rail, ha még nincs lépéslista
- **WaveView** (felirat-feldolgozás): Platinum/Diamond színpaletta
  - kész = smaragd, aktív ablak = pezsgőarany↔jégkék pulzus, várakozó = acélszürke

### Verzió
- versionCode: 30300
- versionName: 3.03.0


---

<!-- forrás: CHANGELOG_V3.04.0_HU.md -->

## [CHANGELOG_V3.04.0_HU.md]

## v3.04.0 – Kezdőlap befejezés-animáció

### Új
- **JobFinishedCard** a kezdőlapon sikeres felirat-feldolgozás után
  - „DIAMOND · KÉSZ” státusz
  - CompletionBurst (gyűrű + szikrák) – reduceMotion esetén kihagyva
  - üzenet a SrtJob-ból, koppintás az eredményre, automatikus elrejtés ~6.5 s
- Futó feladat → kész átmenet detektálása (hiba esetén nem jelenik meg)

### Verzió
- versionCode: 30400
- versionName: 3.04.0


---

<!-- forrás: CHANGELOG_V3.05.0_HU.md -->

## [CHANGELOG_V3.05.0_HU.md]

## v3.05.0 – Diamond Experience finomítás

### Változások
- Diamond Experience panel: gyorsabb orbit aktív folyamatnál, részletesebb státuszszövegek („Folyamat-színház aktív”, „SZÍNHÁZ FUT”).
- Kezdőlap fejléc: **v3.05** verziójelvény.
- Korábbi prémium animációk (Process / Live Theater, JobFinished, WaveView) változatlanul elérhetők.

### Verzió
- versionCode: 30500
- versionName: 3.05.0


---

<!-- forrás: CHANGELOG_V3.06.0_HU.md -->

## [CHANGELOG_V3.06.0_HU.md]

## v3.06.0 – Mozgásprofil + élő teljes képernyő

### Új
- **Mozgásprofil** a Beállításokban: Teljes / Diszkrét / Minimal / Ki
  - `Prefs.motionProfile` + `PremiumMotion.profile()` bekötés
  - „Ki” bekapcsolja a csökkentett animáció kapcsolót is
- **LiveFullscreen**: Platinum témában felül **Diamond Live Theater** sáv

### Verzió
- versionCode: 30600
- versionName: 3.06.0


---

<!-- forrás: CHANGELOG_V3.10.0_HU.md -->

## [CHANGELOG_V3.10.0_HU.md]

## v3.10.0 – Diamond Cinema Ultimate (teljes javított csomag)

### Új / összevont
- Diamond Cinema Mode (Prefs + Beállítások + PremiumMotion.cinemaEnabled)
- Broadcast lower-third (`DiamondBroadcastChrome`)
- Live Theater: silence drama, lower-third, fázis-haptics
- Process Theater: motor meta chip
- JobFinished End Card ceremony szöveg
- Dokumentum: DIAMOND_CINEMA_ULTIMATE_V3.10_HU.md

### Tartalmazza a 3.01–3.06 prémium UI-t is
Process/Live Theater, JobCard, WaveView Diamond, Motion profil, Fullscreen sáv, Experience panel.

### Verzió
- versionCode: 31000
- versionName: 3.10.0


---

<!-- forrás: CHANGELOG_V3.11.0_HU.md -->

## [CHANGELOG_V3.11.0_HU.md]

## v3.11.0 – Chronograph cinematic

### Új
- Process Theater hős panel: **kettős chronograph**
  - külső ív = összes folyamat %
  - belső ív = aktuális lépés progress
- Eltelt / becsült hátralévő idő a hős kártyán
- Orbit + pulse továbbra is Cinema / reduceMotion szerint

### Verzió
- versionCode: 31100
- versionName: 3.11.0


---

<!-- forrás: CHANGELOG_V3.12.0_HU.md -->

## [CHANGELOG_V3.12.0_HU.md]

## v3.12.0 – Task Portal (JobCard → felirat folyamat)

### Új
- Kezdőlap **JobCard / JobFinished**: `NavTransitions` cinematic belépés a felirat képernyőre
- `FileSubtitleActivity.EXTRA_FROM_PORTAL`: folyamat panelre fókusz + rövid alpha pulse
- Pipeline `transitionName` a későbbi shared-element bővítéshez
- UI felirat: „Task portal · részletes folyamat”

### Verzió
- versionCode: 31200
- versionName: 3.12.0


---

<!-- forrás: CHANGELOG_V3.13.0_HU.md -->

## [CHANGELOG_V3.13.0_HU.md]

## v3.13.0 – Depth / Parallax stack

### Új
- `DiamondDepthStack`: háromrétegű mélység-háttér (ónix + aurora parallax + élfény)
- Process Theater erre épül Cinema Mode + aktív folyamat esetén
- reduceMotion / nem-cinema: statikus háttér

### Verzió
- versionCode: 31300
- versionName: 3.13.0


---

<!-- forrás: CHANGELOG_V4.0.0_HU.md -->

## [CHANGELOG_V4.0.0_HU.md]

## v4.0.0 – Platinum Infinity Diamond Ultimate Ecosystem

A v3.13.0 DepthStack alapra épülő, tíz pillért összefogó Ultimate tanulási központ.

- Új Ultimate Ecosystem képernyő és fő Intelligence Suite belépési pont.
- Offline-first tanulási profil és CEFR önértékelési becslés.
- Android Speech Recognizer integráció.
- SAF dokumentumválasztás és szöveges dokumentum-előnézet.
- Helyi kifejezésmemória.
- Öt helyzetgyakorlat és helyi teljesítményszámláló.
- Adatvédelmi átláthatóság és moduladat-törlés.
- JVM memória pillanatfelvétel és achievement előrehaladás.
- Verzió: 4.0.0 (40000).


---

<!-- forrás: CHANGELOG_V4.0.1_HU.md -->

## [CHANGELOG_V4.0.1_HU.md]

## v4.0.1 – Ultimate Ecosystem integrációs javítás

- Ultimate Ecosystem Activity manifest-regisztrációja.
- Közvetlen indítóelem a Platinum Intelligence Suite-ban.
- Üres válasz nem rögzíthető teljesített szituációs gyakorlatként.
- Dokumentumbeolvasás csak szöveges MIME-típusokra korlátozva.
- Compose RowScope Metric elrendezési javítás.
- Verzió: 4.0.1 (40100).

A buildet a Gradle 8.9 disztribúció hálózati elérhetetlensége miatt nem lehetett végrehajtani.


---

<!-- forrás: CHANGELOG_V4.1.0_EN.md -->

## [CHANGELOG_V4.1.0_EN.md]

## v4.1.0 – Memory & Speech Integration Wave

- Connects the Ultimate Memory panel to the shared Room dictionary.
- Newly saved phrases are automatically added to the existing spaced-repetition schedule.
- Shows dictionary size and due review count.
- Adds reference-versus-transcript word-error-rate feedback to the speech practice panel.
- Clarifies that transcript similarity is not phonetic pronunciation scoring and that Android speech recognition may use network services.
- Version: 4.1.0 (40200).


---

<!-- forrás: CHANGELOG_V4.1.0_HU.md -->

## [CHANGELOG_V4.1.0_HU.md]

## v4.1.0 – Memory & Speech Integration Wave

### Új funkciók
- A Platinum Memory Universe már a közös Room-szótárba ment: angol kifejezés, magyar jelentés és opcionális példamondat.
- Az új szótári elem automatikusan bekerül a meglévő ismétlési ütemezőbe, ha még nincs hozzá ütemezés.
- A képernyő megjeleníti a szótár elemszámát és az esedékes ismétlések számát.
- Az Infinity Speech Intelligence referencia-mondat és a rendszer által felismert átirat között WER-alapú szövegegyezési mutatót számol, valamint megmutatja a cserék, hiányok és többletek számát.

### Pontossági és adatvédelmi pontosítások
- A beszédértékelés átirat-alapú szöveg-összehasonlítás; nem állít fonéma-, akcentus- vagy intonációelemzést.
- A rendszer beszédfelismerő szolgáltatása hálózatot használhat; a szolgáltató adatkezelése érvényes rá.
- A szótár és az ismétlési ütemezés az alkalmazás helyi Room-adatbázisában marad.

### Verzió
- versionName: 4.1.0
- versionCode: 40200

### Ellenőrzés
- ZIP-integritás és forrásellenőrzés elvégzendő.
- Android Gradle build csak a Gradle 8.9 és az Android SDK elérhetőségével futtatható; build-sikert nem állítunk ellenőrzés nélkül.


---

<!-- forrás: CHANGELOG_V4.1.1_HU.md -->

## [CHANGELOG_V4.1.1_HU.md]

## v4.1.1 – Stabilizáló javítócsomag (Memory & Speech Integration)

### Javítások
- Beszédfelismerés: az eredményt csak RESULT_OK esetén fogadja el; megszakított felismerés után nem marad régi átirat a képernyőn.
- Kiejtés/WER: a görbe aposztróf (don’t) azonos a közönséges aposztróffal; üres referencia/átirat nem okoz hibát.
- Dokumentumbeolvasás: legfeljebb 200 000 karaktert olvas be (nem a teljes fájlt a memóriába); csonkolásról státuszüzenet jelzi.
- Szótármentés: az angol kifejezés szóközei normalizáltak, a kulcs Locale.ROOT szerint készül (azonos a CSV-importtal).
- Szituációs gyakorló: a „Hasznos fordulat" egy gombbal a beszédgyakorló referenciamondata lehet.
- Verziófeliratok (hub, képernyőfejléc, manifest) egységesen 4.1.

### Tesztek
- PronunciationAssessmentTest bővítve (csere/hiány/többlet, aposztróf, üres bemenet).
- Új UltimateLearningEngineTest (szintek, olvasási idő, forgatókönyvek).

### Verzió
- versionName 4.1.1, versionCode 40300

### Ellenőrzés
- Ebben a környezetben a Gradle/Android SDK nem érhető el (services.gradle.org és Google Maven tiltott), ezért a fordítás és a tesztek NEM futottak le; a módosítások statikus átnézéssel készültek. A GitHub Actions CI futtatása szükséges.


---

<!-- forrás: CHANGELOG_V4.2.0_HU.md -->

## [CHANGELOG_V4.2.0_HU.md]

## v4.2.0 – Pontosság, egységesítés és minőségbiztosítás

### Új (kód + teszt)
- **Szóidő-alapú időzítés** (`WordTiming`): a Whisper-szegmensek határait a tokenidőkhöz szűkíti (csak szűkít, nem okoz átfedést; megbízhatatlan tokenidőnél az eredeti marad). Bekötve: `FileRecognizer`. Blokk-szintű igazítás és globális eltolás-becslés is elérhető az API-ban.
- **Kétmenetes egységesítés** (`TerminologyConsistency`): tulajdonnevek írásváltozatai és az azonos forrásmondatok eltérő fordításai a leggyakoribb alakra egységesítve; döntetlennél nem találgat. Bekötve: `SrtBuild` (kapcsoló: Profil és formázás → „Egységesítés", alapból be).
- **Ellenőrzési rangsor** (`ReviewPriority`): fontosság szerinti sorrend (tagadás, szám, név, bizonytalan felismerés, szókonfidencia…). Bekötve a szerkesztőbe: „Következő ellenőrizendő sor ▶". A szókonfidencia-jelölés csak akkor, ha a számuk egyezik a szavakéval.
- **Párbeszéd gondolatjellel** (`DialogueDash`): gyors beszélőváltásból „- … / - …" blokk. Bekötve: `SrtBuild` (kapcsoló, alapból ki).
- **Modellajánló** (`ModelAdvisor`): RAM, magszám, tárhely, hőállapot alapján; a Diagnosztika képernyőn jelenik meg. A sebesség tájékoztató becslés, nem mért érték.
- **Anonimizált hibajelentés** (`ReportAnonymizer`): a megosztott/másolt jelentésben a fájlnevek, útvonalak, URI-k, e-mailek, IP-k és kulcsok kicserélve (a megjelenített napló változatlan).
- **Arany-referencia WER** (`GoldenWer`, `core/src/test/resources/golden`, `tools/golden_wer.py`): a CI minden futáskor összeveti a mintákat az alapvonallal. A három mellékelt minta szintetikus; valódi mintákat a `golden/README_HU.md` szerint adj hozzá.
- **Manifest-integritás teszt** (`ManifestIntegrityTest`): hiányzó/nem bejegyzett Activity-k eszköz nélkül kiderülnek.

### Már korábban megvolt (nem duplikáltuk)
Sorba állított kötegelt feldolgozás (`SrtJob.queue`, éjszakai mód töltőn), megosztás-intent (SEND), hőmérséklet-függő szálszám (`Perf.thermalScaled`), VTT/ASS export, beszélőszínek, token-konfidencia jelölés a szerkesztőben.

### Javított meglévő hibák (a `core` modul nem fordult)
- `HybridTranslationEngine.OnlineAdapter`: `fun interface` absztrakt tulajdonságokkal → sima `interface`.
- `PerformanceRegressionSuite`: nem létező `summaryLine()` hívások → `TranslationQuality.summaryLine(...)`; a belső ellenőrző példák 1 jegyű számokat használtak, amelyeket a `TranslationCheck` szándékosan figyelmen kívül hagy → 3 jegyű példák.

### Ellenőrzés ebben a környezetben
- A teljes `core` modul (főkód + minden unit teszt, új tesztekkel és a golden mintákkal együtt) lefordult és lefutott Kotlin-fordítóval, JUnit-kompatibilis futtatóval: 75/75 sikeres.
- Az Android-független app-kód tesztjei (kiejtés, szótár, SM-2, szinonima, ManifestIntegrityTest) is lefutottak: 18/18.
- NEM futott le: az Android-függő app-kód fordítása (FileRecognizer, SrtBuild, SrtEditorActivity, DiagnosticsActivity, DiagLog, FileSubtitleActivity módosítások), a Gradle build és az eszközteszt: nincs Android SDK / Gradle elérés. Ezeket a GitHub Actions CI-nek kell igazolnia.

### Verzió
versionName 4.2.0, versionCode 40400


---

<!-- forrás: CHANGELOG_V4.2.1_HU.md -->

## [CHANGELOG_V4.2.1_HU.md]

## v4.2.1 – Biztonsági hardening és Premium Intelligence 5.0 előkészítés

### Javítások
- API-kulcs titkosítási hiba esetén nincs plaintext fallback.
- Régi plaintext API-kulcs csak sikeres AES-GCM migráció után marad meg.
- Online beállítási felület visszajelzi a biztonságos kulcsmentés hibáját.
- Egyedi távoli fordítási végpontnál HTTPS kötelező; HTTP csak loopback/privát LAN végponton engedélyezett.
- Release APK többé nem használhatja a debug aláíró kulcsot.
- Saját release kulcs hiányában unsigned release készül; részleges konfiguráció buildhibát okoz.

### Prémium UI
- Forest Graphite színpaletta.
- Compose prémium mód világos és sötét színsémát is használ a rendszer beállítása szerint.

### Dokumentáció
- Premium Intelligence 5.0 cél-specifikáció.
- Funkcióállapot-mátrix, fájlszintű megvalósítási és tesztelési terv.
- Biztonsági hardening és 4.2.0 → 4.2.1 migrációs útmutató.

### Ellenőrzés
A Gradle 8.9 letöltése hálózati DNS-hibán meghiúsult, ezért a 4.2.1 Android build és tesztfuttatás ebben a környezetben nem igazolt. Lásd `BUILD_STATUS_4.2.1_HU.md`.


---

<!-- forrás: CHANGELOG_V4.2.2_HU.md -->

## [CHANGELOG_V4.2.2_HU.md]

## v4.2.2 – automatizált kiadási ellenőrzések

### Változások
- Verzió: 4.2.2 (`versionCode=40402`).
- Bővített EndpointPolicy határérték- és félrevezető URL-tesztek.
- Új `tools/verify_release_security.py` statikus biztonsági kapu.
- GitHub Actions: statikus ellenőrzés, core/app tesztek, Android debug APK, Wear OS debug APK és unsigned release build.
- CI artifactok közé bekerül az app release és Wear OS debug APK is.

### Korlátok
A statikus ellenőrzés nem helyettesíti a Gradle/Kotlin fordítást, a dinamikus teszteket, a dependency/SBOM vizsgálatot vagy a fizikai eszköztesztet. A release APK kulcs nélkül szándékosan aláíratlan.


---

<!-- forrás: CHANGELOG_V4.2.3_HU.md -->

## [CHANGELOG_V4.2.3_HU.md]

## AngolMagyar 4.2.3 – biztonsági ellenőrzés megerősítése

### Változások
- A kiadási biztonsági ellenőrzés pontos, blokk-alapú vizsgálatot végez a release aláírási konfiguráción; a debug kulcs release buildbe kerülését tiltja.
- Ellenőrzi a részleges release-keystore konfiguráció fail-closed kezelését.
- Android-manifeszt ellenőrzések: `allowBackup=false`, globális cleartext forgalom tiltásának megőrzése, engedélyezett exported komponenskészlet, `FileProvider` nem exportált állapota és a Quick Settings Tile kötési jogosultsága.
- Ellenőrzi, hogy a fájlmegosztási belépési pont csak a deklarált megosztási műveletekkel legyen elérhető.
- A `.gitignore` kulcsfájl-védelmi ellenőrzése PKCS#12 fájlokra is kiterjed.

### Fontos korlát
Ez a kiadás a meglévő funkciókat nem bővíti új AI-szolgáltatóval, kamerás OCR-rel vagy felhőszinkronnal. A biztonsági script statikus guardrail; nem helyettesít dinamikus tesztet, függőségvizsgálatot vagy penetrációs tesztet.


---

<!-- forrás: CHANGELOG_V4.2.4_HU.md -->

## [CHANGELOG_V4.2.4_HU.md]

## AngolMagyar 4.2.4 – Premium Intelligence

### Smart Context Translation finomítás
- Néhány gyakori kétértelmű szóhoz lokális, determinisztikus kontextusbecslés készült.
- A `bank`, `light` és `charge` lehetséges jelentéseit közeli kulcsszavak alapján szűkíti.
- Ha a kontextus nem elégséges, az alternatívák megmaradnak, és a rendszer kifejezetten jelzi a bizonytalanságot.
- A `bank` pénzügyi megfelelője most természetes magyar „pénzintézet”.
- Új regressziós tesztek fedik a pénzügyi, földrajzi, műszaki és bizonytalan eseteket.

### Korlát
Ez offline, szabályalapú heurisztika, nem generatív AI és nem garantálja a helyes jelentést. A végső fordítást a felhasználónak kell ellenőriznie.


---

<!-- forrás: CHANGELOG_V4.2.5_HU.md -->

## [CHANGELOG_V4.2.5_HU.md]

## AngolMagyar 4.2.5 – Smart Translation Memory

### Újdonságok
- Új, platformfüggetlen `SmartTranslationMemory` motor a `core` modulban.
- Csak jóváhagyott, pontosan egyező szegmens és pontos nyelvpár adhat javaslatot.
- A projektmemória az adott projekten belül elsőbbséget kap a globális memóriával szemben.
- Az azonos hatókörű, eltérő fordítások több jelöltként jelennek meg, `ambiguous=true` jelzéssel.
- A memória soha nem írja át automatikusan a fordítást; a találat mindig felhasználói megerősítést igényel.
- A használatszám csak explicit megerősített használat után növelhető.
- Jóváhagyás és archiválás/törlés helyett visszakereshető visszavonás (`RETIRED`) támogatott.

### Biztonsági és adatvédelmi határok
- A core motor nem végez hálózati műveletet és nem tárol adatot önállóan.
- A perzisztencia, titkosítás, hozzáférés-szabályozás és törlési UI az Android adapter feladata; ez a verzió ezeket nem állítja késznek.
- A projektazonosító szerinti szűrés csak logikai elkülönítés; többfelhasználós környezetben szerveroldali jogosultságellenőrzés is szükséges.

### Verzió
- versionName: 4.2.5
- versionCode: 40405


---

<!-- forrás: CHANGELOG_V4.2.6_HU.md -->

## [CHANGELOG_V4.2.6_HU.md]

## AngolMagyar 4.2.6 – forráscsomag-javítási napló

### Megőrzött alapok
- Android alkalmazás `versionName=4.2.6`, `versionCode=40406`.
- Meglévő app/core/Wear modulok, offline ASR/fordítási útvonalak, felirat- és tanulási komponensek.
- Android Keystore AES-GCM titoktárolás és release/debug aláírás szétválasztás.
- Meglévő exported component és FileProvider határok.

### Ebben a mérnöki javítócsomagban
- A belső projektgyökér könyvtárneve `4.2.5` helyett a tényleges `4.2.6` verzióhoz igazítva.
- README és build-státusz dokumentáció verzióeltérései javítva.
- `SmartTranslationMemoryStore`: visszafejtési/Keystore-hiba esetén a titkosított adatblob nem törlődik; a mentés és törlés fail-closed módon megszakad, így nem írhatja felül a megőrzendő adatot üres listával.
- Új fájlszintű Platinum Intelligence 6.0 terv, státusz-, audit- és tesztdokumentáció.
- A kiadás előtti statikus ellenőrzés bővítve a fordítási memória adatmegőrzési invariánsaival.

### Kifejezetten NEM állítjuk késznek
AI társalgópartner, generatív offline AI, élő tolmács újratervezése, kamera OCR, PDF/DOCX import, felhőszinkron, teljes képernyőmigráció, biometrikus zár és fonetikai kiejtésértékelés. Ezekhez külön implementáció, engedélyek/szolgáltatók, tesztek és eszközvalidáció szükséges.


---

<!-- forrás: CHANGELOG_V4.2.6_PLATINUM_6.0_ENGINEERING_HU.md -->

## [CHANGELOG_V4.2.6_PLATINUM_6.0_ENGINEERING_HU.md]

## CHANGELOG – AngolMagyar 4.2.6 + Platinum Intelligence 6.0 Engineering

### 4.2.6 / Platinum Intelligence 6.0 Engineering (forrásszintű javítócsomag)

#### Biztonság (P1)
- `SmartTranslationMemoryStore`: dekriptálási / Keystore hiba esetén a titkosított blob megmarad; `readEntries()` null-t ad; mentés és törlés megszakad. Nincs csendes adatvesztés, nincs plaintext fallback.
- `SecretStore`: fail-closed AES-GCM; legacy plaintext csak sikeres migráció után; titkosítási hiba esetén nem ír vissza plaintextet.

#### Stabilizálás (P0)
- Projektmappa, README, BUILD_STATUS, VALIDATION_REPORT és forrás-audit a valós `versionName=4.2.6` / `versionCode=40406` értékhez igazítva.
- CI workflow: static security guardrail → core teszt → app unit teszt → debug APK → Wear debug → unsigned release.
- `tools/verify_release_security.py` – PASS.

#### Dokumentáció és terv
- `PLATINUM_INTELLIGENCE_6.0_IMPLEMENTATION_PLAN_HU.md` – fázisonkénti, fájlszintű terv.
- `PLATINUM_INTELLIGENCE_6.0_STATUS_HU.md` – tényleges vs. tervezett státusz.
- `PLATINUM_INTELLIGENCE_6.0_TEST_PLAN_HU.md` (ha jelen van) + meglévő FEATURE_MATRIX és IMPLEMENTATION_AND_TEST_PLAN.

#### Domain logika (már meglévő, megerősített)
- Offline Smart Context Translation, Smart Translation Memory (APPROVED-only, scope, ambiguity).
- ReviewIntelligence, TranslationCheck, minőség- és tanulási komponensek.

#### Nem része ennek a csomagnak
- Új APK / aláírt release.
- Teljes P5–P10 implementáció (hang/meeting/kamera/cloud/teljes UI-migráció).
- Fizikai eszközteszt és golden screenshot baseline.

#### Verziószabály
Az alkalmazás `versionName` és `versionCode` változatlan (4.2.6 / 40406) a frissítési kompatibilitás miatt. A „6.0” fejlesztési célverzió és minőségkapu-program.


### P2–P3 folytatás (ugyanebben a csomagban)

#### Új
- `app/.../TranslationIntelligence.kt` – offline koordinátor: SmartTranslationMemory + SmartContextTranslation + TranslationCheck.
- `TranslationIntelligenceTest.kt` – negáció/szám/név flag-ek, pending entry scope, store nélküli analyze.

#### Módosított
- `ui/design/PremiumTranslationCard.kt` – opcionális memóriajavaslat, minőség-chippek, kontextus-megjegyzés, „Javaslat elfogadása”.
  A régi hívások továbbra is fordulnak (új paraméterek default értékkel).

#### Elvek
- Memória és kontextus csak javaslat; automatikus felülírás tilos.
- Minőségjelzés forrása látható (determinisztikus offline check, nem „AI certainty”).
- Keystore-hiba esetén memória-javaslat nem jelenik meg.


### P4 folytatás (ugyanebben a csomagban)

#### Módosított
- `PhrasebookStore.kt`: SpacedRepetition (SM-2) ütemezés; `repetitions` + `easeFactor` mezők; `due()` lekérdezés; `review(id, grade)`.
- `PhrasebookActivity.kt`: ismétlési mód (jelentés felfedése, Újra/Nehéz/Jó/Könnyű), due számláló.
- `PlatinumIntelligenceActivity.kt`: hub státuszok P2–P4 szerint frissítve.

#### Elvek
- Tanulási ütemezés determinisztikus, offline, helyi tárolás.
- Phrasebook és ReviewCoach ugyanazt a SpacedRepetition motort használja.
- Nincs hálózati feltöltés a szókincstárból.


### P5–P7 folytatás

#### Új
- `MeetingWorkflow.kt` – offline meeting csomag: összefoglaló + minőség (ReviewIntelligence) + phrase candidates (nem auto-save)
- `LiveTranslationHints.kt` – élő párokhoz rövid UI-hint (memória / minőség / kontextus)
- `MeetingWorkflowTest.kt`

#### Módosított
- `TranscriptDetailActivity.showSummary`: MeetingWorkflow minőségpontszám és jelzések
- PlatinumIntelligence hub: Subtitle + Meeting Workflow státusz

#### Elvek
- Minőségjelzés nem módosítja az átiratot
- Tanulási jelöltek csak explicit felhasználói mentés után kerülhetnek szótárba
- MeetingMode prefs snapshot/restore változatlan


### P8 / P9 / P10 folytatás

#### Új
- `ui/design/AccessibilityKit.kt` – kontraszt, touch target, snapshot, checklist
- `sync/SyncContract.kt` – NoOp sync, envelope, registry (P9)
- `capture/CaptureContracts.kt` – camera/document engines default UNAVAILABLE (P8)
- Unit tesztek: AccessibilityKitTest, SyncContractTest, CaptureContractsTest

#### Módosított
- `DiagnosticsActivity` – akadálymentesség checklist kártya
- PlatinumIntelligence hub – P8/P10 státuszszövegek

#### Elvek
- P8: nincs „kész” OCR/kamera, amíg readiness != READY
- P9: nincs bekapcsolható felhőszinkron backend nélkül
- P10: practical a11y helpers, nem WCAG tanúsítvány-állítás


---

<!-- forrás: CHANGELOG_V56_HU.md -->

## [CHANGELOG_V56_HU.md]

## Changelog – v2.56.0

- Dual Translation összehasonlító panel.
- Offline Dictionary Pro mini-szótár.
- Pronunciation Master Android TextToSpeech támogatással.
- Infinity Quality Dashboard alapmutatókkal.
- Pontosított AI-státusz: generatív AI-fordítás nincs aktiválva.
- Verziószám 2.56.0 / 5600.


---

<!-- forrás: CHANGELOG_v2.30.0_HU.md -->

## [CHANGELOG_v2.30.0_HU.md]

## AngolMagyar v2.30.0 – Gyémánt Edition (első UI-frissítési kör)

### Elkészült a forráskódban
- Új „Gyémánt” kiemelőszín hideg türkiz főszínnel és visszafogott lila fényárnyalattal.
- Új telepítéseknél a Gyémánt téma az alapértelmezett; a már elmentett felhasználói témaválasztást nem írja felül.
- A kezdőképernyő fejlécén megjelenik a „GYÉMÁNT” jelölés és az alkalmazás értékajánlata.
- A meglévő színválasztó automatikusan megjeleníti az új témát, mert az Accent.ALL listából épül fel.

### Tudatosan változatlanul hagyva
- Átiratfelismerési és fordítási logika.
- Minőségpontozás, célzott újrafelismerés, fájlformátumok és export.
- A korábban kiválasztott téma a meglévő telepítéseken.

### Ellenőrzés
Ez a forráskód-módosítás önmagában nem igazolja a fordíthatóságot vagy az APK működését. Futtatandó:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

Ezután kis kijelzős telefonon, világos/sötét módban és OLED módban is ellenőrizni kell a fejlécet, a témaválasztót és a régi (View-alapú) képernyőket.

### Második fejlesztési kör – minőségellenőrzés
- A pontszám felirata „Ellenőrzési index” lett, és a képernyő egyértelműsíti, hogy ez a jelzések súlyozása, nem mért felismerési pontosság.
- A természetes rövid válaszok (pl. „Yes”, „Okay”, „Thanks”) nem kapnak automatikusan töredékjelzést.
- Az üres sor kizárólag üres tartalomként kerül jelzésre, nem kap mellé félrevezető töredékjelölést.
- A nulla hosszúságú idősáv is hibás időzítésként jelenik meg.
- Új egységtesztek kerültek a fenti esetekre.

### Gyémánt Edition – harmadik fejlesztési kör
- A fordítási memória szöveges importja most a kereséssel azonos kulcsnormalizálást használja; a külső TSV-fájlokban szereplő nagybetűk és írásjelek nem akadályozzák a találatot.
- Hibás, üres vagy célfordítás nélküli import-sorok kihagyása; az ismétlődő normalizált kulcsoknál a későbbi érték érvényesül.
- Négy célzott `TranslationMemoryTest` készült az import, export/import kör, hibás sorok és ütköző kulcsok ellenőrzésére.
- Android verziómetaadat frissítve: `versionCode = 3000`, `versionName = 2.30.0`.
- A teljes Android-build és a JUnit-futtatás továbbra is külön környezetben ellenőrizendő.


### Gyémánt Edition – negyedik fejlesztési kör
- Unicode NFC-normalizálás a fordítási memória kulcsainál, hogy az ékezetes szövegek előre összeállított és kombináló karakteres változata is egyezzen.
- Az in-memory és Room-alapú fordítási memória közös kulcsnormalizálást használ, csökkentve az eltérő találati viselkedés kockázatát.
- Új egységteszt a kanonikusan ekvivalens Unicode-kifejezésekre.

### Update 7 – export előtti minőségellenőrzés
- Az SRT és WebVTT export előtt lefut a `SrtQualityCheck` ellenőrzés.
- A felhasználó összesítést kap a hibákról és figyelmeztetésekről, legfeljebb nyolc részletes jelzéssel.
- Az ellenőrzés nem módosítja automatikusan a feliratot; a felhasználó dönthet az export folytatásáról.
- A minőségellenőrzés jelenleg az SRT/VTT exportokra van bekötve; a DOCX/PDF/MD/TXT útvonalak külön integrációt igényelnek.


---

<!-- forrás: COMPOSE_COMPILER_FIX_HU.md -->

## [COMPOSE_COMPILER_FIX_HU.md]

## Javítási jegyzőkönyv – Compose/Kotlin IR fordítóhiba

### Kiinduló hiba

A GitHub Actions `:app:compileDebugKotlin` feladata a `DiamondLiveTheater.kt` fordításakor Kotlin backend hibával állt le. A kiváltó kivétel:

```text
java.lang.IllegalStateException: No mapping for symbol: VAR name:reduced type:kotlin.Boolean [val]
```

A hibás konstrukció a `DiamondLiveView` inicializálójában létrehozott lokális `reduced` Boolean értéket zárta be a `ComposeView.setContent` Compose-lambda-jába:

```kotlin
val reduced = PremiumMotion.reduced(ctx)
ComposeView(ctx).apply { setContent { DiamondLiveTheater(reduced) } }
```

### Javítás

A `reduced` érték már nem kerül át külső lokális változóként a Compose-lambda-ba. A mozgáscsökkentési preferencia a kompozícióban, a `LocalContext.current` segítségével kerül lekérdezésre:

```kotlin
setContent {
    DiamondLiveTheater(reduced = PremiumMotion.reduced(LocalContext.current))
}
```

Ez megtartja a meglévő `PremiumMotion.reduced` döntési logikát (alkalmazásbeállítás és rendszer animációskála), és nem módosítja az animációk időzítését vagy a képernyő funkcióit. A Kotlin, Gradle, AGP és Compose verziók változatlanok.

### Regresszióvédelem

A `tools/verify_compose_compiler_regression.py` ellenőrzi, hogy a `DiamondLiveView` ne vezessen vissza konstruktor-lokális `reduced` Boolean capture-t, és a Compose tartalom a `LocalContext.current` alapján kérje le a beállítást. A GitHub Actions ezt a guardot a release security ellenőrzés után futtatja.

### Ellenőrzési állapot

- Forrásmódosítás: elkészült.
- ZIP integritás: az eredeti feltöltött archívum hibamentesen tesztelhető volt.
- Regressziós guard: futtatandó / a csomagellenőrzés része.
- Android Gradle build és teljes tesztcsomag: a csomag összeállításakor külön futtatandó; sikeresnek csak tényleges CI- vagy helyi futás után minősíthető.

### Érintett fájlok

- `app/src/main/java/hu/angolmagyar/fordito/ui/processing/DiamondLiveTheater.kt`
- `tools/verify_compose_compiler_regression.py` (új)
- `.github/workflows/build.yml`


---

<!-- forrás: DIAMOND_BLUE_V10_HU.md -->

## [DIAMOND_BLUE_V10_HU.md]

## Diamond Blue UI v10 – Ultimate Diamond Experience

A v10 frissítés a v9 Diamond Blue vizuális rendszerére épül. A fordítási, beszédfelismerési, fájlkezelési és feldolgozási logikához nem nyúl.

### Vizuális fejlesztések
- Új, vektorosan rajzolt, több metszetű zafír Diamond embléma a kezdőképernyő fejlécében.
- Finom, folyamatos fénycsík az emblémán, a csökkentett animációs beállítás tiszteletben tartásával.
- Egységes Diamond Edge peremfény és lassú fényreflexió a közös Compose PremiumCard komponensen.
- A kártyák meglévő belépési animációja és tartalma változatlan marad; a csillanás a tartalom mögött jelenik meg.
- Az animációk kikapcsolnak az alkalmazás csökkentett mozgás beállításánál és energiatakarékos módban.

### Módosított fájlok
- `app/src/main/java/hu/angolmagyar/fordito/ui/design/DiamondBrandMark.kt` (új)
- `app/src/main/java/hu/angolmagyar/fordito/ui/design/PremiumDesignSystem.kt`
- `app/src/main/java/hu/angolmagyar/fordito/ui/MainActivity.kt`

### Ellenőrzés
A ZIP szerkezeti integritása ellenőrizhető. Az Android/Kotlin fordítás a környezetben nem futott le: a Gradle Wrapper a `services.gradle.org` hostot DNS-hiba miatt nem érte el. Ezért az APK buildje nincs igazolva.
- Kódszerkezeti ütközés javítása: a Compose időtartam-token `PremiumMotionDurations` nevet kapott, így nem ütközik a feldolgozó animációs segéd `PremiumMotion` objektummal.
- A `Prefs.reduceMotion` duplikált deklarációját egyetlen közös beállításra tisztítottam.


---

<!-- forrás: DIAMOND_BLUE_V11_HU.md -->

## [DIAMOND_BLUE_V11_HU.md]

## Diamond Blue UI v11 – Diamond Experience

A v11 frissítés a v10 Diamond Blue felületére épül. A fordítási, beszédfelismerési, fájlkezelési és feldolgozási logika változatlan maradt.

### Új felületi elem
- A kezdőképernyő fejlécét követő, új Diamond Experience panel.
- Saját Compose Canvas-alapú, vektoros zafírmedál: többfokozatú fényudvar, körbefutó gyűrű és metszett gyémánt.
- Finom, lassú orbit animáció és pulzáló fény, külső képfájl vagy hálózati erőforrás nélkül.
- A panel valós alkalmazásállapotot jelez: készenléti vagy aktív feldolgozási állapot.
- A meglévő csökkentett animáció és energiatakarékos mód esetén az animációk statikus megjelenésre váltanak.
- A kezdőképernyő többi elemének belépési sorrendje az új panelhez igazítva.

### Módosított fájlok
- `app/src/main/java/hu/angolmagyar/fordito/ui/MainActivity.kt`
- `DIAMOND_BLUE_V11_HU.md`
- `BUILD_STATUS_DIAMOND_V11_HU.md`
- `CHANGELOG.md`

### Ellenőrzés
- A forrásmódosítások és a ZIP archívum szerkezeti integritása ellenőrizve.
- A teljes Android/Kotlin build nem igazolt: a Gradle Wrapper 8.9 disztribúcióját a környezet nem tudta letölteni (`UnknownHostException: services.gradle.org`).
- Emiatt az APK és a készülékes animációs teljesítmény nem tekinthető teszteltnek.


---

<!-- forrás: DIAMOND_CINEMA_ULTIMATE_V3.10_HU.md -->

## [DIAMOND_CINEMA_ULTIMATE_V3.10_HU.md]

## Diamond Cinema Ultimate – v3.10.0

Teljes prémium vizuális és cinematic csomag az AngolMagyar Platinum/Diamond vonalon.

### Bekapcsolás
- **Beállítások → Mozgásprofil: Teljes**
- **Diamond Cinema Mode** kapcsoló (max. vizuál)
- reduceMotion / „Ki” profil: minden hurok és cinema effekt kikapcsol

### Cinematic elemek

#### Feldolgozás (Process Theater)
- Aktuális művelet hős panel + orbit gyűrű
- Lépés energia-sín + flow particle
- Lépéslista státuszokkal
- Élő felismerés/fordítás
- Meta: szegmens, fájl, %, fordítva, **motor**

#### Élő fordítás (Live Theater)
- Fázisgép: Kész / Figyel / ASR / Fordít / Szünet
- Spektrum (valós level történet)
- **Silence drama**: csendben spektrum összehúzódik + „Várakozás…”
- **Broadcast lower-third** szövegsáv
- **Haptics** fázisváltáskor
- Fullscreen élő: ugyanez felül

#### Kezdőlap
- JobCard + beágyazott Process Theater
- JobFinished **End Card** + CompletionBurst
- Diamond Experience medál (gyorsabb orbit aktívan)
- v3.10 jelvény

#### WaveView
- Platinum/Diamond színezés (kész / aktív / vár)

#### Mozgás
- Profilok: full / subtle / reduced / none
- Cinema csak FULL + kapcsoló mellett

### Korábbi hullám modulok (core)
- Smart Context, Translation Quality, Hybrid Engine
- Global Dashboard, Performance Suite, DiamondIntegration kapu

### Nyitott (eszközös)
- Fizikai QA, teljes View→Compose, CI Gradle

### v3.11 Chronograph
- Külső ív: overall %
- Belső ív: lépés progress
- Időfelirat: eltelt / hátra

### v3.12 Task Portal
- NavTransitions a JobCardról
- EXTRA_FROM_PORTAL + pipeline pulse

### v3.13 Depth stack
- Parallax aurora rétegek Cinema Mode-ban


---

<!-- forrás: FEATURE_MATRIX_5.0_HU.md -->

## [FEATURE_MATRIX_5.0_HU.md]

## AngolMagyar – funkcióállapot-mátrix a v5.0 célverzióhoz

A státuszok forráskód- és dokumentációs áttekintést jelentenek, nem fizikai eszközös működési garanciát.

| Javaslat / képesség | Kiinduló állapot a v4.2.0-ban | 4.2.1 csomag változása | v5.0 előtt hátralévő munka |
|---|---|---|---|
| Infinity Context AI | Részleges: `SmartContextTranslation`, `OnlineTranslator` kontextusablak | Nem duplikálva | Kontextus-adatmodell, beszélő/projekt kontextus és alternatívák egységes integrációja |
| Translation Quality Intelligence | Több szabály- és auditmotor, WER referencia tesztek | Nincs új pontossági állítás | Teljes pipeline/UI összekötés, referenciahangos benchmark és nyelvtani ellenőrzés |
| Voice Intelligence Studio | ASR, VAD, TTS, `PronunciationAssessment` | Nincs új pontozási állítás | Hangfelvétel összehasonlítás, fonetikai validáció, US/UK eszközteszt |
| Personal Learning Intelligence | SM-2 és `LearningAnalyticsActivity` | Nincs duplikált tanulómotor | Fordítási hibákból gyakorlófeladat, aktív/passzív szókincs és teljes tanulási eseménynapló |
| Subtitle Studio Pro | SRT/VTT/ASS feldolgozás, editor, job queue, checkpoint | Nincs duplikált szerkesztő | Hanghullám, szinkronizált kétpaneles editor, undo/redo, verziódiff és UX validáció |
| Offline AI & Privacy Vault | `SecretStore`, `SecureBackupArchive`, `PrivacyActivity`; a SecretStore korábban plaintext fallbacket engedett | **Javítva:** fail-closed AES-GCM titoktárolás; release/debug aláírás szétválasztása | Biometrikus zár, megőrzési szabályok UI-integrációja, biztonsági tesztek |
| Smart Translation Memory | TranslationMemory, GlossaryStore, GlossaryGovernance, RetranslationPlanner | Nincs párhuzamos adattár | UI/pipeline integráció, projekt és globális prioritás, hatásvizsgálat és jóváhagyás |
| Diamond Experience | Compose design tokenek és több paletta; View/Compose eltérő képernyők | **Bővítve:** Forest Graphite paletta és Compose világos/sötét prémium színséma | Teljes képernyőmigráció, OLED/kontraszt/accessibility és screenshot baseline |
| AI Conversation Partner | Nincs igazolt teljes párbeszédpartner | Specifikálva | Generatív szolgáltató, beszédfolyam, tanulási visszajelzés, költség/adatvédelmi kontroll |
| Live Interpreter | Élő fordítás és ASR alapok | Nincs duplikálva | Kétirányú munkamenet, megszakítások, latency és valós készülék teszt |
| Smart Camera Translate | Nem találtunk igazolt kamera-OCR munkafolyamatot | Specifikálva | CameraX + ML Kit OCR, engedélyek, kijelölés, overlay és készülékes teszt |
| Document Intelligence | Dokumentum export infrastruktúra részben jelen van | Specifikálva | PDF/DOCX import, formázásmegőrzés, OCR és export teszt |
| Meeting Assistant | `MeetingMode`, `MeetingSummary` alapok | Nincs duplikálva | Teljes átirat → beszélő → fordítás → összefoglaló munkafolyamat |
| Cloud Sync | Nincs rögzített backend/szolgáltató | Tudatosan nem aktiválva | Backend és auth kiválasztás, E2E titkosítás, konfliktusfeloldás és adatkezelés |
| Smart Export | ExportHelper, felirat export | Nincs duplikálva | Export sablonok, előnézet, dokumentumformátumok és metaadat-védelem |

### Fontos értelmezés

A 4.2.1 egy biztonsági és felületi hardening kiadás, nem a teljes v5.0 funkciókészlet. A hiányzó, szolgáltatófüggő képességeket (generatív társalgás, felhőszinkron) nem lehet hitelesen bekapcsolni szolgáltató, backend, hitelesítés és adatkezelési döntés nélkül. A kamera- és dokumentumfeldolgozás is további natív Android-integrációt igényel.


---

<!-- forrás: IMPLEMENTATION_AND_TEST_PLAN_5.0_HU.md -->

## [IMPLEMENTATION_AND_TEST_PLAN_5.0_HU.md]

## AngolMagyar 5.0 – fájlszintű megvalósítási és tesztelési terv

### A. Alap hardening és reprodukálható build

| Fájl / terület | Feladat | Elfogadási feltétel |
|---|---|---|
| `app/build.gradle.kts` | Release aláírás kizárólag saját release kulccsal; debug fallback tiltása | Hiányzó kulcs esetén unsigned release, részleges kulcsnál egyértelmű buildhiba |
| `SecretStore.kt` | AES-GCM titoktárolás fail-closed módban | Keystore-hiba esetén nincs plaintext tárolás; régi kulcs migrációja titkosítva |
| `core/EndpointPolicy.kt`, tesztje | Távoli custom endpoint HTTPS-korlátja | HTTPS és helyi/private HTTP elfogadott; távoli plaintext HTTP elutasított |
| `Presets.kt`, `OnlineSettingsDialog.kt` | Titkosított mentés hibájának kezelése | UI visszajelzést ad, online kapcsolatpróba nem indul kulcsmentési hiba után |
| `LuxuryPalettes.kt`, `Prefs.kt`, `SettingsActivity.kt` | Forest Graphite paletta | Új telepítésen megjelenik; meglévő paletták nem vesznek el |
| `ui/theme/Theme.kt` | Világos/sötét prémium Compose színséma | Rendszertéma-váltásra kontrasztos, olvasható színséma |
| `.gitignore` | Helyi release kulcsfájlok kizárása | `keystore.properties` és release keystore nem kerül a repositoryba |

### B. Kontextus és minőség

- `core/SmartContextTranslation.kt`: ContextRequest bővítése szomszédos mondattal, beszélővel, projekttémával és stílusprofillal.
- `core/OnlineTranslator.kt`: közös context prompt; eredet és szolgáltatói hibák strukturált visszaadása.
- `core/TranslationQualityAudit.kt`, `TranslationCheck.kt`, `ReviewPriority.kt`: súlyosság és jelzés-eredet egységesítése.
- `app/SrtBuild.kt`, `SrtEditorActivity.kt`: ellenőrzési jelzés, hangrészlet lejátszás és jóváhagyás bekötése.

Teszt: többértelmű szó tesztmátrix, név/szám/tagadás regresszió, üres és hiányos válasz, offline fallback, kézi jóváhagyás megőrzése.

### C. Voice és tanulás

- `RecognitionHelper.kt`, `LiveWhisperAsr.kt`, `AudioRecorder.kt`: életciklus, megszakítás, permission és erőforrás felszabadítás.
- `PronunciationAssessment.kt`: csak validált mérőszámokat adjon; átirat-egyezés ne legyen fonetikai pontszámként megjelenítve.
- `UltimateLearningEngine.kt`, `LearningAnalyticsStore.kt`, `LearningAnalyticsActivity.kt`: fordítási hibából tanulókártya, aktív/passzív szókincs.

Teszt: referenciahangos WER, hangfelvétel/újrajátszás, permission visszavonás, TTS locale hiány, SM-2 határértékek, tanulási események tartóssága.

### D. Subtitle Studio

- `FileSubtitleActivity.kt`, `SrtEditorActivity.kt`, `SrtBuild.kt`, `SubtitlePostProcessor.kt`, `SrtJob.kt`, `Checkpoint.kt`: kétpaneles szerkesztő, audio seek, undo/redo, automatikus mentés, checkpoint.

Teszt: SRT/VTT/ASS import-export round-trip, hosszú fájl, megszakítás és folytatás, átfedés, időbélyeg, hibás bemenet, memóriahasználat.

### E. Privacy Vault

- `SecretStore.kt`, `SecureBackupArchive.kt`, `BackupCenterActivity.kt`, `PrivacyActivity.kt`, `AuditLog.kt`, `ReportAnonymizer.kt`.
- Következő bővítés: biometrikus feloldás, adatmegőrzési UI, projektszintű törlés, titkosított sync csak backend döntés után.

Teszt: hibás kulcs, sérült titkosított mentés, jelszóhibák, napló- és export anonimizálás, plaintext keresés tesztadatokon, adat törlés utáni visszaállíthatatlanság.

### F. Kamera, dokumentum, meeting, cloud

- Kamera: új `CameraTranslateActivity`, CameraX, ML Kit Text Recognition; csak explicit kameraengedéllyel.
- Dokumentum: `DocumentImportCoordinator`, PDF/DOCX/TXT parser adapterek; formázásmegőrző export.
- Meeting: meglévő `MeetingMode` és `MeetingSummary` teljes munkafolyamatba kötése.
- Cloud: backend, hitelesítés és titkosítás kiválasztása előtt csak interface/specifikáció; éles szinkron nem kapcsolható be.

Teszt: OCR pontosság különböző fényben, PDF szöveg és scan külön kezelése, DOCX stílusok, meeting beszélőváltás, sync konfliktus és jogosultság.

### G. Kiadási tesztmátrix

1. `./gradlew :core:test`
2. `./gradlew :app:testDebugUnitTest`
3. `./gradlew :app:assembleDebug :wear:assembleDebug`
4. `./gradlew :app:assembleRelease` saját release kulccsal
5. Valós eszköz: telepítés, frissítés, mikrofon, háttérfolyamat, fájlválasztó, TTS, offline fordítás.
6. UI: világos, sötét, OLED, nagy betűméret, kompakt kijelző, csökkentett mozgás.
7. Biztonság: API-kulcs tárolás, hálózati hozzájárulás, mentés-visszaállítás, adat-export és törlés.
8. Kiadási jegyzőkönyv: commit hash, Gradle/JDK/SDK/NDK verzió, teszteredmények, APK SHA-256 és aláírási tanúsítvány ujjlenyomata.

### Kiadási döntés

Egy funkció csak akkor „kész”, ha a forráskód, a felhasználói felület, a tárolás, a hibakezelés, a teszt és a dokumentáció együtt teljesül. A jelen 4.2.1 csomagban az A fejezetben felsorolt hardening változások kerültek be; a B–F fejezet a v5.0 további végrehajtandó specifikációja.

### 4.2.2 automatizált kiadási kapu

A CI a `tools/verify_release_security.py` ellenőrzést futtatja a Gradle tesztek előtt. Ez forrásszintű regresszióvédelmi kapu, nem helyettesíti a Kotlin/Android buildet vagy a készülékes validációt. A pipeline külön lefordítja az app debug, Wear OS debug és unsigned app release variánsokat.


---

<!-- forrás: IMPLEMENTATION_NOTES_HU.md -->

## [IMPLEMENTATION_NOTES_HU.md]

## AngolMagyar 2.28.6 – megvalósítási megjegyzések

### Token-szintű bizonytalanság
A JNI-híd a Whisper meglévő API-jából kiolvassa a token szövegét, valószínűségét és időbélyegét. A Kotlin `WhisperNative.Seg.tokens` mezőben ezek elérhetők. A `TokenQuality` a küszöb alatti tokeneket kézi ellenőrzésre jelöli. A `FileRecognizer` a leggyengébb tartalmi token log-valószínűségét a meglévő feliratminőségi jelzésbe is beemeli, a szavankénti pontszámokat pedig továbbadja a szerkesztőnek. Ez nem szóhelyességi garancia, és nem módosítja a felismert szöveget.

### Tartalommegőrzés
A `FileRecognizer` már nem dob el szegmenst pusztán azért, mert a no-speech valószínűsége 0.8 fölötti. Az egymás utáni három azonos szegmens is csak akkor szűrhető, ha mindhárom alacsony átlagos logprob értékű.

### Ellenőrzés
A ZIP forráscsomag. Ebben a környezetben az Android NDK-s build és a teljes Gradle tesztfuttatás nincs igazolva; a telefonos telepítés előtt Android Studio/Gradle build szükséges.


### Update 9 – gyors ugrás az első érintett feliratsorhoz
Az export előtti minőségellenőrzés párbeszédablakában megjelent az „Első érintett sor” gomb. Ez az első jelzett cue pozíciójára görget, és fókuszt kér a látható sorra. Nem írja át a feliratot, az időzítést vagy a fordítást. Az ellenőrzést és az exportot a felhasználó továbbra is külön kezeli.


---

<!-- forrás: INFINITY_AI_INTELLIGENCE_WAVE_V2.57.0_HU.md -->

## [INFINITY_AI_INTELLIGENCE_WAVE_V2.57.0_HU.md]

## Platinum Infinity – v2.57.0 INFINITY AI INTELLIGENCE WAVE

### Elkészült fejlesztési eszközök
- **Synonym Intelligence:** offline kurált angol szinonimajavaslatok magyar jelentéssel.
- **Pronunciation Assessment:** célmondat és beszédfelismerőből származó átirat összevetése Levenshtein-alapú szóhibaaránnyal (WER). Ez szövegegyezés, nem fonetikai vagy akcentusminősítés.
- **Dictionary CSV interchange:** UTF-8 CSV import/export segéd idézőjelek, vesszők és idézőjelek helyes kezelésével.
- **Learning Stats model:** egyszerű, determinisztikus számlálók szótárkereséshez, gyakorláshoz és sikeres ellenőrzésekhez.
- **Next Wave Tools UI:** szinonimakereső és átirat-összevető panel integrálva a meglévő Platinum eszközoldalra.

### Verzió
- versionName: 2.57.0
- versionCode: 5700

### Tesztlefedettség
Új unit tesztek: szinonimajavaslat, azonos/eltérő beszédátirat pontozása, CSV round-trip vesszővel és idézőjellel.

### Korlátok / következő integrációs feladatok
- A CSV segéd jelenleg domain-modul; a fájlválasztó és a szótár Room-adatbázisba történő import/export UI-integrációja következő lépés.
- A beszédértékelő a már külső beszédfelismerőből kapott átiratot értékeli. Mikrofonindítás, nyelvi modell és fonéma-/hangminőség-elemzés nincs e modul által bekapcsolva.
- Valódi generatív AI-fordítás nincs aktiválva; szolgáltatóadapter, biztonságos kulcstárolás, hozzájárulás és adatvédelmi folyamat továbbra is szükséges.
- APK-build és fizikai eszközteszt csak sikeres Gradle/Android SDK környezetben igazolható.

Ez forráskód-csomag, nem igazolt APK.


---

<!-- forrás: INFINITY_AI_VOICE_MASTER_V2.58.0_HU.md -->

## [INFINITY_AI_VOICE_MASTER_V2.58.0_HU.md]

## Platinum Infinity – v2.58.0 AI & VOICE MASTER

### Integrációs hullám

#### Tartós saját szótár (Room)
- Új `dictionary_entries` tábla angol kulccsal, magyar jelentéssel és példamondattal.
- A korábbi `translation_memory` tábla adatait megőrző, 1 → 2 verziós Room migráció.
- CSV import az Android Storage Access Framework fájlválasztójával.
- CSV export felhasználó által kiválasztott célfájlba, UTF-8 BOM kódolással.
- A saját szótár bejegyzései megjelennek az offline keresési találatok között.
- Azonos normalizált angol kulcs importja frissíti a korábbi bejegyzést.

#### Beszédfelismeréses gyakorlás
- Android `RecognizerIntent` indítása angol (en-US) nyelvi beállítással.
- A felismert szöveg visszakerül a szerkeszthető mezőbe.
- A meglévő WER-alapú szövegegyezés-értékelő azonnal használható.
- A beszédfelismerés szolgáltatását a készülék biztosítja; internet/offline támogatás és pontosság készülékfüggő.
- A pontszám szövegátirat-egyezést mér, nem fonetikai vagy akcentusminősítést.

### Verzió
- versionName: 2.58.0
- versionCode: 5800

### Ellenőrzés és korlátok
- Forrásmódosítások elkészültek.
- Gradle build megkísérelve: `./gradlew :app:compileDebugKotlin --offline`.
- A wrapper a Gradle 8.9 disztribúciót próbálta letölteni; a környezet DNS-hibája (`UnknownHostException: services.gradle.org`) miatt a fordítás nem indult el.
- APK-build, unit teszt és fizikai Android-eszközteszt nincs igazolva.
- Valódi generatív AI-fordító nincs aktiválva; ehhez külön szolgáltatóintegráció, kulcskezelés és adatvédelmi hozzájárulás szükséges.

Ez módosított Android-forrásprojekt, nem igazoltan telepíthető APK.


---

<!-- forrás: MIGRATION_4.2.0_TO_4.2.1_HU.md -->

## [MIGRATION_4.2.0_TO_4.2.1_HU.md]

## Frissítési útmutató – 4.2.0 → 4.2.1

### Felhasználói adatok

A normál alkalmazásadatok és a meglévő debug aláírás megmarad. A debug kulcs változatlanul a projektben maradt, ezért a 4.2.0 debug telepítés frissíthető.

### API-kulcs migráció

Az első beállításolvasáskor a korábban plaintextként tárolt API-kulcs titkosított Android Keystore tárolóba kerül. Sikeres migráció után a régi plaintext mező törlődik.

Ha a Keystore nem érhető el, a kulcs nem marad plaintext formában; ilyen esetben a felhasználónak újra meg kell adnia az API-kulcsot, miután az eszköz Keystore állapota helyreállt.

### Fejlesztői build

A debug APK továbbra is a projekt debug aláírásával készül. A release APK saját kulcs nélkül unsigned, és nem telepíthető normál frissítésként, amíg nincs aláírva.

Release kulcs beállítása: lásd a README „Saját release aláírás” fejezetét. Soha ne commitold a keystore-t vagy a `keystore.properties` fájlt.

### Ellenőrzés

Frissítés után ellenőrizd:
1. alkalmazás elindul és meglévő projektek megjelennek;
2. online fordítási beállítások betöltődnek;
3. API-kulcs titkosított migrációja sikeres;
4. offline fordítás, TTS, mikrofon és felirat-export működik;
5. világos/sötét prémium téma váltása működik.


---

<!-- forrás: NEXT_WAVE_V2.55.0_HU.md -->

## [NEXT_WAVE_V2.55.0_HU.md]

## Platinum Infinity – Next Wave v2.55.0

### Ebben a hullámban

#### Smart Context Translation – első használható eszköz
- Angol forrásszöveg és szabad kontextus megadása.
- Természetes, hivatalos és közvetlen hangnem kiválasztása.
- Determinisztikus kontextusjelzések: tegezés/magázás, modalitás, többjelentésű kifejezések és kommunikációs szándék.
- A modul fordítási briefet ad; nem állítja, hogy nyelvi modell vagy teljes szemantikai elemző, és nem írja át automatikusan a szöveget.

#### Translation Quality – használható alapellenőrző
- A forrás és fordítás összevetése a meglévő `TranslationQualityAudit` motorral.
- Szám-, tulajdonnév-, tagadás- és szokatlan hosszeltérés-jelzések.
- A figyelmeztetések nem bizonyítják a hibát; a modul nem módosítja a fordítást.

#### Infinity Global UI / Platinum Motion
- A meglévő `LuxuryPalettes` és `PremiumMotion.reduced()` infrastruktúra dokumentáltan elérhető.
- Az új eszközoldal jelzi a tényleges migrációs hátralékot; nem jelöli késznek a teljes View-migrációt vagy minden képernyő mozgásintegrációját.

### Integráció
- Új `NextWaveToolsActivity`, regisztrálva az Android manifestben.
- A Platinum Intelligence Suite következő hullámának első négy eleme már az új eszközoldalra navigál.
- Verzió: 2.55.0 / versionCode 5500.

### Ellenőrzés és korlátok
A forráscsomag módosítva. APK-buildet és Android-eszköztesztet csak sikeres Gradle/SDK környezetben lehet igazolni; a csomag nem tekinthető telepíthető APK-nak. A kontextusjelzések szabályalapúak, nem generatív fordítások.


---

<!-- forrás: NEXT_WAVE_V2.56.0_HU.md -->

## [NEXT_WAVE_V2.56.0_HU.md]

## Platinum Infinity Ultimate Intelligence – v2.56.0

### A kiadás tartalma

#### Dual Translation
- Közös angol forrás mellett két magyar változat rögzíthető.
- Mindkét változatra lefut a projekt meglévő, determinisztikus TranslationQualityAudit ellenőrzése.
- Szóhossz és figyelmeztetésszám összevetése.
- Nincs automatikus győzteshirdetés: a jelzésszám nem fordításminőségi pontszám.

#### Dictionary Pro Offline
- Beépített, helyben kereshető angol–magyar mini-szótár 26 többjelentésű gyakori szóval.
- Több magyar jelentés és rövid kétnyelvű példamondat.
- Nem teljes lexikai adatbázis, hálózati keresést nem végez.

#### Pronunciation Master
- Android TextToSpeech integráció.
- Amerikai (Locale.US) és brit (Locale.UK) nyelvi beállítás kiválasztható.
- Beszédsebesség 0,88-ra állítva.
- A ténylegesen elérhető hang a készülék telepített TTS hangadataitól függ; hiányzó nyelvi adat esetén a felület tájékoztat.

#### Infinity Quality Dashboard
- Forrás- és fordításszó-szám, karakterhossz, szóarány.
- Meglévő minőségellenőrző figyelmeztetéseinek összesítése.
- Nem állít elő szemantikai pontosságot vagy AI-pontszámot.

#### Infinity AI Translation Engine – integrációs előkészítés
- A felület egyértelműen megkülönbözteti a szabályalapú kontextus-briefet a generatív AI-fordítástól.
- Valódi generatív szolgáltatás nincs bekapcsolva ebben a kiadásban; ehhez külön szolgáltatóadapter, kulcskezelés és adatvédelmi folyamat szükséges.

### Verzió és integráció
- versionName: 2.56.0
- versionCode: 5600
- A meglévő Platinum Intelligence Hub NextWaveToolsActivity útvonala változatlan.
- Új külső Android-függőség nem került hozzáadásra; a kiejtéshez a platform TextToSpeech API-ja használatos.

### Tesztelési státusz
A forráscsomag módosítva. A Kotlin/Android build és a fizikai eszközteszt eredményét külön kell igazolni. A TTS nyelvi adatainak megléte eszközfüggő.


---

<!-- forrás: NEXT_WAVE_V2.63_3.00_HU.md -->

## [NEXT_WAVE_V2.63_3.00_HU.md]

## Fejlesztési hullám lezárása – v2.63 → v3.00

| Verzió | Fejlesztés | Státusz |
|---|---|---|
| v2.63.0 | Learning Analytics Diamond | Kész |
| v2.64.0 | Smart Context + Translation Quality | Kész |
| v2.65.0 | Hybrid Engine + Motion/Global | Kész / részben |
| v2.66.0 | Platinum Global Dashboard | Kész |
| v2.67.0 | Performance & Regression Suite | Kész |
| **v3.00.0** | **Teljes Diamond integráció** | **Kész (forrásszintű kapu)** |

A kapu `DiamondIntegration.evaluate()` hívással ellenőrizhető. A View→Compose és az eszközös QA a kiadás előtti kötelező lépések maradnak.


---

<!-- forrás: PHASE4_FILE_MATRIX_HU.md -->

## [PHASE4_FILE_MATRIX_HU.md]

## Phase 4 – fájlszintű változásmátrix

| Fájl | Művelet | Hatás |
|---|---|---|
| `core/src/main/java/hu/angolmagyar/fordito/TranslationInvariantAudit.kt` | Új | Szám- és tagadáseltérés figyelmeztetése, offline |
| `core/src/main/java/hu/angolmagyar/fordito/AdaptiveReviewScheduler.kt` | Új | Determinisztikus ismétlési időpont-számítás |
| `core/src/test/java/hu/angolmagyar/fordito/TranslationInvariantAuditTest.kt` | Új | Audit regressziós tesztek |
| `core/src/test/java/hu/angolmagyar/fordito/AdaptiveReviewSchedulerTest.kt` | Új | Ütemező regressziós tesztek |
| `PLATINUM_INTELLIGENCE_8.0_PHASE4_HU.md` | Új | Műszaki és validációs dokumentáció |
| `CHANGELOG_PLATINUM_8.0_PHASE4_HU.md` | Új | Változásnapló |
| `PHASE4_FILE_MATRIX_HU.md` | Új | Fájl- és hatásmátrix |


---

<!-- forrás: PHASE4_VALIDATION_HU.md -->

## [PHASE4_VALIDATION_HU.md]

## Phase 4 – validációs jelentés

- Kotlin/JVM fordítás a két új platformfüggetlen osztályra: **PASS**.
- Futtatható smoke teszt: **PASS – 6 állítás** (számeltérés, tagadáseltérés, egyező tokenek, 1/6 napos intervallum, sikertelen ismétlés reset, esedékesség).
- `:core:test`: **BLOCKED** – Gradle 8.9 letöltése `UnknownHostException: services.gradle.org` miatt nem lehetséges ebben a környezetben.
- Teljes Android build/APK/eszközteszt: **NOT RUN**.
- Következtetés: a két új core komponens JVM-szinten fordul és smoke tesztelhető; teljes projektintegráció és kiadás előtti Android validáció még szükséges.


---

<!-- forrás: PHASE5_FILE_MATRIX_HU.md -->

## [PHASE5_FILE_MATRIX_HU.md]

## Phase 5 fájlmátrix
| Fájl | Művelet | Felelősség |
|---|---|---|
| `core/src/main/.../OfflineGlossaryAudit.kt` | Új | Offline terminológiai ellenőrzés |
| `core/src/main/.../OfflineMemoryRanker.kt` | Új | Offline memóriaelemek rangsorolása |
| `core/src/test/.../OfflineGlossaryAuditTest.kt` | Új | 5 terminológiai teszt |
| `core/src/test/.../OfflineMemoryRankerTest.kt` | Új | 3 rangsorolási teszt |
| `PLATINUM_INTELLIGENCE_8.0_PHASE5_HU.md` | Új | Műszaki leírás |
| `CHANGELOG_PLATINUM_8.0_PHASE5_HU.md` | Új | Változásnapló |


---

<!-- forrás: PHASE5_VALIDATION_HU.md -->

## [PHASE5_VALIDATION_HU.md]

## Phase 5 validációs jelentés

Dátum: 2026-10-31

### Lefuttatott ellenőrzések
- A két új Kotlin production osztály külön `kotlinc` fordítása: PASS.
- 5 független futó smoke assertion (hiányzó terminológia, kis-/nagybetű, több szavas kifejezés, szóhatár, rangsorolás): PASS.
- Forráscsomag ZIP CRC/integritás ellenőrzése: a csomagolás után futtatandó.

### Nem igazolt ellenőrzések
- A teljes Android/Gradle build és JUnit futtatás ebben a körben nem történt meg.
- APK telepítés, emulátor- és fizikai eszközteszt nem történt.
- A két új motor tiszta Kotlin API-ként került be; az alkalmazás UI/Room rétegébe történő bekötés nem része ennek a fázisnak.

### Biztonsági és offline megjegyzés
A hozzáadott kód nem használ hálózatot, nem végez automatikus szövegátírást, nem módosít meglévő adatbázis-sémát vagy jogosultságokat. A szótárbejegyzések hosszkorlátot kapnak; a találatok figyelmeztetések, nem automatikus javítások.


---

<!-- forrás: PHASE6_FILE_MATRIX_HU.md -->

## [PHASE6_FILE_MATRIX_HU.md]

## Phase 6 – fájlmátrix

| Fájl | Művelet | Szerep |
|---|---|---|
| `core/.../OfflineIntelligencePipeline.kt` | Új | Közös, tiszta offline API |
| `app/.../core/OfflineIntelligenceRepository.kt` | Új | Room adapter meglévő DAO-khoz |
| `core/src/test/.../OfflineIntelligencePipelineTest.kt` | Új | Integrációs core tesztek |
| `PLATINUM_INTELLIGENCE_8.0_PHASE6_HU.md` | Új | Műszaki dokumentáció |
| `CHANGELOG_PLATINUM_8.0_PHASE6_HU.md` | Új | Változásnapló |
| `PHASE6_FILE_MATRIX_HU.md` | Új | Fájlszintű áttekintés |
| `PHASE6_VALIDATION_HU.md` | Új | Validációs eredmények és korlátok |

Nem módosult: Room entitások, DAO-k, adatbázis-verzió, migrációk, jogosultságok és meglévő fordítási folyamat.


---

<!-- forrás: PHASE6_VALIDATION_HU.md -->

## [PHASE6_VALIDATION_HU.md]

## Phase 6 – validáció

### Sikeres ellenőrzések
- A Phase 6 core production Kotlin források (`TranslationInvariantAudit`, `AdaptiveReviewScheduler`, `OfflineGlossaryAudit`, `OfflineMemoryRanker`, `OfflineIntelligencePipeline`) `kotlinc` fordítása: PASS.
- Egyedi futó smoke teszt: PASS.
  - kombinált audit három figyelmeztetést adott a szándékosan eltérő példára;
  - tiszta audit nulla figyelmeztetést adott;
  - memória-rangsorolás stabil ID szerinti tie-breaket adott;
  - ismétlési ütemezés 1 napos intervallumot számolt.
- ZIP CRC ellenőrzés: a csomagolás után futtatandó / eredmény a kiadási összegzésben.

### Nem lefuttatott ellenőrzések
- JUnit tesztfuttatás: nem történt meg.
- `:app:compileDebugKotlin` Android build: megkísérelve, de a Gradle 8.9 disztribúció letöltése `UnknownHostException: services.gradle.org` hibával megállt; a fordítás nem indult el.
- APK build, emulátor- és fizikai eszközteszt: nem történt meg.

### Értelmezés
A core fordítás és smoke teszt igazolja az új tiszta Kotlin pipeline működését. Az Android repository fordítási kompatibilitása és az alkalmazás futásidejű integrációja külön, Gradle-képes Android környezetben ellenőrizendő.


---

<!-- forrás: PHASE7_FILE_MATRIX_HU.md -->

## [PHASE7_FILE_MATRIX_HU.md]

## Phase 7 – fájlmátrix

| Fájl | Művelet | Hatás |
|---|---|---|
| `ui/OfflineIntelligenceCenterActivity.kt` | Új | Felhasználói offline minőség- és memória-központ |
| `ui/PlatinumIntelligenceActivity.kt` | Módosítás | Új képernyő navigációs belépési pontja |
| `AndroidManifest.xml` | Módosítás | Activity `exported=false` regisztráció |
| `core/OfflineIntelligenceRepository.kt` | Módosítás | Helyi statisztikai darabszámok, limitált glossary scan |
| `core/db/DictionaryDao.kt` | Módosítás | Limitált friss szótári lekérdezés |

Nem módosult: adatbázis-séma/verzió, entitások, migrációk, fordítási motor, hálózati jogosultságok és meglévő adat-hozzáférési szabályok.


---

<!-- forrás: PHASE7_VALIDATION_HU.md -->

## [PHASE7_VALIDATION_HU.md]

## Phase 7 – validációs jelentés

### Elvégzett ellenőrzések
- A kiinduló Phase 6 ZIP archívum CRC-ellenőrzése sikeres volt.
- Forrásmódosítások után a Manifest és a Kotlin fájlok statikus ellenőrzése, valamint a ZIP archívum integritás-ellenőrzése szükséges a kiadás előtt.

### Nem lefuttatott ellenőrzések
- Android Gradle fordítás és Compose compiler: nem futott le, mert a Gradle Wrapper 8.9 letöltése `UnknownHostException: services.gradle.org` hibával leállt.
- JUnit, Robolectric és Compose UI tesztek: nem futottak.
- APK, emulátor és fizikai készülék teszt: nem futott.

### Kiadási státusz
Forráscsomagként átadható, de **nem minősíthető build-ellenőrzött vagy kiadásra kész APK-nak**. A képernyő végleges integrációját Android SDK-val és a projekt Gradle-függőségeivel rendelkező környezetben kell lefordítani és kipróbálni.


---

<!-- forrás: PLATINUM_6.0_ENGINEERING_FILE_INVENTORY_HU.md -->

## [PLATINUM_6.0_ENGINEERING_FILE_INVENTORY_HU.md]

## Platinum 6.0 Engineering – új / módosított fájlok listája

### Új fájlok
| Fájl | Fázis |
|---|---|
| `app/.../TranslationIntelligence.kt` | P2–P3 |
| `app/.../LiveTranslationHints.kt` | P5 |
| `app/.../MeetingWorkflow.kt` | P5–P7 |
| `app/.../ui/design/AccessibilityKit.kt` | P10 |
| `app/.../sync/SyncContract.kt` | P9 |
| `app/.../capture/CaptureContracts.kt` | P8 |
| `app/src/test/.../TranslationIntelligenceTest.kt` | P2–P3 |
| `app/src/test/.../MeetingWorkflowTest.kt` | P5–P7 |
| `app/src/test/.../ui/design/AccessibilityKitTest.kt` | P10 |
| `app/src/test/.../sync/SyncContractTest.kt` | P9 |
| `app/src/test/.../capture/CaptureContractsTest.kt` | P8 |
| `CHANGELOG_V4.2.6_PLATINUM_6.0_ENGINEERING_HU.md` | Dok |
| `RELEASE_CHECKLIST_6.0_RC_HU.md` | Dok |
| `PLATINUM_6.0_ENGINEERING_FILE_INVENTORY_HU.md` | Dok |

### Jelentősen módosított
| Fájl | Változás |
|---|---|
| `SmartTranslationMemoryStore.kt` | Fail-closed olvasás (korábbi engineering fix) |
| `PremiumTranslationCard.kt` | Memória / minőség / kontextus UI |
| `PhrasebookStore.kt` | SpacedRepetition SM-2 |
| `PhrasebookActivity.kt` | Ismétlési mód |
| `TranscriptDetailActivity.kt` | MeetingWorkflow minőség az összefoglalóban |
| `DiagnosticsActivity.kt` | Accessibility checklist |
| `PlatinumIntelligenceActivity.kt` | Hub státuszok |
| `PLATINUM_INTELLIGENCE_6.0_STATUS_HU.md` | Státuszmátrix |
| `VALIDATION_REPORT_4.2.6_HU.md` | Frissített kapuk |
| `BUILD_STATUS_4.2.6_HU.md` | Build osztályozás |
| `README.md` | Engineering átadás |


---

<!-- forrás: PLATINUM_7.0_PHASE1_VALIDATION_HU.md -->

## [PLATINUM_7.0_PHASE1_VALIDATION_HU.md]

## Platinum Intelligence 7.0 – Phase 1 validációs jelentés

Dátum: 2026-10-31
Kiinduló forrás: AngolMagyar 4.2.6 / Platinum Intelligence 6.0 Engineering Fixed-5

### Elkészült forrásmódosítások

1. `core/src/main/java/hu/angolmagyar/fordito/PlatinumWorkflow.kt`
   - Determinisztikus workflow definíció-validáció és ciklusészlelés.
   - Offline és hálózati lépéskorlátok, helyi capability ellenőrzés.
   - Start, complete, fail, retry és cancel állapotátmenetek.
   - Szövegfordítási és hangból felirat workflow sablon.
2. `core/src/main/java/hu/angolmagyar/fordito/TranslationWorkspace.kt`
   - Fordítási változatok és stílusmetaadatok.
   - Append-only revíziókezelés; visszaállítás új revízió létrehozásával.
   - Token-alapú diff, nagy bemenetnél memória-korlátos fallback.
   - A meglévő `TranslationQualityAudit` használata.
3. Két új tesztosztály, összesen 11 tesztmetódussal.

### Ellenőrzések

| Ellenőrzés | Eredmény | Megjegyzés |
|---|---|---|
| Teljes core Kotlin forrás fordítása `kotlinc`-kel | PASS | JDK 21; 3 meglévő figyelmeztetés |
| Új tesztforrások szintaxis/típusellenőrzése | PASS | Könnyű JUnit API stubbal |
| Új tesztmetódusok futtatása | PASS 11/11 | Reflection harness + JUnit API-kompatibilitási stub; nem Gradle/JUnit runner |
| Workflow/workspace smoke teszt | PASS | Külön futtatható smoke harness |
| Release/security statikus ellenőrző | PASS | `tools/verify_release_security.py` |
| Python segédprogramok compileall | PASS | `tools/` |
| Android XML parse | PASS | 38 XML |
| Gradle `:core:test` / app build | NEM FUTOTT | Gradle 8.9 disztribúció/cache nem elérhető ebben a környezetben |
| APK/AAB és fizikai eszközteszt | NEM FUTOTT | Nem állítható kiadáskésznek |

### Korlátozások / következő hullám

- A workflow motor jelenleg core állapotgép; a tényleges ASR/fordító/felirat motorokhoz adapter és tartós checkpoint store szükséges.
- A fordítási revíziótár jelenleg memóriabeli referenciaadapter; Room/Keystore-alapú tartós tárolás és UI bekötés hátravan.
- Nem módosult az Android `applicationId`, `versionName=4.2.6`, `versionCode=40406`, SDK-konfiguráció vagy manifest permission.
- Nem készült APK; ez Phase 1 forráscsomag, nem teljes Platinum 7.0 release.


---

<!-- forrás: PLATINUM_INFINITY_AI_MASTER_V2.60.0_HU.md -->

## [PLATINUM_INFINITY_AI_MASTER_V2.60.0_HU.md]

## PLATINUM INFINITY AI MASTER – v2.60.0

### Elkészült: Infinity Backup Center

A felhasználó által kiválasztott JSON-fájlba exportálható, illetve onnan visszaállítható:
- saját szótár (`dictionary_entries`),
- fordítási memória (`translation_memory`),
- adaptív ismétlési ütemezés (`review_schedule`).

#### Biztonsági és adatvédelmi működés
- A fájlkezelő helyválasztása Android SAF-en keresztül történik.
- A mentés helyben készül; a funkció nem küld adatot hálózaton keresztül.
- A visszaállítás csak támogatott formátum- és verzióazonosítóval indulhat.
- A JSON méretkorlátja 20 MB, a rekordszám táblánként legfeljebb 100 000.
- A három adattábla visszaállítása egy Room-tranzakcióban történik.
- Hibás mentés esetén a tranzakció visszagörgeti a módosításokat.

#### Nem része a mentésnek
Médiafájlok, letöltött beszédfelismerő-modellek, alkalmazásbeállítások, titkos kulcsok és külső szolgáltatói hitelesítő adatok.

#### Következő lépések
- Titkosított backup opció felhasználói jelszóval.
- Automatikus, ütemezett helyi mentés.
- Visszaállítás előtti tartalmi előnézet és összevonási mód.
- Tanulási dashboard a Room-adatokból számolt mutatókkal.


---

<!-- forrás: PLATINUM_INFINITY_SOVEREIGN_AI_V2.59.0_HU.md -->

## [PLATINUM_INFINITY_SOVEREIGN_AI_V2.59.0_HU.md]

## PLATINUM INFINITY SOVEREIGN AI – v2.59.0

### Memory Coach – adaptív szókártya-ismétlés

A v2.58.0-ban létrejött saját Room-szótár mostantól ismétlési munkafolyamatot is kapott. Az Intelligens ismétlő a saját szótár elemeiből hoz létre helyi kártyákat, megmutatja a magyar jelentést, majd négy értékelési lehetőséggel ütemezi a következő ismétlést.

#### Ütemezési szabályok
- Újra (0–2): ismétlésszám nullázása, következő ismétlés 1 nap múlva.
- Nehéz (3): sikeres ismétlés, konzervatív intervallum.
- Jó (4) és Könnyű (5): SM-2 ihletésű intervallumnövelés.
- Az ease factor 1,3 alá nem csökken.

#### Adattárolás
- Room schema 3.
- Migráció 2 → 3 kizárólag új `review_schedule` táblát és indexet ad hozzá.
- A fordítási memória és a saját szótár rekordjai változatlanul megmaradnak.

#### Korlátok
- Az ütemező nem generatív AI, hanem átlátható, determinisztikus algoritmus.
- A szavak az alkalmazás saját szótárából kerülnek a gyakorlóba.
- Az alkalmazás nem küld tanulási adatokat külső szolgáltatásnak.
- APK-build és fizikai eszközteszt csak sikeres Android buildkörnyezetben igazolható.


---

<!-- forrás: PLATINUM_INFINITY_SOVEREIGN_V19_HU.md -->

## [PLATINUM_INFINITY_SOVEREIGN_V19_HU.md]

## Platinum Ultra Extreme v19 — Infinity Sovereign Edition

### Ebben a csomagban

A v18 Infinity Luxury Plus forrására épülő, kompatibilitást szem előtt tartó fejlesztési csomag. A meglévő fordítási, beszédfelismerési, felirat-, dokumentum- és diagnosztikai funkciók megőrzése volt az elsődleges szempont.

#### Újonnan beépített
- **Globális Infinity Luxury palettaválasztó** a Beállításokban: Platinum Silver, Obsidian Black, Royal Gold, Arctic Diamond és Midnight Sapphire.
- **Közös LuxuryPalettes tokenrendszer** a Compose prémium kártyák felületeihez, fényeihez és kereteihez.
- **Tartós témaválasztás** SharedPreferences-alapon, alkalmazás-újraindítás után is.
- **Verzióemelés** 2.49.0 / versionCode 4900.
- **Megőrzött csökkentett animációs beállítás**: a palettaváltás nem kapcsolja ki vagy írja felül ezt a beállítást.

#### A v18-ból megtartott képességek
- Material 3 / Compose kezdőképernyő és prémium kártyarendszer.
- Animált felület és csökkentett mozgás opció.
- Élő hangfordítás, hangfelvétel és hanghullám-vizualizáció.
- Dokumentum-/feliratfordítás, SRT-munkafolyamatok és folyamatjelzők.
- Fordítási előzmények, szótár-/kifejezéskönyv és kedvencek.
- Diagnosztika, adatvédelmi képernyő, offline/online szolgáltatások beállításai.

### A 12 fejlesztési javaslat státusza

1. **Infinity Glass Luxury Design** — továbbépítve a meglévő PremiumCard felületén; a kiválasztott paletta meghatározza a kártyák színét és fénykeretét.
2. **Cinematic Micro-Animations** — a meglévő mozgásrendszer és csökkentett animációs mód megtartva.
3. **Smart Language Intelligence** — meglévő fordítási, nyelvazonosítási, szótár- és memóriafunkciók megtartva; új külső AI-szolgáltatás nincs automatikusan bekötve.
4. **Platinum Command Center** — meglévő Compose kezdőlap és gyorsműveleti kártyák megtartva.
5. **Adaptive Luxury Themes** — öt paletta választása és mentése hozzáadva. A globális paletta jelenleg a Compose prémium kártyákra vonatkozik; a teljes régi View-alapú képernyők egységesítése külön migrációs feladat.
6. **Translation Cards 2.0** — a meglévő prémium fordítási kártya, másolási és kapcsolódó műveletek megtartva.
7. **Voice Studio Ultra** — a meglévő élő fordítási/hangfelületek és hullámnézet megtartva.
8. **Document Translation Pro** — a meglévő dokumentum-/feliratfeldolgozási folyamatok megtartva.
9. **Ultra Premium Navigation** — a meglévő kezdőlap és képernyőnavigáció megtartva.
10. **Trust & Transparency Center** — meglévő adatvédelmi és diagnosztikai képernyők megtartva.
11. **Performance Engine** — meglévő teljesítmény- és csökkentett animációs megoldások megtartva; külön eszközprofilos benchmark futtatása javasolt.
12. **Signature Infinity Experience** — egységes paletta-tokenekkel továbbfejlesztve; a teljes alkalmazás minden régi képernyőjének egységesítése fokozatosan végezhető el.

### Fontos műszaki megjegyzés

A témaválasztás jelenleg a Compose `PremiumCard` elemek színvilágát állítja. A régi Android View-alapú képernyők külön témákat/komponenseket használhatnak. Nem állítjuk, hogy az összes funkció Androidon le lett fordítva vagy eszközön tesztelve: a build ellenőrzéséhez Android SDK-val rendelkező környezet szükséges.

### Build és ellenőrzés

A projekt gyökeréből:

```bash
./gradlew :app:assembleDebug :wear:assembleDebug
./gradlew :app:testDebugUnitTest
```

Ha a build hibát jelez, először az Android SDK / Gradle / JDK verzióit, majd a konkrét fordítási hibát kell ellenőrizni. Telepítés előtt érdemes mentést készíteni a korábbi APK-ról és alkalmazásadatokról.


---

<!-- forrás: PLATINUM_INFINITY_SOVEREIGN_V20_HU.md -->

## [PLATINUM_INFINITY_SOVEREIGN_V20_HU.md]

## Platinum Ultra Extreme v20 — Infinity Sovereign Global Theme

### Újdonságok a v19-hez képest

- **Valódi globális Compose témázás:** az öt kiválasztott Infinity paletta mostantól a Material 3 `primary`, `secondary`, `background`, `surface`, `outline` és szövegszíneit is vezérli.
- **Platinum kapcsoló tiszteletben tartása:** ha a Platinum Luxury téma ki van kapcsolva, a korábbi Blue Cinematic / rendszerfüggő téma marad érvényben.
- **OLED mód:** a fekete háttér beállítás továbbra is feketévé teszi a fő felületi hátteret.
- **Csökkentett mozgás javítása:** a prémium kártyák belépő animációja is kikapcsol, ha a csökkentett animáció aktív.
- **Verzió:** 2.50.0 / versionCode 5000.

### Ellenőrzési állapot

A forrásmódosítások elkészültek. A teljes Android buildet és eszköztesztet külön, Android SDK-val rendelkező környezetben kell lefuttatni.

```bash
./gradlew :app:assembleDebug :wear:assembleDebug
./gradlew :app:testDebugUnitTest
```

### Megjegyzés

A klasszikus Android View-alapú képernyők saját témakezelést is használhatnak. Ez a kiadás a Compose Material 3 témát teszi valóban palettafüggővé; a teljes régi képernyők migrációja további, képernyőnkénti feladat.


---

<!-- forrás: PLATINUM_INFINITY_SOVEREIGN_V21_HU.md -->

## [PLATINUM_INFINITY_SOVEREIGN_V21_HU.md]

## Platinum Ultra Extreme v21 — Infinity Sovereign Theme Refresh

### Újdonság

A kiválasztott globális Luxury téma mostantól nemcsak mentésre kerül, hanem a fő Compose-felületre való visszatéréskor automatikusan érvényesül. Ugyanez igaz a Platinum téma és az OLED fekete mód beállításaira.

### Működés

- A főképernyő rögzíti az alkalmazott témabeállítások egyszerű aláírását.
- `onResume()` összehasonlítja a mentett beállításokat az utoljára alkalmazott értékekkel.
- Csak valódi változás esetén történik `recreate()`, és az összehasonlítási állapot előre frissül.
- A Blue Cinematic / rendszerfüggő mód továbbra is elérhető a Platinum téma kikapcsolásával.

### Korlátok

Ez a frissítés a Compose Material 3 felületre vonatkozik. A klasszikus Android View képernyők külön színrendszerének teljes egységesítése további munkát igényel. A csomag Android buildje itt nem igazolt; telepíthető APK-nak csak sikeres helyi/CI build után tekinthető.


---

<!-- forrás: PLATINUM_INFINITY_V22_HU.md -->

## [PLATINUM_INFINITY_V22_HU.md]

## Platinum Ultra Extreme v22 — Infinity Palette Preview

### Új fejlesztések
- A Beállításokban mind az öt Infinity Luxury paletta saját színátmenetes előnézetet kapott.
- A palettaválasztók minimum 48 dp magas érintési célterületet használnak, és tartalmaznak akadálymentes leírást.
- A színcsíkok a paletta hátterét, fő kiemelőszínét és fény-/másodlagos színét jelzik.
- Az alkalmazás verziója 2.52.0-ra (versionCode 5200) emelkedett.

### Megőrzött működés
A kiválasztás továbbra is a meglévő `luxuryThemeId` preferenciába mentődik. A fő Compose-felület a Beállításokból való visszatéréskor az Activity újraépítésével alkalmazza a változtatást.

### Korlátok és ellenőrzés
Ez a csomag forráskód. Az Android-fordítás csak olyan környezetben ellenőrizhető, ahol a Gradle wrapper és a függőségek elérhetők. A klasszikus Android View-képernyők teljes körű paletta-migrációja még nem része ennek a verziónak.


---

<!-- forrás: PLATINUM_INFINITY_V23_INTELLIGENCE_SUITE_HU.md -->

## [PLATINUM_INFINITY_V23_INTELLIGENCE_SUITE_HU.md]

## Platinum Ultra Extreme v23 — Infinity Intelligence Suite

Verzió: **2.53.0** · versionCode: **5300**

### Ebben a kiadásban ténylegesen módosult

- Új **Platinum Intelligence Suite** központ, a főképernyőről elérhető.
- A központ közvetlen hivatkozásokat ad a már létező élő fordítás, felirat/média, szókincstár, átiratok, modellek, adatvédelem és diagnosztika képernyőkhöz.
- A központ a meglévő funkciókat elkülöníti a részben kész és még fejlesztendő képességektől; nem jelöli késznek a nem létező funkciókat.
- Az Infinity Luxury paletta immár a közös `Ui.color()` útvonalon a klasszikus View-képernyők fő háttér-, kártya-, szöveg-, szegély- és kiemelőszíneire is kiterjed, amikor a Platinum téma aktív.
- A Compose Material 3 téma és a prémium kártyák továbbra is a kiválasztott öt Luxury palettát használják.
- Verzióemelés 2.53.0 / 5300.

### A 25 javaslat állapota

Az állapotok a forráskód jelenlegi képességeit jelölik, nem ígért vagy dekoratív funkciókat.

| # | Javaslat | v23 állapot |
|---|---|---|
| 1 | Infinity Dynamic UI | Továbbfejlesztve: a paletta a Compose és a közös View-színsegéd több fő színére kiterjed; egyes képernyőkben vannak még fix színek. |
| 2 | Platinum Motion Engine | Részleges: több képernyőn animáció és csökkentett mozgás beállítás van; teljes egységes motor még nincs. |
| 3 | Ultra Dashboard 2.0 | Részleges: meglévő főképernyő + új Intelligence Suite belépő. Teljesen testreszabható elrendezés még nincs. |
| 4 | Platinum Icon System | Részleges: meglévő Material ikonok; teljes egységes egyedi ikoncsalád nincs. |
| 5 | Adaptive Luxury Layout | Részleges: egyes képernyők szélességkorlátot használnak; teljes kétpaneles tablet-nézet nincs. |
| 6 | Smart Context Translation | Fejlesztendő: nincs teljes, kontextust értékelő motor. |
| 7 | Platinum Translation Score | Fejlesztendő: nincs megbízható, kalibrált minőségi pontszám. |
| 8 | Dual Translation Engine | Fejlesztendő: nincs teljes, két motoros összehasonlító munkafolyamat. |
| 9 | Platinum Dictionary Pro | Részleges: szókincstár és mentett kifejezések léteznek; teljes lexikai szótár még nincs. |
| 10 | Phrase Intelligence | Részleges: szókincstár és fordítási alapok megvannak; teljes idióma-/kifejezésmagyarázat nincs. |
| 11 | Infinity Voice Studio | Részleges: élő fordítás, beszédfelismerés és TTS-alapok léteznek. |
| 12 | Live Conversation Mode | Meglévő alapfunkció; megszakítási, életciklus- és fizikai eszközteszt még szükséges. |
| 13 | Pronunciation Coach | Fejlesztendő: nincs megbízható fonetikai kiejtés-pontozás. |
| 14 | Offline Voice Pack | Részleges: helyi modellek kezelése létezik; minden hangfunkció teljes offline lefedettsége nem garantált. |
| 15 | Smart Listening Mode | Részleges: hangfelismerési/átirat-folyamatok vannak; dedikált, végigcsiszolt hallgatási mód nincs. |
| 16 | Platinum Document Translator | Részleges: média-/felirat-feldolgozás van; általános PDF/DOCX fordító nem tekinthető teljesnek. |
| 17 | Infinity OCR Scanner | Fejlesztendő: ebben a kiadásban nincs igazolt teljes OCR munkafolyamat. |
| 18 | Subtitle Translator | Részleges/alapfunkció elérhető a felirat- és SRT-eszközökben; teljes formátum-regresszióteszt szükséges. |
| 19 | Batch Translation Center | Részleges: kötegelt feladat- és médiafeldolgozási alapok vannak; általános többdokumentumos fordítóközpont nincs. |
| 20 | Translation Export Studio | Részleges: meglévő exportsegédek; minden felsorolt formátum és formázásmegőrzés nincs igazolva. |
| 21 | Platinum Performance Center | Részleges: diagnosztika és mérési segédek vannak; hiteles, teljesítmény-mutatókkal alátámasztott központ még fejlesztendő. |
| 22 | Smart Cache System | Részleges: meglévő fordítási memória/gyorsítótár-alapok; egységes szabályozható cache-vezérlés még nincs. |
| 23 | Privacy & Security Center | Részleges: adatvédelmi képernyő és helyi adatokkal kapcsolatos beállítások léteznek; teljes adatfolyam-audit szükséges. |
| 24 | Automated Quality Testing | Részleges: unit tesztek vannak; build és teljes készülékes regresszióteszt nem igazolt. |
| 25 | Platinum Accessibility Suite | Részleges: akadálymentességi leírások és csökkentett animáció léteznek; teljes WCAG/Android accessibility audit nincs. |

### Fordítási / tesztállapot

A csomag szerkezeti ellenőrzése és XML-manifest parse-ellenőrzése elvégezhető helyben. Az Android/Kotlin buildet megkíséreltük, de a Gradle wrapper nem tudta letölteni a Gradle 8.9 disztribúciót, mert a környezet nem érte el a `services.gradle.org` címet (`UnknownHostException`). Emiatt a Kotlin-fordítás és az APK futása **nincs igazolva**. A v23 forráscsomag, nem tesztelt telepítő APK.

### Javasolt build-ellenőrzés fejlesztői gépen

```bash
./gradlew :app:assembleDebug :wear:assembleDebug
./gradlew :app:testDebugUnitTest
```


---

<!-- forrás: PLATINUM_INTELLIGENCE_6.0_FILE_MATRIX_HU.md -->

## [PLATINUM_INTELLIGENCE_6.0_FILE_MATRIX_HU.md]

## Platinum Intelligence 6.0 – fájlszintű státuszmátrix

Státuszjelölés: **MEGLÉVŐ** = forrásban megtalálható; **JAVÍTVA** = ebben a csomagban ténylegesen módosítva; **TERVEZETT** = még implementálandó; **FELTÉTELES** = külső szolgáltató/backend vagy eszközfüggő.

| Fájl / terület | Kiinduló szerep | 6.0 feladat | Státusz ebben a csomagban |
|---|---|---|---|
| `app/build.gradle.kts` | Android build, signing, dependencies | Release signing és dependency audit | MEGLÉVŐ, auditálva; build nem futott |
| `AndroidManifest.xml` | Permission, exported komponensek, provider | Exported allowlist és permission regresszió | MEGLÉVŐ, statikus ellenőrző védi |
| `SecretStore.kt` | AES-GCM Android Keystore | Fail-closed titoktárolás | MEGLÉVŐ, statikusan ellenőrizve |
| `SmartTranslationMemoryStore.kt` | Titkosított fordítási memória | Dekódolási hiba esetén blob megőrzése, mutáció megszakítása | **JAVÍTVA** |
| `core/SmartTranslationMemory.kt` | Platformfüggetlen pontos memóriaegyezés | Projektprioritás, jóváhagyás, kétértelműség | MEGLÉVŐ |
| `core/SmartContextTranslation.kt` | Kontextusérzékeny fordítás | Egységes request/pipeline integráció | TERVEZETT |
| `TranslateService.kt`, `Engines.kt`, `PolyEngine.kt` | Fordítási pipeline | Offline/online útvonal, memória és quality integráció | TERVEZETT |
| `TranslationQuality.kt`, `TranslationCheck.kt`, `TranslationQualityAudit.kt` | Fordításminőség ellenőrzés | Súlyosság/eredet egységesítése és UI-integráció | MEGLÉVŐ, integráció TERVEZETT |
| `ReviewIntelligence.kt`, `SpacedRepetition.kt`, `UltimateLearningEngine.kt` | Tanulási ütemezés | Közös tanulási események | MEGLÉVŐ, integráció TERVEZETT |
| `LearningAnalyticsStore.kt`, `LearningAnalyticsActivity.kt` | Tanulási analitika | Tényleges eseményekből számolt célok/statisztika | MEGLÉVŐ, bővítés TERVEZETT |
| `AudioRecorder.kt`, `LiveWhisperAsr.kt`, `SystemAsr.kt` | Helyi beszédfelismerés | Lifecycle/permission/benchmark | MEGLÉVŐ, hardening TERVEZETT |
| `PronunciationAssessment.kt` | Kiejtés/átirat metrikák | Fonetikai és ASR-metrika szétválasztása | MEGLÉVŐ, validáció TERVEZETT |
| `FileSubtitleActivity.kt`, `SrtEditorActivity.kt`, `SrtJobService.kt` | Felirat workflow | Undo/redo, wave timeline, autosave és round-trip | MEGLÉVŐ, bővítés TERVEZETT |
| `MeetingMode.kt`, `MeetingSummary.kt` | Meeting domain | Teljes átirat–összefoglaló folyamat | MEGLÉVŐ, integráció TERVEZETT |
| `CameraTranslateActivity` (új) | Nincs jelen | CameraX + OCR + engedélykezelés | TERVEZETT |
| `DocumentImportCoordinator` (új) | Nincs igazolt import pipeline | PDF/DOCX/TXT import/export | TERVEZETT |
| `SyncContract` (új) | Nincs backend | Backendfüggetlen szerződés, konfliktusmodell | FELTÉTELES |
| `PremiumDesignSystem.kt`, `Theme.kt` | Több design token és Compose theme | Egységes képernyőmigráció | MEGLÉVŐ, migráció TERVEZETT |
| `README.md`, státusz- és tervdokumentumok | Projektleírás | Verzió és készültség pontosítása | **JAVÍTVA** |
| projektgyökér könyvtár | ZIP-ben `4.2.5` nevet viselt | `4.2.6` elnevezés | **JAVÍTVA** |

### Változatlanul megőrzendő elemek

- `applicationId=hu.angolmagyar.fordito`
- `versionName=4.2.6`, `versionCode=40406` (amíg migrációs kiadás nincs)
- `minSdk=29`, `targetSdk=35`, `compileSdk=35`
- `:app`, `:core`, `:wear` modulok
- Offline ASR/fordítási és modellletöltési útvonalak
- Meglévő adatbázisok, export formátumok és alkalmazásfájlok
- Release kulcs hiányában unsigned release; debug kulcs soha nem lehet release kulcs
- `allowBackup=false`, nem exportált belső komponensek és FileProvider jogosultsági határai

### Fontos

A „MEGLÉVŐ” nem azonos azzal, hogy minden eszközön hibátlanul működik. A státusz forráskód jelenlétet jelez. A működéshez a tesztterv és a kiadási jegyzőkönyv szükséges.


---

<!-- forrás: PLATINUM_INTELLIGENCE_6.0_IMPLEMENTATION_PLAN_HU.md -->

## [PLATINUM_INTELLIGENCE_6.0_IMPLEMENTATION_PLAN_HU.md]

## AngolMagyar Platinum Intelligence 6.0 – fájlszintű megvalósítási terv

### 0. Verziózási és minőségi döntés

A „6.0” fejlesztési célverzió, nem az alkalmazás jelenlegi Android-verziója. A kiinduló alkalmazás `versionName=4.2.6`, `versionCode=40406`; ezek, az `applicationId`, a meglévő adatbázisok, a fájlformátumok és a debug/release aláírási szabályok a 6.0 fejlesztési ág első stabil mérföldkövéig változatlanok. A verziókód emelése csak külön migrációs és frissítési teszt után történhet.

**Nem cél egyetlen lépésben minden funkciót bekapcsolni.** A 6.0 egy minőségkapukkal felépített program: minden fázis külön buildelhető, tesztelhető és visszagörgethető. Külső szolgáltató, backend vagy kamera/dokumentum parser nélkül az adott funkció nem jelenhet meg működőként.

### 1. Alapelvek és architekturális korlátok

1. Offline-first: a fordítás, szótár, tanulás, feliratfeldolgozás, helyi előzmények és mentés internet nélkül használható marad. Hálózati funkció opcionális, explicit online állapotot és felhasználói jóváhagyást igényel.
2. Nincs csendes adatvesztés: hibás/ideiglenesen hozzáférhetetlen titkosított tár nem értelmezhető üres tárként. Írási művelet olvasási hiba után megszakad.
3. Nincs titok plaintext fallbackkel: API-kulcs csak Android Keystore AES-GCM útvonalon tárolható.
4. Nincs automatikus felülírás: jóváhagyott fordítás, kézi szerkesztés és projektterminológia védett; memória csak javaslat.
5. Mérőszámok forrása látható: becsült minőség, ASR-konfidencia, WER/CER és fonetikai pontosság nem keverhető.
6. Nincs késznek jelölés build, teszt és valós készülékes ellenőrzés nélkül.
7. Kifelé irányuló adatküldés, mikrofon, kamera és felhőszinkron csak explicit, visszavonható felhasználói művelettel történhet.

### 2. Fázisok

#### P0 – Forrás- és kiadási stabilizálás (első kötelező fázis)

**Cél:** reprodukálható forrásállapot, verziókonzisztencia, regresszióvédelem.

| Fájl | Változtatás |
|---|---|
| `README.md`, `CHANGELOG_V4.2.6_HU.md`, `BUILD_STATUS_4.2.6_HU.md`, `VALIDATION_REPORT_4.2.6_HU.md` | Tényleges `4.2.6 / 40406` verzió rögzítése; build és készülékteszt státuszának pontos megjelölése. |
| `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, `core/build.gradle.kts`, `wear/build.gradle.kts` | Plugin/dependency verziók és SDK/JDK/NDK mátrix auditja; verziófrissítés csak kompatibilitási teszt után. |
| `.github/workflows/build.yml` | Core teszt, app teszt, debug app, Wear debug és unsigned release build; tesztartefaktumok megőrzése. |
| `tools/verify_release_security.py` | Exported komponensek, FileProvider, backup tiltás, cleartext, release signing és titkosított memória invariánsok ellenőrzése. |
| `.gitignore` | Keystore, lokális SDK és titkos konfiguráció kizárása. |
| `gradle/wrapper/gradle-wrapper.properties`, `gradle/wrapper/gradle-wrapper.jar` | Wrapper-disztribúció és wrapper JAR integritásának rögzítése; Gradle 8.9 checksum ellenőrzés CI-ben. |

**Elfogadás:** tiszta CI-ben teljes build és teszt; az unsigned release nem kap debug kulcsot; a forrásban nincs kulcs/jelszó; a verzióadatok konzisztensen egyeznek.

#### P1 – Privacy Vault és helyi adattárolás

| Fájl | Változtatás |
|---|---|
| `app/.../SecretStore.kt` | AES-GCM, migráció, kulcs-invalidation és hibakezelés; plaintext fallback tilos. |
| `app/.../SmartTranslationMemoryStore.kt` | Titkosított blob megőrzése dekódolási hiba esetén; módosító művelet megszakítása, nincs „üres tár” felülírás. |
| `app/.../AuditLog.kt`, `DiagLog.kt`, `PrivacyActivity.kt` | Naplóredakció, törlési/megőrzési felület, diagnosztika személyes szöveg és titok nélkül. |
| `app/.../BackupHelper.kt`, `intelligence/SecureBackupArchive.kt`, `intelligence/BackupArchive.kt`, `ui/BackupCenterActivity.kt` | Mentés-visszaállítás verziózott manifesttel, méretlimittel, integritásellenőrzéssel és titkosítási hibánál fail-closed működéssel. |
| `app/src/main/res/xml/file_paths.xml`, `AndroidManifest.xml` | FileProvider csak szükséges könyvtárakat osszon meg; exportált komponensek allowlistje változatlanul explicit. |

**Elfogadás:** hibás jelszó, sérült blob, hiányzó/invalidált Keystore-kulcs, részleges írás és visszaállítás esetén nincs plaintext fallback, nincs csendes adatvesztés.

#### P2 – Context AI és Translation Memory integráció

| Fájl | Változtatás |
|---|---|
| `core/.../SmartContextTranslation.kt` | Közös `ContextRequest`: előző/következő mondat, projekt, beszélő, stílus, jóváhagyott terminológia. |
| `core/.../SmartTranslationMemory.kt`, `app/.../SmartTranslationMemoryStore.kt` | Pontos nyelvpár és pontos normalizált szegmens; projektmemória elsőbbsége; csak APPROVED javaslat; kétértelmű egyezés jelzése. |
| `core/.../TranslationStyle.kt`, `TranslationQuality.kt`, `TranslationCheck.kt`, `TranslationQualityAudit.kt` | Stílus- és minőségi jelzések közös adatmodellje, eredet/súlyosság mezőkkel. |
| `app/.../TranslateService.kt`, `Engines.kt`, `PolyEngine.kt`, `OnlineSettingsDialog.kt` | Pipeline adapter: offline motor elsődleges; online/generatív motor külön opt-in. |
| `app/.../MainActivity.kt`, `ui/design/PremiumTranslationCard.kt` | Memóriajavaslat, eredet, bizonytalanság, jóváhagyás/elutasítás és kézi szerkesztés UI. |
| `core/src/test/.../SmartContextTranslationTest.kt`, `SmartTranslationMemoryTest.kt` és app tesztek | Kontextus, nyelvpár, projektütközés, jóváhagyás, kézi felülírás és offline fallback tesztje. |

**Elfogadás:** az offline fordítás nem függhet hálózattól; a memória nem cserélheti le automatikusan a fordítást; a kézzel jóváhagyott változat megmarad.

#### P3 – Translation Quality Intelligence

| Fájl | Változtatás |
|---|---|
| `core/.../TranslationQuality.kt`, `TranslationCheck.kt`, `TranslationQualityAudit.kt`, `LineQuality.kt`, `Hallucination.kt` | Számok, nevek, tagadás, kihagyás/duplikáció, terminológia, nyelvtan és írásjelek ellenőrzése. |
| `core/.../GoldenWer.kt`, `WordErrorRate.kt`, `TextMetrics.kt` | Csak ellenőrzött referenciaátirattal számolt WER/CER; becsült pontszám külön. |
| `app/.../SrtBuild.kt`, `SrtEditorActivity.kt`, `ReviewSheet.kt` | Soronkénti jelzés, forrás-eredet, hangrészlet-visszajátszás és jóváhagyott javítás. |
| `app/src/test/.../HallucinationTest.kt`, `TranslationCheckTest.kt`, `LineQualityTest.kt` | Negáció, számok, nevek, rövid sorok, üres kimenet és hiányzó mondat regressziós mátrix. |

**Elfogadás:** a felület nem nevez heurisztikát „AI-bizonyosságnak”; a mérőszám forrása megjelenik; hibás ellenőrzés nem módosítja a forrást.

#### P4 – Personal Learning Intelligence és offline Coach

| Fájl | Változtatás |
|---|---|
| `core/.../review/ReviewIntelligence.kt`, `intelligence/SpacedRepetition.kt`, `ultimate/UltimateLearningEngine.kt` | Egységes, determinisztikus tanulási esemény- és ismétlési szabályok. |
| `app/.../VocabLearner.kt`, `PhrasebookStore.kt`, `GlossaryStore.kt` | Fordítási hibából tanulókártya csak felhasználói megerősítéssel; aktív/passzív szókincs elkülönítése. |
| `app/.../intelligence/LearningAnalyticsStore.kt`, `LearningStats.kt`, `ui/LearningAnalyticsActivity.kt`, `ui/ReviewCoachActivity.kt` | Napi/heti célok, tényleges eseményekből számolt grafikonok, kihagyott napok büntetésének elkerülése. |
| Új `core/.../OfflineCoach.kt` és tesztje | Helyi szabályalapú feladatgenerálás és előre definiált szerepjátékok; internet és generatív modell nélkül is működőképes. |
| `app/.../MainActivity.kt`, `ui/PlatinumIntelligenceActivity.kt` | Coach felület és tanulási terv bekötése. |

**Elfogadás:** minden statisztika visszavezethető mentett eseményre; az offline Coach nem állít generatív AI képességet; ütemezés stabil és tesztelt.

#### P5 – Voice & Pronunciation Intelligence

| Fájl | Változtatás |
|---|---|
| `app/.../AudioRecorder.kt`, `AudioHelper.kt`, `RecognitionHelper.kt`, `LiveWhisperAsr.kt`, `SystemAsr.kt` | Lifecycle, megszakítás, permission-visszavonás, audio erőforrás-felszabadítás és offline modellállapot. |
| `app/.../intelligence/PronunciationAssessment.kt`, `SpeakerDiarizer.kt`, `SpeakerTracker.kt` | ASR egyezés, beszédtempó, szünet és fonetikai metrika külön; csak validált metrika jelenhet meg pontszámként. |
| `app/.../TtsHelper.kt`, `AsrPrefs.kt`, `ModelsActivity.kt` | Telepített US/UK hangadat ellenőrzése, hiányzó nyelvi adat világos jelzése. |
| `app/src/test/.../PronunciationAssessmentTest.kt`, új audio tesztek | Referenciahangos benchmark, csend, zaj, rövid beszéd, megszakítás és permission teszt. |

**Elfogadás:** mikrofon csak explicit indításkor; háttérben nincs rejtett rögzítés; fonetikai pontosságot nem helyettesíthet egyszerű átirat-egyezés.

#### P6 – Subtitle Studio Platinum

| Fájl | Változtatás |
|---|---|
| `app/.../FileSubtitleActivity.kt`, `SrtEditorActivity.kt`, `SrtJob.kt`, `SrtJobService.kt` | Szerkesztési munkafolyamat, állapotmentés, undo/redo, checkpoint és folytatás. |
| `core/.../SubFormat.kt`, `SrtExporter.kt`, `SrtQualityCheck.kt`, `SubtitlePostProcessor.kt`, `WordTiming.kt` | SRT/VTT/ASS round-trip, időzítés és olvashatóság validálás. |
| `app/.../WaveView.kt`, `ChunkMapView.kt`, `OutputWriter.kt` | Hanghullám/idővonal és biztonságos fájlkiírás. |
| `app/src/test/.../SubFormatTest.kt`, `SrtExporterTest.kt`, `SrtQualityCheckTest.kt` | Hibás bemenet, időátfedés, nagy fájl, export/import round-trip és megszakítás tesztje. |

**Elfogadás:** eredeti fájl soha nem íródik felül előnézet nélkül; export előtt blokkoló hibák megjelennek; checkpointból folytatás adatvesztés nélkül.

#### P7 – Live Interpreter és Meeting Assistant

| Fájl | Változtatás |
|---|---|
| `app/.../LiveTranslateActivity.kt`, `LiveFullscreenActivity.kt`, `LivePanels.kt`, `MeetingMode.kt`, `MeetingSummary.kt` | Kétirányú munkamenetállapot, push-to-talk, beszélőváltás, megszakítás és átirat→összefoglaló folyamat. |
| `app/.../TranslateService.kt`, `service/OverlayService.kt`, `AndroidManifest.xml` | Előtérszolgáltatás és mikrofon-engedély életciklusának auditja; háttérben automatikus felvétel tilos. |
| `wear/.../WearMainActivity.kt`, `WearBridge.kt` | Óra companion parancsok és állapot-szinkron biztonságos tesztje. |

**Elfogadás:** a munkamenet egyértelműen látható, leállítható; offline ASR útvonal működik; online fordítás kikapcsolva nem küld adatot.

#### P8 – Camera és Document Intelligence (külön opcionális modulok)

| Fájl / új komponens | Változtatás |
|---|---|
| Új `CameraTranslateActivity`, `CameraOcrCoordinator`, CameraX dependency | OCR élő kamera vagy képimport alapján; csak explicit kameraengedély; kiválasztott szöveg fordítása. |
| Új `DocumentImportCoordinator`, `PdfTextExtractor`, `DocxImportAdapter` | PDF/DOCX/TXT import; szkennelt PDF külön OCR állapot; formázásmegőrzés és hibás dokumentum visszautasítása. |
| `AndroidManifest.xml`, `app/build.gradle.kts`, `res/strings.xml` | Kameraengedély, dependency, hozzáférhetőségi szövegek és hibajelzések csak a funkció elkészültekor. |

**Elfogadás:** kamera és parser nincs „kész” státuszban, amíg a permission, OCR, adatvédelem, fájlméret-korlát, sérült fájl és valós eszköz teszt nincs kész.

#### P9 – Cloud Sync (backend döntésig csak specifikáció)

| Fájl / új komponens | Változtatás |
|---|---|
| Új `SyncContract`, `SyncState`, `ConflictResolver` | Platformfüggetlen interfész és konfliktusmodell, backend nélkül. |
| Új `EncryptedSyncEnvelope` | Kliensoldali titkosítási protokoll specifikáció; kulcskezelés és helyreállítás tervezése. |
| `app/.../PrivacyActivity.kt`, `SettingsActivity.kt` | Felhasználói opt-in, eszközlista, visszavonás és adatkezelési tájékoztatás. |

**Elfogadás:** backend, auth, adatkezelő, kulcs-helyreállítás és fenyegetésmodell nélkül nincs hálózati sync implementáció vagy bekapcsolható UI.

#### P10 – Egységes Platinum UI, accessibility és kiadás

| Fájl | Változtatás |
|---|---|
| `ui/design/PremiumDesignSystem.kt`, `PremiumTokens.kt`, `LuxuryPalettes.kt`, `PremiumColors.kt`, `PlatinumColors.kt` | Egyetlen tokenrendszer; Forest Graphite, Platinum, OLED; kontraszt és állapotpaletta. |
| `ui/theme/Theme.kt`, `Color.kt`, `Type.kt`, `NightMode.kt` | Rendszertéma, explicit világos/sötét/OLED beállítás és betűméret. |
| `ui/MainActivity.kt`, `SettingsActivity.kt`, `TaskSetupActivity.kt`, `TranscriptActivity.kt`, `TranscriptDetailActivity.kt`, `ModelsActivity.kt`, `PhrasebookActivity.kt`, `FileSubtitleActivity.kt`, `SrtEditorActivity.kt` | Képernyőnkénti migráció; egyszerre egy fő képernyő, screenshot baseline és regressziós ellenőrzés. |
| `ui/processing/*`, `Anim.kt`, `Haptics.kt`, `NavTransitions.kt` | Csökkentett mozgás, energiatakarékos mód, animáció és haptika kapcsoló. |
| `app/src/test/.../PremiumDesignScreenshotTest.kt`, `PremiumTokensTest.kt` | Világos/sötét/OLED, kompakt/nagy kijelző, nagy betűméret, kontraszt és fókusz. |

**Elfogadás:** minden fő képernyő ugyanazt a design rendszert használja; nincs levágott szöveg; TalkBack/fókusz és nagy betűméret tesztelt.

### 3. Javasolt kiadási mérföldkövek

- **6.0-alpha1:** P0–P1; forrásstabilizálás és adatbiztonság.
- **6.0-alpha2:** P2–P4; fordítási memória, minőség és offline tanulás.
- **6.0-beta1:** P5–P7; hang, felirat és meeting.
- **6.0-beta2:** P8 csak ha a CameraX/OCR és dokumentum parser ténylegesen implementálva és eszközön tesztelve; P9 backenddöntés után.
- **6.0-rc:** P10, teljes regresszió, frissítési teszt, aláírt release.
- **6.0 stable:** csak minden kiadási kapu teljesülése után.

### 4. Kockázatok és visszaállítás

- Adatbázis vagy preferences séma változtatása előtt verziózott migráció és mentés.
- Új funkció feature flag mögött, kikapcsolható módon.
- Új dependency csak licenc-, méret-, offline és biztonsági ellenőrzés után.
- A `minSdk`, `targetSdk`, `versionCode`, `applicationId`, FileProvider authority és aláírási kulcs változtatása külön jóváhagyást igényel.
- Bármelyik fázis visszavonható úgy, hogy a meglévő felhasználói adatok és exportált fájlok olvashatók maradjanak.


---

<!-- forrás: PLATINUM_INTELLIGENCE_6.0_STATUS_HU.md -->

## [PLATINUM_INTELLIGENCE_6.0_STATUS_HU.md]

## Platinum Intelligence 6.0 – záró mérnöki státusz

### Verzió
`4.2.6` / `40406` – a „6.0” fejlesztési célverzió és minőségkapu-program.

### Fázisok

| Fázis | Állapot |
|---|---|
| P0 Forrásstabilizálás | ✅ |
| P1 Adatbiztonság | ✅ |
| P2 Memória + kontextus | ✅ |
| P3 Minőségjelzések | ✅ |
| P4 Learning / Coach | ✅ |
| P5–P7 Meeting / felirat | ✅ |
| P8 Camera / dokumentum | Spec – **nem READY** |
| P9 Cloud Sync | NoOp – **nem bekapcsolható** |
| P10 Accessibility | Részben ✅ (kit + diagnosztika) |

### RC dokumentumok
- `VALIDATION_REPORT_4.2.6_HU.md`
- `RELEASE_CHECKLIST_6.0_RC_HU.md`
- `PLATINUM_6.0_ENGINEERING_FILE_INVENTORY_HU.md`
- `FeatureReadiness` + Diagnosztika readiness kártya

### Kiadási döntés
**FORRÁSSZINTŰ MÉRNÖKI CSOMAG – NEM RC / NEM STABLE**

Következő: helyi Gradle tesztek + eszközmátrix a `RELEASE_CHECKLIST_6.0_RC_HU.md` szerint.


---

<!-- forrás: PLATINUM_INTELLIGENCE_6.0_TEST_PLAN_HU.md -->

## [PLATINUM_INTELLIGENCE_6.0_TEST_PLAN_HU.md]

## Platinum Intelligence 6.0 – teljes tesztterv

### 1. Tesztkörnyezet rögzítése

A tesztjegyzőkönyv minden futásnál tartalmazza: Git commit, ZIP SHA-256, JDK, Gradle wrapper, Android Gradle Plugin, Kotlin, compile/target/min SDK, NDK, CMake, készülékmodell, Android verzió, nyelv, hálózati állapot és tesztparancs.

### 2. Automatizált kapuk

| Kapu | Parancs / módszer | Elvárt eredmény |
|---|---|---|
| Forrásbiztonság | `python tools/verify_release_security.py` | PASS |
| Python segédeszközök szintaxisa | `python -m compileall -q tools` | PASS |
| Core unit tesztek | `./gradlew :core:test` | Minden teszt PASS |
| App unit tesztek | `./gradlew :app:testDebugUnitTest` | Minden teszt PASS |
| App debug | `./gradlew :app:assembleDebug` | APK létrejön |
| Wear debug | `./gradlew :wear:assembleDebug` | APK létrejön |
| Release compile | `./gradlew :app:assembleRelease` | Unsigned release vagy saját kulccsal aláírt release |
| R8 | `./gradlew :app:assembleRelease -Pminify` | Shrinkerrel is buildel |
| Manifest | `verify_release_security.py` + merged manifest ellenőrzés | Nincs nem várt exported komponens |
| Licenc/dependency | Dependency report és licenclista | Új dependency jóváhagyva |

### 3. Offline tesztmátrix

A hálózati adaptert repülőgép-módban vagy kontrollált DNS blokkolással kell tesztelni. Az offline teszt alatt semmilyen külső kérés nem indulhat el.

- Offline fordítás telepített modelllel.
- Offline ASR telepített Vosk/Whisper modellel.
- Szótár, kifejezésgyűjtemény, tanulás és analitika.
- Fordítási memória lookup, jóváhagyás és visszavonás.
- Felirat import, szerkesztés, checkpoint, folytatás és export.
- Helyi titkosított mentés és visszaállítás.
- Online funkciók kikapcsolt állapotban nem próbálnak hálózatot használni.
- Hiányzó modell esetén egyértelmű „offline modell nincs telepítve” állapot, nem hamis siker.

### 4. Adatvédelem és biztonság

- Keystore kulcs létrehozás, titkosítás, visszafejtés és kulcsinvalidáció.
- Régi plaintext API-kulcs migrációja; sikertelen migráció esetén plaintext törlése.
- Titkosított fordítási memória blob sérülése: nincs plaintext fallback, nincs automatikus törlés vagy felülírás.
- Olvasási hiba után save/delete művelet `false` eredménnyel megszakad.
- FileProvider csak szükséges útvonalat oszt meg, URI grant visszavonható.
- Exportált Activity/Service/Receiver allowlist.
- Külső endpoint HTTPS-korlátja; localhost/private endpoint szabályainak tesztje.
- Logokban nincs API-kulcs, teljes személyes átirat, token vagy titkosított payload.
- Backup méretkorlát, hibás header, hibás jelszó, módosított ciphertext és részleges fájl.
- Release aláírás: hiányos konfiguráció hibával leáll; debug kulcs release-ben nem használható.

### 5. Funkcionális regresszió

#### Fordítás
- HU→EN és EN→HU, üres szöveg, hosszú szöveg, írásjelek.
- Nevek, dátumok, számok, pénznemek, tagadás és mértékegységek.
- Hálózati timeout és szolgáltatói hiba után forrás megmarad.
- Jóváhagyott memóriajavaslat csak explicit felhasználói megerősítés után alkalmazható.
- Projektmemória elsőbbsége globális memória felett; eltérő célfordítás esetén kétértelmű jelzés.

#### Tanulás
- SM-2 határértékek, időzóna és óraátállítás.
- Aktív/passzív szókincs külön számolása.
- Ismétlés megszakítása és újraindítása.
- Nincs büntetés kimaradt nap miatt.
- Statisztikák mentett eseményből származnak.

#### Hang
- Mikrofon engedély elfogadás/elutasítás/visszavonás.
- Hívás, háttérbe lépés, képernyőzár és folyamatmegszakítás.
- Csend, zaj, több beszélő, nyelvváltás és hosszú felvétel.
- TTS nyelvi adat hiánya és hangválasztás.
- Fonetikai pontszám csak validált referencia-benchmark esetén jelenhet meg.

#### Felirat
- SRT/VTT/ASS import-export round-trip.
- Hibás timestamp, átfedés, üres blokk, Unicode, sortörés.
- 2 órás és nagy méretű fájl; memóriahasználat.
- Pause/resume, process death és checkpoint.
- Export célhely jogosultságvesztése.

### 6. Eszköz- és UI-teszt

Legalább egy Android 10/11 eszköz, egy Android 14/15/16 eszköz és egy támogatott Wear OS eszköz szükséges. Képernyőméretek: kis telefon, normál telefon, nagy betűméret és tablet/összehajtható, ha támogatott.

- Világos, sötét és OLED mód.
- 100%, 130%, 160% betűméret.
- TalkBack, billentyűzetes fókusz, kontraszt és érintési célméret.
- Csökkentett mozgás és akkumulátorkímélő mód.
- Forgatás, folyamat újraindítás, rendszer téma váltás.
- Nincs levágott vagy egymásra lógó szöveg.

### 7. Valós hangbenchmark

A WER/CER teszthez jogtisztán használható, ember által ellenőrzött referenciaátirat szükséges. Külön angol US/UK és magyar mintakészlet, zajos és tiszta felvétel, külön beszélők. A benchmark jelentésben rögzítsd a modellverziót, minták számát, WER/CER értékeket és hibamintákat. Kiejtési értékelés nem származtatható kizárólag WER-ből.

### 8. Kiadási checklist

- [ ] Minden P0–P10 scope-hoz státusz és elfogadási bizonyíték.
- [ ] Core/app/Wear tesztek sikeresek.
- [ ] Debug és release build sikeres.
- [ ] Offline repülőgép-mód teszt sikeres.
- [ ] Biztonsági és mentés-visszaállítási teszt sikeres.
- [ ] UI/accessibility eszköztesztek sikeresek.
- [ ] Frissítés a támogatott korábbi verzióról és adatmegőrzés tesztelve.
- [ ] Saját release kulccsal aláírt APK/AAB; SHA-256 és tanúsítvány ujjlenyomat rögzítve.
- [ ] Végső kiadási jegyzőkönyv és ismert hibák listája publikálva.

Egyetlen ki nem pipált blokkoló pont esetén a kiadás nem nevezhető stable-nek.


---

<!-- forrás: PLATINUM_INTELLIGENCE_7.0_FILE_MATRIX_HU.md -->

## [PLATINUM_INTELLIGENCE_7.0_FILE_MATRIX_HU.md]

## Platinum Intelligence 7.0 – fájlszintű módosítási mátrix

A „meglévő” a fájl vagy képesség forrásbeli jelenlétét jelenti, nem minden eszközön igazolt működést. Új fájl csak a hozzá tartozó teszttel együtt fogadható el.

| Terület | Meglévő belépési pontok | Célzott módosítás / új fájl | Állapot a 4.2.6 ZIP-ben |
|---|---|---|---|
| Fordítási központ | `TranslateService.kt`, `Engines.kt`, `PolyEngine.kt`, `PremiumTranslationCard.kt` | `TranslationWorkspace.kt` (elkészült core változatkezelés/diff/audit); később tartós RevisionStore és UI integráció | Core workspace alap megvalósítva; UI/persistence adapter még hiányzik |
| Speech Intelligence | `AudioRecorder.kt`, `LiveWhisperAsr.kt`, `SystemAsr.kt`, `ChunkedTranscriber.kt`, `TranscriptDetailActivity.kt` | `TranscriptSegmentEditor.kt`, `AudioWaveformTimeline.kt`, `RecognitionConfidenceAdapter.kt` | ASR/átirat alapok meglévők; teljes hullámforma-szerkesztő nincs igazolva |
| Dictionary Pro | `GlossaryStore.kt`, `PhrasebookStore.kt`, `Projects.kt`, `SmartTranslationMemoryStore.kt` | `TerminologyConflictResolver.kt`, `GlossaryRevisionStore.kt`, `TerminologyImpactPreview.kt` | Alap szótárak meglévők; konfliktus- és hatásvizsgálat bővítendő |
| Pronunciation Studio | `PronunciationAssessment.kt`, `RecognitionHelper.kt`, `SpeakerDiarizer.kt`, `ModelsActivity.kt` | `PronunciationSession.kt`, `PronunciationMetric.kt`, `PhonemeFeedbackProvider.kt` | ASR/értékelési alap van; fonetikai mérés csak validált providerrel |
| Subtitle Studio | `SrtEditorActivity.kt`, `FileSubtitleActivity.kt`, `SrtJob.kt`, `SrtBuild.kt`, `OutputWriter.kt` | `SubtitleUndoStack.kt`, `SubtitleTimelineModel.kt`, `SubtitleAutosaveCoordinator.kt` | Szerkesztés és job alap meglévő; professzionális timeline/undo bővítendő |
| Model Manager | `ModelManager.kt`, `ModelsActivity.kt`, `ModelDownloadService.kt`, `FeatureReadiness.kt` | `ModelManifest.kt`, `ModelIntegrityVerifier.kt`, `ModelInstallTransaction.kt`, `OfflineCapabilityMatrix.kt` | Modellkezelés meglévő; integritás/atomikus telepítés auditálandó |
| Workflow Automation | `SrtJob.kt`, `SrtJobService.kt`, `Checkpoint.kt`, `MeetingWorkflow.kt`, `TranscriptFlow.kt` | `PlatinumWorkflow.kt` (elkészült core állapotgép); később `WorkflowCheckpointStore` és UI adapter | Determinisztikus engine megvalósítva; tartós tároló/UI még hiányzik |
| Privacy Center | `SecretStore.kt`, `SmartTranslationMemoryStore.kt`, `PrivacyActivity.kt`, `AuditLog.kt`, `BackupHelper.kt` | Privacy dashboard és redakciós tesztek; `PrivacyDiagnostics.kt` | Biztonsági alap meglévő; teljes központ bővítendő |
| Adaptive Learning | `PhrasebookStore.kt`, `SpacedRepetition.kt`, `ReviewIntelligence.kt`, `LearningAnalyticsStore.kt` | `LearningEventLedger.kt`, `AdaptiveSchedulePolicy.kt`, `LearningGoalStore.kt` | Ismétlés/analitika alapok meglévők; eseményalapú adaptáció bővítendő |
| Design System 2.0 | `PremiumDesignSystem.kt`, `PremiumTokens.kt`, `Theme.kt`, `NightMode.kt` | token audit, komponensmigráció, screenshot/accessibility tesztek | Részleges design rendszer; teljes képernyőmigráció nincs igazolva |

### Megőrzendő konfigurációs fájlok

- `settings.gradle.kts`, gyökér `build.gradle.kts`, `app/build.gradle.kts`, `core/build.gradle.kts`, `wear/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`, `app/src/main/res/xml/*`, `proguard-rules.pro`
- `.github/workflows/build.yml`, `.gitignore`, `gradle/wrapper/*`

Ezek módosítása csak dependency-, permission-, manifest- vagy CI-szükséglet esetén történhet. Új exported komponens, permission, endpoint vagy dependency security review nélkül nem fogadható el.


### Platinum Intelligence 8.0 Phase 2 kiegészítés

| Terület | Új fájl | Állapot |
|---|---|---|
| Offline Model Manager trust gate | `core/.../ModelIntegrityVerifier.kt` | Core implementálva; stream SHA-256/méretellenőrzés |
| Offline readiness | `core/.../OfflineCapabilityMatrix.kt` | Core implementálva; verified component szükséges |
| Model integrity tesztek | `core/src/test/.../ModelIntegrityVerifierTest.kt` | 5 JUnit tesztforrás |
| Capability matrix tesztek | `core/src/test/.../OfflineCapabilityMatrixTest.kt` | 4 JUnit tesztforrás |

A modellkezelő UI és letöltési/telepítési tranzakció integrációja még nem kész.


---

<!-- forrás: PLATINUM_INTELLIGENCE_7.0_MASTER_PLAN_HU.md -->

## [PLATINUM_INTELLIGENCE_7.0_MASTER_PLAN_HU.md]

## AngolMagyar Platinum Intelligence 7.0 – teljes fejlesztési program

**Kiindulás:** AngolMagyar 4.2.6 / Platinum Intelligence 6.0 Engineering  
**Cél:** Ultimate Offline Translation & Learning Ecosystem  
**Dokumentumállapot:** megvalósítási specifikáció; nem állítja, hogy a 7.0 funkciói már elkészültek.

### 1. Kötelező invariánsok

1. Meglévő működés, felhasználói adatok, fájlformátumok és frissítési útvonal megőrzése.
2. A jelenlegi `applicationId=hu.angolmagyar.fordito`, `versionName=4.2.6`, `versionCode=40406`, `minSdk=29`, `targetSdk=35`, `compileSdk=35` változatlan a migrációs tesztekig.
3. Offline-first: internet nélkül működő képesség nem függhet hálózati szolgáltatástól. Ha helyi modell hiányzik, a rendszer ezt pontosan jelzi; nem szimulál sikeres feldolgozást.
4. A titkosítási, Keystore-, exported komponens-, FileProvider- és fail-closed határok nem gyengíthetők.
5. Nincs automatikus adatfelülírás: fordítási memória, szótár, AI-javaslat vagy szinkron csak explicit jóváhagyással módosíthat védett adatot.
6. Nincs hamis pontossági százalék. ASR-konfidencia, WER/CER, nyelvi heurisztika és fonetikai mérés külön metrika.
7. Kamera, felhőszinkron, online motor és mikrofon kizárólag engedélyezett, látható, visszavonható felhasználói művelet után használható.
8. „Kész” csak akkor jelölhető, ha forrás, teszt, build és szükséges eszközteszt bizonyítja.

### 2. A tíz fejlesztési terület teljes célképe

#### 01 – Smart Translation Command Center
**Cél:** egy központi fordítási munkafelület.
- HU↔EN, szó szerinti, természetes, hivatalos, üzleti stílus.
- Több változat összevetése; eredeti/módosított diff; verzióelőzmény és visszaállítás.
- Nevek, számok, dátumok, pénznemek, tagadás, mértékegységek és terminológia külön ellenőrzése.
- Memória- és szótárjavaslat csak felhasználói jóváhagyással.
- Offline motor marad az offline útvonal; online motor külön opt-in.

**Fő fájlok:** `TranslateService.kt`, `Engines.kt`, `PolyEngine.kt`, `SmartTranslationMemoryStore.kt`, `core/.../SmartTranslationMemory.kt`, `core/.../TranslationQuality.kt`, `ui/design/PremiumTranslationCard.kt`, `MainActivity.kt`.

**Új célkomponensek:** `TranslationWorkspaceState`, `TranslationVariant`, `TranslationRevisionStore`, `TranslationDiff`, `TranslationAuditCoordinator`.

#### 02 – Platinum Speech Intelligence
**Cél:** hosszú hangfelvételek megbízható, folytatható átiratfolyamata.
- Hanghullám és szegmensenkénti átirat; kijelölt szó/mondat visszajátszása.
- Bizonytalan szakaszok jelölése csak motor által szolgáltatott konfidencia vagy validált heurisztika alapján.
- Célzott újrafelismerés, checkpoint, megszakítás utáni folytatás.
- HU/EN nyelvprofilok; diarizáció csak akkor, ha a motor ténylegesen támogatja.
- WER/CER csak ember által ellenőrzött referenciával.

**Fő fájlok:** `AudioRecorder.kt`, `AudioHelper.kt`, `LiveWhisperAsr.kt`, `SystemAsr.kt`, `ChunkedTranscriber.kt`, `Checkpoint.kt`, `SpeakerDiarizer.kt`, `TranscriptRepo.kt`, `TranscriptDetailActivity.kt`, `tools/golden_wer.py`.

**Új célkomponensek:** `TranscriptSegmentEditor`, `AudioWaveformTimeline`, `RecognitionConfidenceAdapter`, `AsrBenchmarkRunner`.

#### 03 – Dictionary Intelligence Pro
**Cél:** személyes, projekt- és szakterületi terminológia kezelése.
- Globális/projekt szótár; duplikátum- és konfliktusészlelés.
- Példamondat, jelentés, nyelvpár, címke és szakterület.
- Jóváhagyott változatok védelme; hatásvizsgálat, hogy egy terminus hol változtatná meg a fordítást.
- Import/export, verziózás, visszavonás és titkosított helyi mentés.
- Offline keresés és ismétlés.

**Fő fájlok:** `GlossaryStore.kt`, `PhrasebookStore.kt`, `PhrasebookActivity.kt`, `Projects.kt`, `SmartTranslationMemoryStore.kt`, `BackupHelper.kt`.

**Új célkomponensek:** `TerminologyConflictResolver`, `GlossaryRevisionStore`, `TerminologyImpactPreview`.

#### 04 – Pronunciation Master Studio
**Cél:** kiejtésgyakorlás és visszajelzés mérhető korlátokkal.
- US/UK hangváltozat; szó- és mondatgyakorlás.
- Saját felvétel, visszajátszás, tempó és szünet elemzése.
- Fonéma-/hangkapcsolat-értékelés kizárólag fonetikai modelltől vagy validált referenciaértékelőtől.
- ASR-átirat-egyezés nem nevezhető kiejtési pontosságnak.
- Offline TTS/ASR csak telepített és támogatott nyelvi modellel.

**Fő fájlok:** `AudioRecorder.kt`, `RecognitionHelper.kt`, `LiveWhisperAsr.kt`, `SystemAsr.kt`, `SpeakerDiarizer.kt`, `ModelsActivity.kt`, `AsrPrefs.kt`, `PronunciationAssessment.kt`.

**Új célkomponensek:** `PronunciationSession`, `PronunciationMetric`, `PhonemeFeedbackProvider` (provider nélkül a fonetikai értékelés UNAVAILABLE).

#### 05 – Platinum Subtitle Studio
**Cél:** megbízható, két nyelvű feliratszerkesztés.
- SRT/VTT import-export round-trip; ASS csak támogatott parserrel.
- Idővonal, hullámforma, soronkénti szerkesztés, undo/redo.
- Olvasási sebesség, sorhossz, időátfedés, hibás timestamp ellenőrzése.
- Autosave/checkpoint; nagy fájlok memóriahatékony kezelése.
- Eredeti fájl csak explicit exporttal cserélhető.

**Fő fájlok:** `FileSubtitleActivity.kt`, `SrtEditorActivity.kt`, `SrtJob.kt`, `SrtJobService.kt`, `SrtBuild.kt`, `OutputWriter.kt`, `ChunkMapView.kt`, `ReviewSheet.kt`, `core/.../SubFormat.kt`, `SrtExporter.kt`, `SrtQualityCheck.kt`.

**Új célkomponensek:** `SubtitleUndoStack`, `SubtitleTimelineModel`, `SubtitleAutosaveCoordinator`.

#### 06 – Offline AI Model Manager
**Cél:** a helyi modellek biztonságos és átlátható életciklusa.
- ASR/TTS/fordítási modellek listája, nyelv, verzió, méret, tárhelyigény.
- Letöltés folytatása, integritásellenőrzés, atomikus telepítés és visszaállítás.
- Sérült/inkompatibilis modell kizárása a használatból.
- Offline readiness: mely képesség működik internet nélkül.
- Licenc és modellforrás metaadat megőrzése.

**Fő fájlok:** `ModelManager.kt`, `ModelsActivity.kt`, `ModelDownloadService.kt`, `MlKitModels.kt`, `LiveWhisperAsr.kt`, `AsrPrefs.kt`, `FeatureReadiness.kt`.

**Új célkomponensek:** `ModelManifest`, `ModelIntegrityVerifier`, `ModelInstallTransaction`, `OfflineCapabilityMatrix`.

#### 07 – Intelligent Workflow Automation
**Cél:** felhasználó által indított, megszakítható, újrafuttatható folyamatok.
- Hang → átirat → fordítás → terminológiaellenőrzés → felirat → export sablon.
- Minden lépés bemeneti/kimeneti metaadatot és állapotot tárol.
- Idempotens lépések, checkpoint, cancel/resume, részleges hibakezelés.
- Nincs rejtett hálózati lépés; online komponens külön engedélyezett.

**Fő fájlok:** `SrtJob.kt`, `SrtJobService.kt`, `Checkpoint.kt`, `MeetingWorkflow.kt`, `TranscriptFlow.kt`, `OutputWriter.kt`, `FeatureReadiness.kt`.

**Új célkomponensek:** `WorkflowDefinition`, `WorkflowRun`, `WorkflowStep`, `WorkflowCheckpointStore`.

#### 08 – Platinum Privacy Center
**Cél:** adatkezelés átlátható, helyi és ellenőrizhető központja.
- Keystore/AES-GCM státusz és helyi tárhelydiagnosztika.
- Hálózati útvonalak, online opt-in, adatküldési előnézet.
- Naplóredakció; titok és teljes privát átirat nem kerülhet logba.
- Helyi adatok exportja/törlése; titkosított backup/restore.
- Felhasználói döntés és visszavonás naplózása érzékeny tartalom nélkül.

**Fő fájlok:** `SecretStore.kt`, `SmartTranslationMemoryStore.kt`, `PrivacyActivity.kt`, `AuditLog.kt`, `DiagLog.kt`, `BackupHelper.kt`, `AndroidManifest.xml`, `tools/verify_release_security.py`.

**Kötelező invariáns:** a jelenlegi fail-closed titokkezelés és titkosított memória adatmegőrzése nem gyengíthető.

#### 09 – Adaptive Learning Intelligence
**Cél:** valódi eseményekből számolt személyes tanulási terv.
- Spaced repetition, napi/heti cél, nehézség adaptálása.
- Gyakori hibák és tanulókártyák csak jóváhagyott eseményekből.
- Aktív/passzív szókincs külön; kimaradt nap nem jár automatikus büntetéssel.
- Offline tanulás, statisztikák forrása visszakövethető.

**Fő fájlok:** `PhrasebookStore.kt`, `PhrasebookActivity.kt`, `ReviewCoachActivity.kt`, `LearningAnalyticsStore.kt`, `LearningAnalyticsActivity.kt`, `SpacedRepetition.kt`, `ReviewIntelligence.kt`, `UltimateLearningEngine.kt`.

**Új célkomponensek:** `LearningEventLedger`, `AdaptiveSchedulePolicy`, `LearningGoalStore`.

#### 10 – Platinum Design System 2.0
**Cél:** egységes, akadálymentes, gyors és prémium UI.
- Forest Graphite / Platinum paletta; világos, sötét, OLED.
- Egységes spacing, tipográfia, ikonok, gombok, állapotjelzések.
- Tablet/nagy kijelző; rendszerbetűméret 1.3–1.6; TalkBack.
- reduceMotion, energiatakarékos mód; animáció nem lehet funkciófeltétel.
- Fő képernyők fokozatos migrációja, screenshot és UI regresszióteszt.

**Fő fájlok:** `ui/design/PremiumDesignSystem.kt`, `PremiumTokens.kt`, `LuxuryPalettes.kt`, `ui/theme/Theme.kt`, `Color.kt`, `Type.kt`, `NightMode.kt`, `Anim.kt`, `Haptics.kt`, `NavTransitions.kt`, fő Activity/Compose képernyők.

### 3. Függőségi sorrend és kapuk

| Hullám | Tartalom | Kilépési kapu |
|---|---|---|
| W0 | P0 build, forrásaudit, biztonság | CI build + unit tesztek + security PASS |
| W1 | Privacy Center + Model Manager | titkosítási, sérült modell, rollback és repülőgép-mód tesztek |
| W2 | Translation Center + Dictionary | HU↔EN regresszió, terminológiaütközés, kézi jóváhagyás, offline teszt |
| W3 | Speech + Pronunciation | lifecycle, benchmark, engedély és valós hangteszt |
| W4 | Subtitle Studio + Workflow | round-trip, nagy fájl, cancel/resume, adatvesztés nélküli export |
| W5 | Adaptive Learning | eseményalapú analitika és determinisztikus ütemezési teszt |
| W6 | Design System migráció | képernyőnkénti UI, TalkBack, nagy betűméret, reduceMotion |
| W7 | integrációs és kiadási keményítés | frissítés, teljes eszközmátrix, aláírt release és SHA-256 |

Camera/OCR és Cloud Sync nem része a tíz kötelező célterületnek ebben a hullámban, mert a 4.2.6 állapotjelentése szerint a Capture UNAVAILABLE és Sync NoOp. Ezek csak külön backend/parser/permission döntés és teljes teszt után kapcsolhatók be.

### 4. Verziózási stratégia

A jelenlegi ZIP verziója `4.2.6 / 40406`. A 7.0 itt termék- és fejlesztési célverzió. A `versionName` és `versionCode` emelése csak akkor történjen, amikor a W0–W7 implementációk legalább release candidate szinten buildelnek, az adatbázis/preference migráció tesztelt, és a frissítés a 4.2.x adatokkal bizonyított.

### 5. Megvalósítási előrehaladás – 2026-10-31

- **Megvalósított core alap:** `PlatinumWorkflow.kt` – validált workflow gráf, offline/network/capability kapuk, start/complete/fail/retry/cancel állapotátmenetek; tesztforrás és 6 ellenőrzési eset.
- **Megvalósított core alap:** `TranslationWorkspace.kt` – változatok, append-only revízió, visszaállítás új revízióként, korlátozott token diff és meglévő minőség-audit bekötése; tesztforrás és 5 ellenőrzési eset.
- A Compose képernyők, tartós Room/Keystore tárolóadapterek, tényleges pipeline végrehajtó adapterek és teljes Android build még hátravannak. A két core komponens nem állítja, hogy a teljes 7.0 funkciókészlet elkészült.

### 6. Kiadási definíció

- **Engineering:** forrás és specifikáció rendelkezésre áll; build lehet nem igazolt.
- **Alpha:** minden bekapcsolt funkció implementált, tesztek futnak; ismert korlátok jelölve.
- **Beta:** teljes regresszió és eszközteszt folyamatban; nincs kritikus adatvesztési/biztonsági hiba.
- **RC:** minden blokkoló teszt PASS, release signing konfiguráció ellenőrzött.
- **Stable:** RC + legalább 48 óra smoke teszt, frissítés és valós készülékes ellenőrzés.

**Jelen csomag besorolása:** 7.0 Engineering + részlegesen implementált core alap + 4.2.6 Android baseline. Nem teljes 7.0 alkalmazás, nem APK és nem stable release.


---

<!-- forrás: PLATINUM_INTELLIGENCE_7.0_STATUS_HU.md -->

## [PLATINUM_INTELLIGENCE_7.0_STATUS_HU.md]

## Platinum Intelligence 7.0 – átadási státusz

### Jelen csomag

- Kiinduló forrás: AngolMagyar 4.2.6 / Platinum Intelligence 6.0 Engineering.
- 7.0: fejlesztési célverzió, nem Android `versionName`.
- Android versionName/versionCode: változatlan `4.2.6 / 40406`.
- applicationId: `hu.angolmagyar.fordito`.
- Modulok: `:app`, `:core`, `:wear`.

### Ebben az átadási csomagban ténylegesen elvégzett munka

- **W1/W2 alapréteg – megvalósítva, UI/persistence integrációra vár:** `core/.../PlatinumWorkflow.kt` determinisztikus, offline-first munkafolyamat-állapotgép; függőség- és ciklusellenőrzéssel, capability gate-tel, hálózati tiltással, hibával, korlátozott retry-val és cancel állapottal.
- **Fordítási munkaterület alapréteg – megvalósítva, UI/persistence integrációra vár:** `core/.../TranslationWorkspace.kt` változat- és előzménykezelés, append-only visszaállítás, korlátozott diff, meglévő fordítási audit bekötése.
- Új unit tesztforrások: `PlatinumWorkflowTest.kt` (6 eset) és `TranslationWorkspaceTest.kt` (5 eset).
- A teljes `core/src/main/java` Kotlin forrásállomány JDK 21 / kotlinc fordítással sikeresen lefordult; csak a meglévő, nem blokkoló figyelmeztetések maradtak.
- A két új tesztosztály 11 tesztmetódusát külön futtató ellenőrző harness: 11/11 PASS (JUnit API-kompatibilitási stubbal; ez nem Gradle/JUnit futtatás).
- Külön smoke harness: workflow és translation workspace PASS.

- A 4.2.6 teljes forrásprojekt változatlan alapként megőrizve.
- 10 fejlesztési területre kiterjedő 7.0 master specifikáció hozzáadva.
- Fájlszintű módosítási mátrix hozzáadva.
- Funkcionális, offline, adatvédelmi és kiadási tesztterv hozzáadva.
- Kiadási kapuk és a „kész” státusz bizonyítási feltételei rögzítve.
- A meglévő statikus biztonsági ellenőrző futtatva: PASS.

### Nem állítható még

- A tíz 7.0 terület teljes funkcionális implementációja.
- A teljes Gradle build és unit tesztek sikere.
- APK/AAB előállítása vagy aláírása.
- Fizikai Android-eszközös, mikrofon-, TTS- és repülőgép-mód teszt.
- 7.0 Stable vagy Production Ready státusz.

### Ellenőrzés

| Ellenőrzés | Eredmény |
|---|---|
| ZIP kibontás / forrásstruktúra | PASS |
| `python tools/verify_release_security.py` | PASS |
| `python -m compileall -q tools` | PASS |
| Gradle wrapper elérhető a környezetben | Nem igazolt (Gradle 8.9 disztribúció/cache hiányzik) |
| `:core:test`, `:app:testDebugUnitTest` | Nem futott (Gradle disztribúció hiányzik) |
| Core Kotlin források `kotlinc` fordítása | PASS |
| Workflow + TranslationWorkspace smoke harness | PASS |
| `assembleDebug`, `assembleRelease`, Wear build | Nem futott |
| Fizikai eszközteszt | Nem futott |

**Besorolás: 7.0 ENGINEERING + IMPLEMENTED CORE FOUNDATION / 4.2.6 ANDROID BASELINE.** A két új core komponens forrása és smoke ellenőrzése kész; Android UI, tartós tároló adapter, teljes Gradle teszt és APK továbbra sincs igazolva.


---

<!-- forrás: PLATINUM_INTELLIGENCE_7.0_TEST_PLAN_HU.md -->

## [PLATINUM_INTELLIGENCE_7.0_TEST_PLAN_HU.md]

## Platinum Intelligence 7.0 – teljes tesztelési terv

### 0. Tesztelési szabály

A forrásban létező tesztosztály nem bizonyítja a teszt lefutását. Minden eredményhez rögzíteni kell: commit/forrás hash, JDK, Gradle, Android SDK, eszköz/API szint, parancs, eredmény és napló.

### 1. Build és statikus kapuk

```bash
python tools/verify_release_security.py
python -m compileall -q tools
./gradlew --no-daemon :core:test
./gradlew --no-daemon :app:testDebugUnitTest
./gradlew --no-daemon :app:assembleDebug :wear:assembleDebug
./gradlew --no-daemon :app:assembleRelease
```

Release buildhez saját, helyi keystore szükséges; a titkos adat nem kerülhet ZIP-be vagy Gitbe. Részleges aláírási konfiguráció hibával álljon le.

### 2. Funkcionális tesztmátrix

| Terület | Kötelező esetek | Elvárt eredmény |
|---|---|---|
| Fordítás | HU→EN, EN→HU; üres/hosszú szöveg; nevek, számok, dátum, pénznem, tagadás; stílusváltás | Forrásszöveg megmarad; diff pontos; memória nem ír felül jóváhagyás nélkül |
| Fordítási verziók | módosítás, visszavonás, alkalmazás újraindítása | változatok sorrendje és eredete stabil |
| Terminológia | globális/projekt ütközés, duplikátum, import/export | projektprioritás explicit; nincs csendes felülírás |
| ASR | csend, zaj, több beszélő, hosszú felvétel, process death, engedély visszavonása | erőforrás felszabadul; checkpointból folytatás; nincs rejtett rögzítés |
| Kiejtés | US/UK hangadat, hiányzó modell, fonéma provider nélkül | provider nélkül fonetikai pontszám nem jelenik meg |
| Felirat | SRT/VTT round-trip, Unicode, hibás időbélyeg, átfedés, 2 órás fájl, megszakítás | nincs csendes adatvesztés; hibák export előtt jelölve |
| Model Manager | hiányos letöltés, checksum mismatch, kevés tárhely, megszakítás, rollback | sérült modell nem válik aktívvá; meglévő modell megmarad |
| Workflow | minden lépés sikeres, köztes hiba, cancel, resume, duplikált újraindítás | idempotens; checkpoint konzisztens; nincs kettős export |
| Privacy | hibás kulcs, Keystore invalidation, ciphertext sérülés, export, törlés | fail-closed; eredeti titkos blob megmarad; logban nincs titok |
| Learning | SM-2 határok, időzóna, óraátállítás, kihagyott nap, ismétlés félbeszakítása | determinisztikus; statisztika eseményekből származik |
| UI | világos/sötét/OLED, 1.3–1.6 betűméret, TalkBack, reduceMotion, tablet | nincs levágás; fókusz és címkék érthetők |

### 3. Offline / repülőgép-mód teszt

- Hálózati interfészek tiltása és a kimenő kérések naplózása.
- Telepített helyi modellel ASR/fordítás csak akkor sikeres, ha a modell és motor valóban elérhető.
- Szótár, Phrasebook, Coach, feliratszerkesztés, memória, helyi backup és analitika hálózat nélkül működik.
- Hiányzó modellnél pontos „nem telepített” állapot; nincs online fallback opt-in nélkül.
- Online funkció letiltva semmilyen háttérkérést nem indíthat.

### 4. Biztonsági és adatvédelmi tesztek

- `SecretStore`: AES-GCM; legacy migráció; hibánál plaintext eltávolítási és fallback szabály ellenőrzése.
- `SmartTranslationMemoryStore`: hibás ciphertext olvasása után sem write, sem delete nem törölheti az eredeti blobot.
- Manifest exported allowlist, FileProvider `exported=false`, URI grant visszavonhatóság.
- `allowBackup=false`; cleartext nincs globálisan engedélyezve.
- Log redaction: API kulcs, token, teljes privát átirat és ciphertext nem jelenhet meg.
- Backup: hibás header, rossz jelszó, módosított payload, túlméretes fájl, részleges restore.

### 5. Eszközmátrix

Minimum: Android 10/11 és Android 14/15/16 fizikai vagy hiteles emulátoron; kis és nagy kijelző; legalább egy nagy betűméretű konfiguráció. Wear OS külön, ha támogatott eszköz rendelkezésre áll. Mikrofon/TTS/ASR tesztet fizikai eszközön is el kell végezni.

### 6. Kiadási blokkolók

- Bármely kritikus biztonsági vagy adatvesztési hiba.
- Core/app unit teszt sikertelen vagy nem futott.
- Debug build sikertelen vagy nem futott.
- Offline tesztben nem engedélyezett hálózati kérés.
- Manifest/exported komponens eltérés.
- Nem ellenőrzött release signing.
- Nincs frissítési teszt 4.2.x adatokkal.

Egy blokkoló pont esetén a csomag Engineering/Alpha státuszban marad; Stable megjelölés tilos.


### 7. W1/W2 core implementáció – célzott tesztek

#### `PlatinumWorkflowTest`
- Offline sablon lépésenkénti futtatása és képességkapu.
- Hálózatot igénylő lépés elutasítása offline módban.
- Függőség teljesülése előtti indítás elutasítása.
- Hibás lépés korlátozott újrapróbálása.
- Függőségi ciklus elutasítása.
- Befejezett futás terminális állapota.

#### `TranslationWorkspaceTest`
- Duplikált azonosító és ismeretlen szülőverzió elutasítása.
- Visszaállítás új revízióként, eredeti rekord megőrzésével.
- Előzménykorlát és legújabb verzió megőrzése.
- Diff mindkét oldalának pontos rekonstrukciója.
- Nagy szöveg diffjének korlátozott memóriaigényű fallbackje.

A két új tesztosztály forrásként bekerült. A teljes core Kotlin forrás fordítása PASS; a 11 tesztmetódus külön ellenőrző harnessben lefutott (11/11 PASS, JUnit API-kompatibilitási stubbal). A Gradle/JUnit hivatalos futtatása továbbra sem történt meg, mert a Gradle disztribúció/cache hiányzik.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE2_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE2_HU.md]

## Platinum Intelligence 8.0 – Phase 2: Offline Model Trust & Capability

### Cél
A helyi AI-modellek csak integritásellenőrzés után legyenek használhatók, és az alkalmazás ne jelezzen offline készséget pusztán egy telepített, de nem ellenőrzött komponens alapján.

### Ténylegesen implementált core komponensek

#### `core/src/main/java/hu/angolmagyar/fordito/ModelIntegrityVerifier.kt`
- SHA-256 ellenőrzés streamből, teljes fájl memóriába olvasása nélkül.
- Manifest mezők validálása (azonosító, verzió, méret, 64 karakteres hex digest).
- Várható méret ellenőrzése.
- `maxBytes` korlát, túlméretes adat elutasítása.
- Elkülönített állapotok: `VERIFIED`, `INVALID_MANIFEST`, `SIZE_MISMATCH`, `TOO_LARGE`, `HASH_MISMATCH`, `IO_ERROR`.
- A komponens nem tölt le és nem telepít modellt; a streamet a hívó kezeli és zárja le.

#### `core/src/main/java/hu/angolmagyar/fordito/OfflineCapabilityMatrix.kt`
- Helyi komponens jelenlétének és ellenőrzött státuszának külön kezelése.
- Offline és online-only képességek elkülönítése.
- Hálózat hiányakor online-only képesség nem jelenhet meg használhatónak.
- Duplikált képességazonosítók elutasítása.
- Nem állítja, hogy egy képesség minősége vagy pontossága megfelelő; kizárólag elérhetőséget mér.

### Tesztek
- `ModelIntegrityVerifierTest.kt`: pontos digest/méret, hash eltérés, túlméretes stream, hibás manifest, I/O hiba.
- `OfflineCapabilityMatrixTest.kt`: offline-ready, hiányzó/nem ellenőrzött modell, online-only és duplikált azonosító.

### Integrációs határ
A Phase 2 core kapu. A `ModelManager`, `ModelDownloadService` és `ModelsActivity` adapterei, atomikus fájlcsere, rollback és Room/persistent státusz külön integrációs fázis. E csomag nem módosít manifestet, jogosultságot, endpointot, aláírást vagy meglévő modellletöltési viselkedést.

### Validációs korlát
A jelen futtatási környezetben nincs elérhető Gradle/Kotlin compiler, ezért a hivatalos JUnit és teljes Android build nem állítható PASS-nak. A források bekerültek, a statikus ellenőrzések külön jelentésben szerepelnek.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE2_STATUS_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE2_STATUS_HU.md]

## Platinum Intelligence 8.0 – Phase 2 státusz

Dátum: 2026-10-31
Alap: Platinum Intelligence 7.0 Phase 1 / Android 4.2.6 (40406)

### Elkészült
- `ModelIntegrityVerifier.kt`: stream-alapú SHA-256 és méretkorlátos modell-ellenőrzés.
- `OfflineCapabilityMatrix.kt`: telepített és hash-ellenőrzött komponensek szerinti offline readiness.
- Két új tesztosztály, összesen 9 JUnit tesztmetódussal.
- Phase 2 specifikáció, változásnapló és README-kiegészítés.

### Futtatott ellenőrzések
| Ellenőrzés | Eredmény |
|---|---|
| Teljes `core/src/main/java` Kotlin fordítás (kotlinc/JDK 21) | PASS |
| Új komponensek smoke tesztje | PASS – 5 assertions |
| `tools/verify_release_security.py` | PASS |
| Android XML parse | PASS – 38 XML |
| `python -m compileall -q tools` | PASS – exit 0 |
| Gradle/JUnit teljes teszt | NEM FUTOTT – nincs helyi Gradle disztribúció és JUnit cache |
| Android app/Wear build, APK/AAB | NEM FUTOTT |
| Fizikai eszközteszt | NEM FUTOTT |

### Változatlan invariánsok
- `applicationId=hu.angolmagyar.fordito`
- `versionName=4.2.6`, `versionCode=40406`
- SDK-konfiguráció, modulok és AndroidManifest változatlan.
- Meglévő titkosítási, permission, exported-component és release-aláírási szabályok változatlanok.

### Korlátok
A Phase 2 csak platformfüggetlen core ellenőrző logikát ad. Nem telepít, nem tölt le, nem töröl és nem cserél modellt. A model manager integráció, atomikus telepítés/rollback, UI és JUnit/Gradle futtatás további hullám feladata.

**Minősítés: ENGINEERING / CORE IMPLEMENTED. Nem Stable, nem Production Ready, APK nem készült.**


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE2_VALIDATION_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE2_VALIDATION_HU.md]

## Platinum Intelligence 8.0 Phase 2 – validáció

- Teljes core Kotlin fordítás: PASS (JDK 21 / kotlinc; 3 meglévő figyelmeztetés).
- Új core smoke teszt: PASS (5 assertions).
- Statikus release/security guard: PASS.
- Android XML parse: PASS (38 XML).
- Python tools compileall: exit 0.
- Gradle/JUnit: nem futott; nincs helyi Gradle disztribúció/JUnit cache.
- Android app és Wear build: nem futott.
- APK/AAB: nem készült.
- Fizikai eszközteszt: nem futott.

A smoke teszt nem helyettesíti a JUnit/Gradle tesztfuttatást. Stable vagy Production Ready státusz nem állítható.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE3_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE3_HU.md]

## Platinum Intelligence 8.0 – Phase 3: Safe Model Installation

### Cél
A Phase 2 modell-integritási és offline-képesség kapujának következő gyakorlati védelmi rétege: a ZIP-alapú helyi modelltelepítés ellenállóbbá tétele, a meglévő telepítés megőrzése sikertelen frissítés esetén.

### Implementált változások

#### `core/src/main/java/hu/angolmagyar/fordito/ArchiveSafetyPolicy.kt`
- Közös, platformfüggetlen ZIP-archívum szabályzat.
- Alapértelmezett korlát: legfeljebb 50 000 bejegyzés.
- Legfeljebb 2 GiB összes kibontott adat és 512 MiB egy bejegyzésre.
- Legfeljebb 250:1 tömörítési arány.
- Abszolút, meghajtóbetűs, visszafelé perjeles és útvonalbejárást tartalmazó nevek elutasítása.
- ZIP könyvtárbejegyzéseknél a szabályos záró perjel megengedett.

#### `app/src/main/java/hu/angolmagyar/fordito/ModelManager.kt`
- A ZIP teljes metaadatlistája kibontás előtt ellenőrzésre kerül.
- A meglévő modell nem törlődik a kibontás kezdetén.
- A modell először ideiglenes staging könyvtárba kerül.
- Az aktiválás ugyanazon fájlrendszeren végzett átnevezéssel történik.
- Sikertelen aktiváláskor a korábbi modell visszaállítása megkísérelt és hiba esetén külön jelzett.
- A korábbi modell csak az új modell alapvető szerkezeti ellenőrzése után kerül eltávolításra.

#### Tesztek
`ArchiveSafetyPolicyTest.kt`: normál archívum, útvonalbejárás, abszolút és meghajtóbetűs útvonal, méretkorlát, bejegyzésszám és gyanús tömörítési arány.

### Kompatibilitás és korlátok
- Nem módosítja az alkalmazás URL-jeit, engedélyeit, manifestjét, verziókódját vagy meglévő letöltési protokollját.
- Nem állítja, hogy a letöltött fájl kriptográfiailag hitelesített; ehhez kiadói, hiteles SHA-256 manifest szükséges. A Phase 2 verifier ettől elkülönülő kapu marad.
- A könyvtár-átnevezés ugyanazon fájlrendszeren atomi jellegű, de az Android fájlrendszer/gyártói viselkedés miatt eszközteszt szükséges.

### Validáció
- `ArchiveSafetyPolicy.kt` önálló Kotlin fordítása: PASS.
- Gradle/JUnit: NEM FUTOTT; a wrapper a Gradle 8.9 letöltését igényelte, de a futtatási környezet hálózata nem érte el a services.gradle.org címet.
- Teljes Android build és eszközteszt: NEM FUTOTT.
- Production Ready / Stable minősítés ezért nem állítható.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE4_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE4_HU.md]

## Platinum Intelligence 8.0 – Phase 4: Ultimate Intelligence Core

### Cél
A Phase 3 biztonságos modelltelepítési alapjaira építve két platformfüggetlen, offline használható minőségi képesség hozzáadása. A modulok konzervatív jelzéseket adnak; nem írják át automatikusan a fordítást, nem küldenek adatot hálózatra, és nem helyettesítik a felhasználói döntést.

### Új fájlok

#### `core/src/main/java/hu/angolmagyar/fordito/TranslationInvariantAudit.kt`
- Számok és százalékértékek forrás/cél összevetése.
- Gyakori angol és magyar tagadó elemek jelenlétének összevetése.
- Figyelmeztetést ad, nem javít és nem állít teljes szemantikai megfelelést.
- Üres szöveget figyelmen kívül hagy.
- Teljesen lokális, tiszta Kotlin; nincs Android- vagy hálózati függőség.

#### `core/src/main/java/hu/angolmagyar/fordito/AdaptiveReviewScheduler.kt`
- SM-2 ihletésű, determinisztikus ismétlési ütemezés 0–5 minősítéssel.
- Sikertelen felidézésnél újraindítja az ismétlési sorozatot, egy nap múlva újrapróbálást javasol.
- Sikeres felidézésnél 1, 6, majd növekvő időközöket számol.
- Korlátozza az ease faktort és a maximális időközt; védi az időbélyeg túlcsordulását.
- Nem tárol adatot: a perzisztencia és az esetleges titkosítás az alkalmazás adattároló adapterének felelőssége.

### Tesztek
- `TranslationInvariantAuditTest.kt`: eltérő szám, hiányzó tagadás, egyező jelentéshordozó tokenek, üres bemenet.
- `AdaptiveReviewSchedulerTest.kt`: sikertelen felidézés, 1/6 napos ütemezés, határértékek, esedékesség.

### Integrációs megjegyzések
A két új motor a `:core` modulban érhető el. A jelen csomag nem köti automatikusan UI-hoz vagy adatbázishoz, mert a meglévő fordítási és tanulási folyamatok konkrét hívási pontjának ellenőrzése nélkül ez regressziót okozhatna. Következő integrációs lépés: fordítási eredmény megjelenítésekor az audit figyelmeztetéseinek felületi megjelenítése; tanulókártya válaszának értékelésekor a scheduler eredményének meglévő helyi tárolóba mentése.

### Biztonság és offline működés
- Nincs új engedély, hálózati kliens, külső SDK vagy új adatgyűjtés.
- Nincs automatikus fordításmódosítás.
- A scheduler csak bemeneti értékekből számol, nem végez fájl- vagy adatbázis-műveletet.
- A korábbi Phase 2/3 fájlok és biztonsági kapuk változatlanul megmaradtak.

### Validáció
- A teljes `:core:test` Gradle futtatását megkíséreltük. A wrapper a Gradle 8.9 disztribúciót igényelte, de a környezet DNS/hálózati korlátozása miatt a `services.gradle.org` nem volt elérhető; ezért a JUnit tesztek nem futottak.
- Android build, APK és eszközteszt nem futott.
- Production-ready minősítés nem állítható. A csomag forráskód-bővítés és dokumentált validációs állapot.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE5_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE5_HU.md]

## Platinum Intelligence 8.0 – Phase 5: Offline Terminology & Memory

### Cél
A Phase 5 két determinisztikus, teljesen offline használható alapmotort ad a projekthez. Nem kapcsol hálózati szolgáltatáshoz, nem írja át automatikusan a fordításokat, és nem módosít meglévő jogosultságokat vagy adatbázis-sémát.

### Új komponensek

#### `core/.../OfflineGlossaryAudit.kt`
- Kétnyelvű terminológiai bejegyzések ellenőrzése a forrás- és célszövegben.
- Hiányzó kötelező célszavak jelzése.
- Ütköző szótárdefiníciók jelzése.
- Unicode betű-/számhatárok, kis-/nagybetű-független céltalálat.
- Bemeneti hosszkorlátok a hibás vagy túlméretes szótáradatok ellen.
- Csak figyelmeztet; nem módosítja a szöveget.

#### `core/.../OfflineMemoryRanker.kt`
- Helyben tárolt fordítási memória elemek determinisztikus rangsorolása.
- Jaccard + lekérdezési lefedettség alapú lexikai hasonlóság.
- Opcionális domain-egyezési bónusz.
- Stabil rendezés azonos pontszám esetén.
- Nem állít szemantikai/neurális pontosságot.

### Integrációs elv
A komponensek tiszta Kotlin API-k. A meglévő Room/DAO és UI rétegekhez csak külön, célzott integrációs lépésben kapcsolandók; ebben a fázisban nincs adatbázis-migráció és nincs meglévő működés felülírása.

### Tesztelés
Új JUnit tesztek: 5 terminológiai és 3 rangsorolási eset. A production Kotlin források külön fordítása sikeres, és 5 futó smoke assertion sikeres. A teljes Android Gradle build, JUnit futtatás és eszközteszt külön környezetben futtatandó; ezek sikeressége ebből a forráscsomagból önmagában nem állítható.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE6_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE6_HU.md]

## Platinum Intelligence 8.0 – Phase 6: Ultimate Integration

### Cél
A Phase 6 közös offline belépési ponttal kapcsolja össze a korábbi fázisok minőségellenőrzési, terminológiai, fordítási memória- és ismétlési komponenseit. A Room-adapter a már meglévő adatbázistáblákat használja.

### Új fájlok

- `core/src/main/java/hu/angolmagyar/fordito/OfflineIntelligencePipeline.kt`
  - Egyesített auditjelentés (jelentésinvariánsok + terminológia).
  - Offline memória-rangsorolás és ismétlési ütemezés egységes, mellékhatásmentes API-n.
- `app/src/main/java/hu/angolmagyar/fordito/core/OfflineIntelligenceRepository.kt`
  - Room adapter a szótárhoz, fordítási memóriához és ismétlési táblához.
  - IO dispatcher használata.
  - Korlátozott rangsorolási és ismétlési lekérdezési limitek.
  - Meglévő Room entitások és DAO-k használata.
- `core/src/test/java/hu/angolmagyar/fordito/OfflineIntelligencePipelineTest.kt`
  - Kombinált audit, üres figyelmeztetés, stabil memória-rangsorolás és ismétlési ütemezés tesztek.

### Adatbázis és kompatibilitás
- Room adatbázis verzió változatlanul 3.
- Nincs új tábla, oszlop vagy migráció.
- A `translation_memory`, `dictionary_entries` és `review_schedule` meglévő táblák kerülnek felhasználásra.
- Nincs jogosultság-, hálózati vagy fordítási kimenetet automatikusan módosító változtatás.
- A fordítási memória rangsorolása legfeljebb 2000 legutóbbi rekordot vizsgál; a visszaadott elemszám legfeljebb 20.
- Az esedékes ismétlések lekérdezése legfeljebb 200 rekordot ad vissza.

### API áttekintés
`OfflineIntelligenceRepository`:
- `auditTranslation(source, target)` – szótár és invariánsok együttes ellenőrzése.
- `rankSimilarTranslations(query, limit)` – hasonló helyi fordítások lexikai rangsorolása.
- `recordReview(englishKey, quality, nowEpochMs)` – ismétlés rögzítése és következő időpont kiszámítása.
- `dueReviews(nowEpochMs, limit)` – esedékes elemek lekérése.
- `dueReviewCount(nowEpochMs)` – esedékes elemek száma.

### Korlátok
- A memória-rangsorolás lexikai, nem neurális vagy szemantikus modell.
- Az audit figyelmeztetés, nem fordítási minőségi garancia.
- A Phase 6 repository API-t ad; automatikus UI bekötést és fordítási folyamatba történő kötelező beavatkozást nem végez.
- Az új funkciók teljes alkalmazásbeli használatához a képernyőknek / ViewModel-eknek explicit módon kell meghívniuk a repository-t.

### Validálás
Lásd `PHASE6_VALIDATION_HU.md`. A teljes Android Gradle build külső Gradle disztribúciót igényel; a build megkísérlése ebben a környezetben hálózati DNS-hiba miatt nem jutott el a fordításig.


---

<!-- forrás: PLATINUM_INTELLIGENCE_8.0_PHASE7_HU.md -->

## [PLATINUM_INTELLIGENCE_8.0_PHASE7_HU.md]

## Platinum Intelligence 8.0 – Phase 7: Ultimate Product Experience

### Cél
A Phase 5–6 offline minőségellenőrző és tanulási komponenseinek első, felhasználó által elérhető képernyő-integrációja.

### Új funkció
Az **Offline Intelligence Center** képernyő elérhető a Platinum Intelligence Suite központból. A képernyő:
- megmutatja a helyi szótár, fordítási memória és esedékes ismétlések darabszámát;
- lehetővé teszi angol forrásszöveg és magyar fordítás offline ellenőrzését;
- megjeleníti a szám-/tagadás- és szótári terminológiai figyelmeztetéseket;
- lexikai rangsorolással hasonló, korábban tárolt fordításokat keres;
- megjeleníti a következő esedékes ismétléseket.

### Biztonság és adatkezelés
- A képernyő csak helyi Room-adatokat olvas; az audit és a memória-rangsorolás nem küld adatot hálózatra.
- A képernyő nem írja át a fordításokat és nem módosítja a szótárat.
- Az ismétlési állapot ezen a képernyőn csak olvasható; a pontozás továbbra is a meglévő ismétlő képernyőben történik.
- A Room adatbázis verziója változatlan (3); nincs új migráció és nincs adatvesztéssel járó művelet.
- A szótári audit legfeljebb 5000 friss bejegyzést, a memória-keresés legfeljebb 2000 friss fordítást vizsgál.
- Az új Activity `exported=false` beállítású, belső alkalmazásképernyő.

### Módosított fájlok
- `app/src/main/java/hu/angolmagyar/fordito/ui/OfflineIntelligenceCenterActivity.kt` – új Compose képernyő.
- `app/src/main/java/hu/angolmagyar/fordito/ui/PlatinumIntelligenceActivity.kt` – navigációs belépési pont.
- `app/src/main/AndroidManifest.xml` – nem exportált Activity regisztráció.
- `app/src/main/java/hu/angolmagyar/fordito/core/OfflineIntelligenceRepository.kt` – helyi darabszámok és korlátozott szótárbeolvasás.
- `app/src/main/java/hu/angolmagyar/fordito/core/db/DictionaryDao.kt` – limitált, friss szótári lekérdezés.

### Korlátok
A memória-rangsorolás lexikai, nem embedding- vagy LLM-alapú szemantikus keresés. A figyelmeztető audit nem helyettesít emberi nyelvi ellenőrzést. A képernyő nem biztosít még szótárbejegyzés-szerkesztést vagy export/import műveletet; ezek külön, tranzakció- és validációközpontú fejlesztési hullámba tartoznak.


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V12_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V12_HU.md]

## Platinum Ultra Extreme UI v12 – Luxury Control Center

### Fő újdonságok
- A Diamond Experience panel alatt új, részletes Platinum Ultra állapotközpont jelenik meg.
- Fekete ónix és grafit alap, szálcsiszolt platina hatás, pezsgőarany kiemelések és finom, lekerekített metrikakártyák.
- Valós alkalmazásállapotot jelenít meg: élő fordítás állapota, hangszint, munkamenet időtartama vagy a felirat-feldolgozás százaléka.
- A mérőcsík a tényleges hangszintből vagy a feladat valós előrehaladásából dolgozik; nem generál kitalált aktivitást.
- A kezdőképernyő funkciói, navigációja és fordítási/feldolgozási logikája változatlan maradt.

### Módosított fájlok
- `app/src/main/java/hu/angolmagyar/fordito/ui/MainActivity.kt`
- `PLATINUM_ULTRA_EXTREME_V12_HU.md`
- `CHANGELOG.md`

### Ellenőrzési megjegyzés
A forrás- és ZIP-integritás ellenőrizhető. Az Android buildet és a készülékes vizuális tesztet külön Gradle-környezetben kell futtatni; sikeres buildet addig nem állítunk, amíg ténylegesen le nem futott.


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V13_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V13_HU.md]

## Platinum Ultra Extreme UI v13 – Platinum Spectrum

### Újdonságok
- Új, 32 oszlopos Platinum Spectrum hang-/feladatvizualizáció a kezdőképernyő állapotközpontjában.
- A spektrum az aktuális hangszintből, illetve a feladat tényleges százalékos állapotából számol; inaktív állapotban visszafogott, nyugalmi mintát mutat.
- Finoman pulzáló állapotjelző aktív fordítás vagy feldolgozás alatt.
- Animált, simább haladásjelző és hozzáférhetőségi leírás a spektrumhoz.
- V13 verziójelzés, a korábbi fordítási és fájlfeldolgozási folyamatok módosítása nélkül.

### Módosított fájlok
- `app/src/main/java/hu/angolmagyar/fordito/ui/MainActivity.kt`
- `PLATINUM_ULTRA_EXTREME_V13_HU.md`
- `CHANGELOG.md`

### Ellenőrzés
A forrás módosítása után meg kell kísérelni az offline Gradle-fordítást. Ha a környezetből hiányoznak a függőségek, a build állapota nem tekinthető igazoltnak.


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V14_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V14_HU.md]

## AngolMagyar – Platinum Ultra Extreme UI v14

### A javított csomagról
Ez a kiadás a teljes v13 forráscsomagból készült újracsomagolással, nem a korábbi hibás/hiányos v14 archívumból. A forrásfában a kezelőfelület verziójelzése V14-re frissült.

### Megőrzött funkciók
- A meglévő Android-projekt, Gradle modulok és wrapper.
- Platinum/Graphite felületi komponensek és Platinum Spectrum vizualizáció.
- A tényleges alkalmazásállapothoz kötött folyamat- és hangszint-visszajelzés.
- A meglévő fordítási, fájlkezelési és feldolgozási kód.

### Ellenőrzés
- ZIP-archívum: integritásellenőrzés elvégzendő a végleges csomagon.
- Fordítás: csak akkor tekinthető sikeresnek, ha a Gradle build a célkörnyezetben lefut.
- Az APK nem része ennek a csomagnak, mert itt nem igazolt a sikeres Android-build.

### Fordítás
Linux/macOS: `./gradlew assembleDebug`
Windows: `gradlew.bat assembleDebug`

Ha a Gradle disztribúció vagy a függőségek nem érhetők el, először hálózati hozzáférést és a Gradle wrapper letöltését kell biztosítani.


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V15_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V15_HU.md]

## AngolMagyar – Platinum Ultra Extreme UI v15: Infinity Edition

### Felületi fejlesztések
- Frissített „Platinum Infinity” fejléc és állapotközpont-cím.
- A spektrum 32 helyett 40 csatornát használ, keskenyebb közökkel és magasabb megjelenítési területtel.
- A spektrum felirata egyértelműen jelzi a 40 csatornás megjelenítést.
- Frissített V15 verziójelzés és lábléc.
- A spektrum továbbra is a meglévő hangszintből vagy a feldolgozás tényleges százalékából számol; nem generál hamis mérési adatot.

### Megőrzött elemek
- A teljes Android-projekt és az összes meglévő forrásfájl.
- Fordítási, fájlkezelési, feldolgozási és modellkezelési funkciók.
- A korábbi Platinum/Graphite komponensek és a hozzáférhetőségi leírás.

### Ellenőrzési állapot
- ZIP CRC/integritás: ellenőrizendő a létrehozott csomagon.
- Forrásellenőrzés: a módosított Kotlin-fájl és a V15 jelölések ellenőrizendők.
- Android build/APK: ebben a környezetben nincs igazolt Gradle build; a csomag nem tartalmaz ellenőrzötten lefordított APK-t.

### Fordítás
Linux/macOS: `./gradlew :app:assembleDebug`
Windows: `gradlew.bat :app:assembleDebug`


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V16_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V16_HU.md]

## AngolMagyar – Platinum Ultra Extreme v16: Infinity Luxury

### Ebben a csomagban ténylegesen módosult
- Az alkalmazás verziója 2.45.0-ról 2.46.0-ra, a versionCode 4500-ról 4600-ra frissült.
- A Platinum Ultra Console felületén V16 jelzés szerepel.
- A megjelenített hangszint és feladat-előrehaladás 0–100% tartományra korlátozott; a hangszint 0.0–1.0 közötti tartományban kerül a vizualizációba. Ez megakadályozza, hogy átmeneti vagy hibás bemeneti értékek túlcsorduló százalékot vagy széteső progress bart okozzanak.
- A 40 sávos spektrum továbbra is a mért hangszintből vagy a feldolgozás előrehaladásából rajzolódik, nem állít elő független, hamis mérési adatokat.
- A meglévő alkalmazásfunkciók és a Platinum/Graphite/Champagne felületi rendszer megmaradtak.

### Ellenőrzés
- A ZIP bemeneti csomag megnyitható volt, 390 bejegyzéssel.
- Forrásmódosítás és verziójelzés frissítve.
- Android build nem igazolt: a `bash gradlew :app:assembleDebug --no-daemon` a Gradle 8.9 letöltésekor `UnknownHostException: services.gradle.org` hibával leállt, mert a buildkörnyezet nem éri el a letöltési kiszolgálót. Ezért ehhez a csomaghoz nem állítom, hogy ellenőrzött APK készült.

### Fordítás
Linux/macOS: `bash gradlew :app:assembleDebug`
Windows: `gradlew.bat :app:assembleDebug`


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V17_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V17_HU.md]

## AngolMagyar – Platinum Ultra Extreme v17: Infinity Luxury Plus

### V17 módosítások
- Verzió: 2.47.0, versionCode 4700.
- A prémium letöltési/haladási sáv egységesen a 0–100 tartományba korlátozott százalékot mutatja a feliraton, a kisegítő lehetőségek leírásában és a grafikus kitöltésben is.
- A negatív érték továbbra is az ismeretlen haladást jelöli; ilyenkor animált folyamatjelző jelenik meg százalék kitalálása nélkül.
- Új egységtesztek ellenőrzik az alsó és felső határt, valamint az érvényes százalékok megőrzését.
- A V16 Platinum/Graphite/Champagne megjelenés és a meglévő funkciók megmaradnak.

### Ellenőrzési állapot
- A ZIP csomag ellenőrzése és a forrásmódosítások megtörténtek.
- A Gradle/Android buildet ebben a környezetben külön kell futtatni; sikeres APK-fordítás nincs igazolva.

### Fordítás
Linux/macOS: `bash gradlew :app:testDebugUnitTest :app:assembleDebug`
Windows: `gradlew.bat :app:testDebugUnitTest :app:assembleDebug`


---

<!-- forrás: PLATINUM_ULTRA_EXTREME_V18_HU.md -->

## [PLATINUM_ULTRA_EXTREME_V18_HU.md]

## AngolMagyar V18 – Platinum Infinity Luxury Plus

### Változások

- A folyamatjelző akadálymentes szemantikát ad: `ProgressBar` szerep, ismert haladásnál 0–100-as tartomány, ismeretlen haladásnál indeterminált állapot.
- A százalékot biztonságosan korlátozó `safeProgressPercent` tiszta Kotlin-függvény, ezért a unit teszt közvetlenül tesztelheti.
- Az ismeretlen haladás továbbra sem jelenik meg hamis százalékként.
- Verzió: 2.48.0, versionCode 4800.

### Ellenőrzési állapot

A ZIP-et a módosított forrásokból állítjuk elő. A teljes Android-build és a JUnit-tesztek futtatása nem volt lehetséges: a Gradle Wrapper a `services.gradle.org` címet nem tudta feloldani (`UnknownHostException`). Emiatt a build sikeressége nem állítható.


---

<!-- forrás: PREMIUM_INTELLIGENCE_5.0_SPEC_HU.md -->

## [PREMIUM_INTELLIGENCE_5.0_SPEC_HU.md]

## AngolMagyar Premium Intelligence 5.0 – teljes fejlesztési specifikáció

### Termékcél

Az AngolMagyar egyetlen koherens, kétirányú angol–magyar nyelvi munkakörnyezetté váljon: fordítás, beszéd, tanulás, felirat, dokumentum és minőségbiztosítás közös projekttel, terminológiával, előzményekkel és adatvédelmi vezérléssel.

A v5.0 célverzió nem tekinthető késznek pusztán attól, hogy egy API vagy képernyő létezik. Minden képességnek végig kell érnie a teljes felhasználói útvonalon: felület → domain logika → tárolás → hibaállapot → teszt → dokumentáció.

### 1. Infinity Context AI – kontextusérzékeny fordítás

#### Elvárt működés
- A fordítás kapja meg az előző és következő mondatot, a beszélőazonosítót, a projekt témáját és a projekthez tartozó jóváhagyott terminológiát.
- Hangnemek: természetes, szó szerinti, hivatalos, társalgási, üzleti, műszaki és feliratbarát.
- Legfeljebb három alternatíva jelenjen meg, rövid indoklással és egyértelmű eredetjelöléssel.
- A bizonytalanság legyen külön jelölve; heurisztikus jelzés nem nevezhető AI-bizonyosságnak.
- Kézzel jóváhagyott fordítás automatikusan nem írható felül.

#### Integráció
A meglévő `SmartContextTranslation`, `OnlineTranslator`, `TranslationStyle`, `TranslationMemory` és `GlossaryStore` közös ContextRequest/TranslationCandidate adatfolyamot használjon. Az offline heurisztika és a külső generatív szolgáltató külön motor maradjon; hálózat nélküli módban a generatív opció ne jelenjen meg elérhetőként.

### 2. Translation Quality Intelligence

- Külön ellenőrzés: számok, dátumok, nevek, tagadás, hiányzó/duplikált sorok, terminológia, nyelvtani és írásjelezési hibák.
- Súlyossági szintek: információ, figyelmeztetés, blokkoló hiba.
- Soronkénti eredet: szabályalapú, ASR-konfidencia, referenciaadat vagy külső modell.
- Mért WER/CER csak kézzel ellenőrzött referenciaátirattal számolható.
- A becsült minőség, szabálytalálat és tényleges pontosság külön kijelzésű.
- Egyérintéses hangrészlet-visszajátszás és célzott újrafelismerés.

### 3. Voice Intelligence Studio

- Élő és fájlból történő angol–magyar beszédmód.
- US/UK TTS-hangválasztás, a telepített Android hangadatok ellenőrzésével.
- Mondatonkénti gyakorlás, rögzítés, visszajátszás és lassítás.
- Kiejtési értékelés csak fonetikai/ASR-alapú, referenciahanggal validált metrikából készülhet.
- Beszédtempó, szünet, érthetőség és szövegfelismerési egyezés külön mérőszám.
- Beszélőnkénti szakaszolás és feliratkapcsolat.

### 4. Personal Learning Intelligence

- A meglévő SM-2 ismétlés és tanulási analitika közös tanulási profilt használjon.
- Gyenge szavak és hibásan fordított kifejezések automatikus gyakorlólistája.
- Aktív és passzív szókincs külön mérése.
- Napi/ heti / havi célok, témakörök, tanulási sorozat és teljesítményjelvények.
- A felhasználó módosíthassa az ütemezést; a rendszer ne büntesse a kihagyott napokat.
- Minden statisztika legyen visszavezethető tényleges tanulási eseményre.

### 5. Subtitle Studio Pro

- Eredeti és fordított felirat párhuzamos nézete.
- Hanghullám, idővonal, soronkénti hang-visszajátszás.
- SRT/VTT/ASS/TXT import/export, hibás fájlok biztonságos visszautasítása.
- Szó- és mondatszintű időzítés, olvasási sebesség, átfedés, sortörés és üres blokkok ellenőrzése.
- Visszavonás/ismétlés, automatikus mentés, verzió-összehasonlítás.
- Hosszú feldolgozás checkpointtal és megszakítás utáni folytatással.

### 6. Offline AI & Privacy Vault

- Offline/online állapot egyértelmű jelzése minden feldolgozásnál.
- API-kulcs kizárólag Android Keystore AES-GCM titkosítással; titkosítási hiba esetén nincs plaintext fallback.
- Titkosított, jelszóval védett biztonsági mentés; import előtt integritás- és méretellenőrzés.
- Biometrikus alkalmazászár opcionális, helyreállítási útmutatóval.
- Ideiglenes hang- és szövegfájlok megőrzési ideje állítható.
- Külső AI szolgáltató használata előtt egyértelmű adatküldési hozzájárulás.
- Adat-export, projekt- és előzménytörlés, naplóanonimizálás.

### 7. Smart Translation Memory

- Globális és projektszintű terminológia.
- Állapotok: PENDING, APPROVED, DISMISSED, RETIRED.
- Jóváhagyott projektterminus elsőbbséget kap a globális javaslattal szemben.
- Ütközés, duplikáció és eltérő fordítás észlelése.
- Import előnézet, hibás sorok listája, TSV/CSV export.
- Szótármódosítás előtti hatásvizsgálat; pontos egyezésű érintett sorok listája.
- Újrafordítás csak explicit jóváhagyással; kézzel jóváhagyott fordítás védett.

### 8. Diamond Experience

- Forest Graphite, Platinum, Obsidian, Gold, Arctic és Sapphire paletták.
- Világos, sötét és OLED sötét mód.
- Egységes komponens-tokenek, tipográfia, térköz, kártyák és állapotjelzések.
- Kompakt/normál/kényelmes sűrűség; nagy betűméret és akadálymentes kontraszt.
- Csökkentett mozgás, animációk visszafogása energiatakarékos módban.
- Kezdőlap: új fordítás, élő tolmács, feliratprojekt, tanulás, legutóbbi projektek és folyamatban lévő feladatok.
- Klasszikus View képernyők fokozatos átemelése a közös design rendszerbe.

### 9. Kiegészítő prémium funkciók

#### AI Conversation Partner
Beszédgyakorló mód szerepjátékokkal, szinthez igazított kérdésekkel, javítási magyarázattal és beszédértékeléssel. Generatív párbeszédhez szolgáltatói kulcs és internet szükséges; offline változat csak előre definiált gyakorlatokat használhat.

#### Live Interpreter
Kétirányú élő beszélgetés, beszélőváltás, push-to-talk, felirat és TTS. A mikrofonengedélyt csak a felhasználó által indított munkamenet alatt kérheti; háttérben nem rögzíthet rejtetten.

#### Smart Camera Translate
Kameraképből OCR, kiválasztott szöveg fordítása, eredeti/fordított szöveg és adatvédelmi figyelmeztetés. Külön CameraX és ML Kit Text Recognition integráció, kameraengedély és valós készülékes teszt szükséges.

#### Document Intelligence
PDF/DOCX/TXT import, szerkezetmegőrző fordítás, táblázat- és bekezdéskezelés, export és dokumentum-összehasonlítás. A beolvasott PDF OCR-t igényelhet; ezt külön kell jelezni.

#### Meeting Assistant
Megbeszélés-átirat, beszélőcímkék, fordítás, döntések és teendők összefoglalója. A meglévő MeetingMode/MeetingSummary alapokra épüljön; összefoglaló generálása előtt a forrás és az adatküldés legyen látható.

#### Cloud Sync
Végponttól végpontig titkosított szinkron, konfliktusfeloldás, eszközlista és visszavonható hozzáférés. Szolgáltató, autentikáció, adatkezelési feltételek és backend még nincs rögzítve; ezek nélkül felhőszinkron nem aktiválható és nem állítható késznek.

#### Smart Export
DOCX/SRT/VTT/ASS/TXT export, fájlnevek és metaadatok védelme, sablonok, export előnézet és hibajelentés.

### 10. Adat- és hibakezelési alapelvek

- A forrás, automatikus átirat, kézi javítás és végleges fordítás külön változat.
- Minden módosítás visszavezethető legyen forrásra, időpontra, motorra és felhasználói jóváhagyásra.
- Sikertelen hálózati kérés ne törölje a forrásszöveget.
- Hosszú feladatnál megszakítás és folytatás; duplikált feladat ne fusson véletlenül kétszer.
- Külső adatküldés előtt világos jelzés; titkok soha nem kerülhetnek naplóba.

### 11. v5.0 kiadási kapu

A v5.0 csak akkor nevezhető teljes kiadásnak, ha:
1. Android és Wear build sikeres.
2. Minden unit és instrumented teszt sikeres.
3. Valós, engedéllyel használható referenciahangok WER/CER benchmarkja dokumentált.
4. Kamera, dokumentum, élő beszéd, felirat és tanulás fizikai eszközön tesztelt.
5. Offline mód hálózat nélkül is ellenőrzött.
6. Titkosítás, mentés-visszaállítás, export és adat-törlés tesztelt.
7. Accessibility, világos/sötét/OLED és kis/nagy kijelző screenshot ellenőrzés megtörtént.
8. Saját release-keystore-ral aláírt APK/AAB készült, és a frissítési útvonal ellenőrzött.


---

<!-- forrás: PREMIUM_ROADMAP_HU.md -->

## [PREMIUM_ROADMAP_HU.md]

## AngolMagyar Gyémánt Edition – prémium fejlesztési specifikáció

Ez a dokumentum a teljes javaslatcsomag célállapotát és az integrációs sorrendet rögzíti. A tervben szereplő funkciók nem mind kész funkciók; a státuszt az alábbi jelölések különítik el.

- **Elkészült ebben a csomagban:** konkrét forráskód vagy teszt került be.
- **Meglévő alap / ellenőrizendő:** a projektben már van kapcsolódó komponens, de teljes körű működése nincs ebben a csomagban igazolva.
- **Következő integráció:** szükséges a teljes felhasználói munkafolyamathoz.

### 1. Diamond Signature UI

Cél: elegáns, csendes luxus; nem túlzsúfolt, gyors és akadálymentes felület.

- Grafit, OLED-fekete, világos, Gyémánt és Platina színpaletta.
- Egységes tipográfiai skála, ikonméret, lekerekítés, térköz és komponensállapot.
- Kártyák és fő műveletek egyértelmű hierarchiája; a csillogás és animáció nem vonhatja el a figyelmet.
- Kompakt / normál / kényelmes sűrűség, dinamikus betűméret és megfelelő kontraszt.
- Animációk visszafogása rendszerbeállítás szerint, csökkentett mozgás lehetősége.
- Kezdőlap: új feladat, folytatás, legutóbbi projektek, mentett sablonok és feldolgozási sor.

**Státusz:** a meglévő témarendszer bővült Platina palettával; teljes képernyőszintű design-system átalakítás és vizuális regressziós teszt még szükséges.

### 2. Pontos átirat és biztonságos minőségellenőrzés

- A forrás-átirat, a kézzel javított átirat és a fordítás külön változatként maradjon meg.
- Jelölje a bizonytalan szavakat, számokat, dátumokat, neveket, tagadásokat, hiányzó vagy ismétlődő szakaszokat.
- A jelzés prioritást mutasson, ne állítsa bizonyíték nélkül, hogy egy adott szó hibás.
- Egyérintéses hangrészlet-visszajátszás és célzott újrafelismerés.
- Referenciahangon és kézzel ellenőrzött referenciaátiraton alapuló benchmark; WER és feldolgozási idő külön mérve.
- Ne jelenjen meg tényleges felismerési pontosságként pusztán heurisztikából számított pontszám.

**Státusz:** meglévő ellenőrzési és célzott felülvizsgálati alapok találhatók a projektben; teljes pipeline-integrációt és készülékes ellenőrzést még el kell végezni.

### 3. Kontextusérzékeny fordítás

- Előző/következő mondat, beszélő, projekt és szakterület kontextusának figyelembevétele.
- Stílusprofilok: természetes, szó szerinti, üzleti, műszaki, társalgási és feliratbarát.
- Szám-, dátum-, tagadás- és entitáskonzisztencia ellenőrzése.
- A gépi fordítás, szótárszabály és kézi jóváhagyás eredetének látható jelölése.
- Az automatikus javítás ne írja felül csendben a kézzel jóváhagyott szöveget.

**Státusz:** meglévő fordítási memória és fordításellenőrző komponensek; egységes eredet- és verziókezelés integrálandó.

### 4. Szótár és terminológia

- Globális és projektszintű szótár.
- PENDING / APPROVED / DISMISSED / RETIRED állapotok.
- Konfliktuskeresés, duplikátum- és eltérő fordításjelzés.
- Projekt-szótár elsőbbsége a globális szótárral szemben, csak jóváhagyott bejegyzés esetén.
- Példamondat, megjegyzés, forrás és módosítási előzmény.
- TSV import/export, hibás sorok jelentése, import előnézete.
- Változatmentés, visszaállítás és archiválás végleges törlés helyett.
- Tanulási javaslatok; globális automatikus elfogadás csak explicit beállítással és világos visszavonási lehetőséggel.

**Státusz:** ebben a csomagban elkészült a `GlossaryGovernance` API és tesztjei; a meglévő tanuló és javítólistákhoz, tároláshoz és UI-hoz integrálni kell.

### 5. Újrafordítás és hatásvizsgálat

- Szótárváltoztatás előtt mutassa meg az érintett projektek, mondatok és feliratblokkok számát.
- Pontos kifejezés-egyezésből induljon ki; fuzzy találat csak külön, felülvizsgálható javaslat legyen.
- Mutassa egymás mellett az előző és az új fordítást, eltérésekkel.
- Műveletek: elfogadás, elutasítás, csak a kiválasztott sor, kijelölt sorok vagy projekt újrafeldolgozása.
- A kézzel jóváhagyott szöveg megőrzése alapértelmezés legyen.
- Minden művelethez visszavonás, naplóbejegyzés és forrás-/modell-/szótárverzió.

**Státusz:** a csomagban a terminusok pontos találatainak hatás-előnézete elkészült külön API-ként; a fordítási pipeline-hoz kötés még szükséges.

### 6. Szerkesztő és feliratstúdió

- Eredeti szöveg és fordítás egymás mellett; szinkronizált időbélyeg és hanghullám.
- Mondatra vagy sorra koppintva lejátszás a megfelelő időponttól.
- Visszavonás/ismétlés, keresés, többszörös kijelölés és biztonságos automatikus mentés.
- SRT / VTT / TXT export, sortörés- és olvashatósági ellenőrzés.
- Felirat-hossz, olvasási sebesség, üres blokk, átfedő időbélyeg és sorrend ellenőrzése.
- Eltérő verziók vizuális összehasonlítása.

**Státusz:** meglévő felirat- és átiratszerkesztők vannak; teljes szinkronizálás és UX-ellenőrzés készülékes próbát igényel.

### 7. Megbízható feldolgozás és adatvédelem

- Hosszú feladatok folytathatósága, checkpoint, feladat-sor, megszakítás utáni helyreállítás.
- Valós, mért feldolgozási idő és egyértelmű hibaállapotok.
- Helyi és felhőfeldolgozás világos megkülönböztetése.
- API-kulcsok biztonságos tárolása; titkok nem kerülhetnek naplóba vagy exportba.
- Projektadatok, átiratok és naplók törlésének/megőrzésének érthető szabályai.
- Importált fájlok és mentések validálása, sérült fájl esetén biztonságos visszautasítás.

**Státusz:** meglévő kapcsolódó komponensek és korábbi ellenőrzőlisták vannak; kiadás előtti biztonsági és eszköztesztek szükségesek.

### 8. Javasolt megvalósítási sorrend

1. Reprodukálható Android build és teljes tesztfuttatás.
2. Szótár-adatmodell, jóváhagyási folyamat, migráció és visszaállítás.
3. Szótár-hatásvizsgálat és célzott újrafordítás a pipeline-ban.
4. Forrás/fordítás változatkezelése, auditnapló és összehasonlító nézet.
5. Hangrészlet-visszajátszás és bizonytalan szakaszok ellenőrzése.
6. Minőségmérés referenciaadatokon; a pontossági állítások validálása.
7. Egységes Diamond / Platinum felület, akadálymentesség és vizuális regressziós ellenőrzés.
8. Hosszú fájlok, megszakítás, offline mód, export és adatvédelmi tesztek valódi Android-eszközön.

### Kiadási kapu

A csomag csak akkor nevezhető teljesen kész Android-kiadásnak, ha a Gradle build, a JUnit tesztek, az APK összeállítása, az alap munkafolyamat és a valós készülékes tesztek sikeresek. A jelen csomag forráskódot tartalmaz, nem igazoltan kész APK-t.


---

<!-- forrás: PREMIUM_UI_BLUE_CINEMATIC_HU.md -->

## [PREMIUM_UI_BLUE_CINEMATIC_HU.md]

## Angol–Magyar 2.45.0 – Electric Blue Cinematic UI

### Megvalósított módosítások

- Egységes Electric Blue + Deep Navy paletta a Compose és a klasszikus Android View felületek erőforrás-szintű témájában.
- Cyan másodlagos kiemelőszín, világos témában kontrasztos kék paletta.
- OLED mód megtartva: a true-black háttér továbbra is a felhasználói beállítást követi.
- A kezdőlapi aktív feladatkártya filmszerű, ötállomásos folyamatnézetet kapott: Hang, Betöltés, Felismerés, Fordítás, Mentés.
- Animált százalékos folyamatjelző, pulzáló aktív állomás, elvégzett állomások jelölése és a meglévő részletes feladatképernyőre vezető kattintás megmaradt.
- A kezdőképernyőn a meglévő navigáció, modellek, fordítási vezérlők, átiratok, szókincstár, diagnosztika, mikrofon és futó élő fordítás funkciók változatlan callbackeken keresztül működnek.
- A Beállítások Compose megjelenésoldala is az új kék palettát használja.

### Működési elvek

A folyamatállomások kiemelése a már létező `SrtJob.overall` összesített százalékból származik; a UI nem talál ki külön háttérfeladat-állapotokat. A tényleges üzenet, százalék és navigáció továbbra is az alkalmazás meglévő állapotából érkezik.

### Build ellenőrzés

A forráskód módosítva és csomagolva. Ebben a környezetben az Android build nem futott le, mert a Gradle Wrapper 8.9 disztribúció letöltéséhez szükséges hálózati kapcsolat nem érhető el (`UnknownHostException: services.gradle.org`). Buildelés Android Studio-ban vagy hálózattal rendelkező build környezetben:

```bash
./gradlew :app:assembleDebug
```


---

<!-- forrás: PREMIUM_UI_BLUE_CINEMATIC_V3_HU.md -->

## [PREMIUM_UI_BLUE_CINEMATIC_V3_HU.md]

## Blue Cinematic UI – 3. fejlesztési kör

### Érintett felületek
- Élő fordítás: új, kék cinematic hero fejléc.
- Modellkezelő: AI Model Center fejléc és motor-szekció címke.
- Mentett átiratok: Library fejléc, a meglévő keresés/szűrés megtartásával.
- Diagnosztika: System Check fejléc, a meglévő ellenőrző logika és műveletek megtartásával.
- Beállítások: Control Center fejléc, a meglévő beállítások és callbackek megtartásával.

### Közös vizuális rendszer
- A régi View-alapú képernyők is megkapják a kék/cyan cinematic kártyaperemet.
- Kártyák rövid, visszafogott belépési animációt kapnak.
- Az új hero komponens mély navy átmenetes hátteret, cyan tipográfiai kiemelést és belépési animációt használ.
- A funkcionális elemek (keresés, letöltés, modelválasztás, diagnosztikai javítások, navigáció) változatlan műveleti logikával működnek.

### Ellenőrzés
A forráskód módosítva és csomagolva. A Gradle buildet külön Android/Gradle környezetben kell futtatni; sikeres buildet e csomag nem állít.


---

<!-- forrás: PREMIUM_UI_BLUE_CINEMATIC_V4_HU.md -->

## [PREMIUM_UI_BLUE_CINEMATIC_V4_HU.md]

## Blue Cinematic UI – 4. fejlesztési kör

### Irány
Cinematic Platinum Blue: mély navy, elektromos kék, cyan fények, hideg fehér felületek.

### Közös felületi rendszer
- A Compose PremiumCard egységes, cyan-kék átmenetes peremet, finom árnyékot és 360 ms-os belépést kapott.
- A régi View-alapú Ui.card elemek kékes, többrétegű felületet és visszafogott belépési animációt kaptak; a csökkentett animáció beállítást tiszteletben tartják.
- A régi ScrollView képernyők egységes háttérkitöltést, viewport-viselkedést és visszafogott görgetési túlcsordulást kaptak.
- A hero fejléc minden régi képernyőn fénycsíkos, navy átmenetes megjelenést használ.
- A világos színpaletta hideg, kékes fehér tónusokra frissült; az éjszakai paletta továbbra is mély navy, az OLED mód pedig megmarad.
- A meglévő vezérlők, callbackek, navigáció, fordítási és letöltési logika változatlan.

### Érintett alkalmazásrétegek
- Compose kezdőlap és közös prémium kártyarendszer.
- Régi View-alapú képernyők közös kártya- és fejlécépítői (így a modellek, diagnosztika, beállítások, átiratok, felirat- és feladatképernyők).
- Közös erőforrás-paletta.

### Build és teszt
A forrásmódosítás elkészült. A teljes Android Gradle build és eszközteszt csak Android SDK-val és elérhető Gradle függőségekkel igazolható; sikeres APK buildet ez a csomag nem állít.


---

<!-- forrás: PREMIUM_UI_PLATINUM_V5_HU.md -->

## [PREMIUM_UI_PLATINUM_V5_HU.md]

## AngolMagyar 2.45.0 – Platinum Luxury v5

**Állapot:** forrásszintű módosítás. Lefordítani és eszközön kipróbálni nem tudtam (nincs Kotlin fordító / Gradle a környezetben), ezért a build még igazolásra vár: `./gradlew :app:assembleDebug`.

### Új vizuális nyelv
Ónix-fekete alap, platina fémfények, pezsgőarany (champagne) kiemelés, ékkő-színű állapotjelzők. Paletta: `ui/design/PlatinumColors.kt`.

### Részlet-gazdag platina folyamatjelzések
| Elem | Fájl | Mit mutat (valós adatból) |
|---|---|---|
| **Platina műszer** | `PlatinumDial.kt` | fémes kávagyűrű lassan körbejáró fénnyel, 60 gravírozott osztás (a lehető legpontosabb %-hoz kigyulladnak), haladásív pezsgőarany ívéggel és fénylő véggel, **szegmensgyűrű** (egy szegmens = egy feldolgozott darab: kész = jégkék, éppen dolgozó = pulzáló arany, hátralévő = sötét), üveg-visszfény |
| **Ékköves folyamatvonal** | `PlatinumTimeline.kt` | 5 csomópont fémes foglalatban; állapot szerint ékkő: vár (sötét), fut (arany, forgó ív, táguló gyűrű), kész (smaragd, rajzolódó pipa), figyelmeztetés (borostyán), hiba (rubin), megszakítva (acél); bevésett sín milestone-jelekkel; a kitöltött szakaszon fényes csillanás fut végig; csomópont alatt **lépésenkénti idő** vagy futó % |
| **Gravírozott statisztikák** | `PlatinumPanel.kt` | eltelt idő (másodpercenként ketyeg), hátralévő idő + az ETA alapja, szegmens x/y, fájlsor, motor |
| **Platina kártya** | `PlatinumPanel.kt` | átmenetes fémes háttér, fényes peremvonal, felső hajszálfény, lépcsőzetes belépés |
| **Befejezési pecsét** | `CompletionBurst.kt` | pezsgőarany / platina / smaragd szikragyűrű, csak élő „kész” átmenetnél |
| Hiba / figyelmeztetés | `PlatinumPanel.kt` | rubin / borostyán üvegsáv a részletekkel (kihagyott részek, fordítói megjegyzés) |

### Őszinteség-elv (nincs hamis jelzés)
- Ha a % nem ismert, a műszer „—”-t mutat, az osztások nem gyulladnak ki.
- Szegmensgyűrű csak ismert darabszámnál (1–72) rajzolódik.
- Hátralévő idő: „számítás…”, amíg a motor nem ad becslést.
- Az animációk csak díszítenek, a haladást nem találják ki.

### Beállítások
- **Platinum Luxury téma** (alapértelmezés: be; kikapcsolva a Blue Cinematic kártya jelenik meg).
- **Prémium feldolgozó kártya** (kikapcsolva a régi `PipelineView`).
- **Csökkentett animáció** (a rendszer animációkapcsolóját is figyeli): a forgás, csillanás, pulzálás, pecsét kimarad, a színek és jelek megmaradnak.

### Hátravan
- Build, eszközteszt, teljesítmény (képkocka-idő, akku) mérése hosszú feldolgozás alatt.
- Platina téma a többi képernyőre (modellkezelő, átiratok, diagnosztika, beállítások, élő fordítás).
- Élő mikrofon-hullám platina stílusban.
- Unit/snapshot tesztek (Robolectric kell a `SrtJob` miatt).
- Hangeffekt / haptika a befejezéshez (opcionális).


---

<!-- forrás: PREMIUM_UI_PLATINUM_V6_HU.md -->

## [PREMIUM_UI_PLATINUM_V6_HU.md]

## AngolMagyar 2.45.0 – Platinum Luxury v6 (interaktív folyamatábra)

**Állapot:** forrásszintű módosítás, lefordítva és eszközön kipróbálva NEM lett (nincs Kotlin fordító / Gradle a környezetben). Első lépés: `./gradlew :app:assembleDebug`.

A képernyőképeken kért irány (platina–fekete–pezsgőarany, többrétegű üveghatás, összetett összekapcsolt folyamatábra animált vonalakkal és adatáramlással, interaktív csomópontok, dinamikus grafikon, mikrointerakciók) ebben a körben a feldolgozó kártyára került.

### Újdonságok
| Elem | Fájl | Leírás |
|---|---|---|
| **Összekapcsolt folyamatábra** | `PlatinumFlowGraph.kt` | ívelt (Bézier) összekötők zegzugos elrendezésben; a kitöltés a valós haladás; a futó szakaszon pezsgőarany **adatáramlás-fénypontok** futnak az éren; fordításnál a Felismerés után külön **Fordítás** csomópont jelenik meg (lefordított sorok számával) |
| **Interaktív csomópontok** | `PlatinumFlowGraph.kt`, `PlatinumPanel.kt` | érintésre a csomópont kijelölődik (arany gyűrű, haptikus visszajelzés), alatta üvegkártyán részletek: állapot, idő, haladás, szegmens, megjegyzés, fordítómotor; újabb érintés bezárja |
| **Üveg-felület** | `PlatinumGlass.kt` | áttetsző fehér réteg, ferde fénykiemelés, átmenetes perem |
| **Mikrointerakció** | `PlatinumGlass.kt` (`pressScale`) | az üvegkártya érintésre finoman összenyomódik, a görgetést nem zavarja |
| **Dinamikus grafikon** | `PlatinumSparkline.kt` | a teljes haladás időbeli menete; a mintákat a panel a valós %-értékekből gyűjti, új feldolgozásnál nullázódik |

### Őszinteség-elv
- Az adatáramlás-pontok csak akkor mozognak, ha a forráslépés ténylegesen fut.
- A Fordítás csomópont nem külön mért lépés: a Felismerés + fordítás egyetlen `SrtJob`-lépés, ezért a csomópont a felismerés állapotát és haladását követi, a sorok száma viszont valós (`engOnline + engOffline`).
- A grafikon üres, amíg nincs legalább két valós minta.
- Csökkentett animáció módban a pontok, csillanások és a nyomás-animáció kimarad.

### Hátravan (a képernyőképek alapján)
- Platina téma a **kezdőképernyőre** (prémium fejléc, hangforrás-választó, utolsó feldolgozások), a **modellkezelőre** (telepített modellek, méret, letöltési sebesség és %), az átiratokra, diagnosztikára, élő fordításra.
- Élő mikrofon-hullám (32–64 oszlop, valós RMS, mikrofon / belső hang megkülönböztetése) – az `AudioRecorder` hangerő-kimenetét ki kell vezetni.
- Szünet/folytatás a feldolgozásban, ha a motor támogatja.
- Build, eszközteszt, képkocka-idő és akku mérése; unit/snapshot tesztek (Robolectric kell a `SrtJob` miatt).
- Opcionális: 3D hatású (perspektivikus) rétegek, parallax.


---

<!-- forrás: PREMIUM_UI_PLATINUM_V7_HU.md -->

## [PREMIUM_UI_PLATINUM_V7_HU.md]

## AngolMagyar 2.45.0 – Platinum Luxury v7

**Állapot:** forrásszintű módosítás, lefordítva és eszközön kipróbálva NEM lett (nincs Kotlin fordító / Gradle a környezetben). Első lépés: `./gradlew :app:assembleDebug`.

### Újdonságok (a Platinum téma kapcsolója érvényes rájuk; kikapcsolva a régi elemek jelennek meg)
| Képernyő | Elem | Fájl |
|---|---|---|
| **Élő fordítás** | **Platina hangszintmérő**: 48 oszlop, balra gördülő előzmény; forrás-címke (Mikrofon / Belső hang / Push-to-talk), állapot (Figyel / Csend / Szünet / Készenlét), szint % és lassan lecsengő csúcsérték | `PlatinumLevelMeter.kt`, `LiveTranslateActivity` |
| **Modellkezelő** | **Platina haladássáv** letöltéshez: kefélt fém kitöltés, 20 gravírozott osztás, csillanás; ismeretlen haladásnál csak futó fénycsík (százalék nélkül); a meglévő sebesség-, méret-, ETA-felirat alatta látszik | `PlatinumProgressBar.kt`, `ModelsActivity` |

### Őszinteség-elv
- A hangszintmérő oszlopai az `AppState.level` valós, korábbi mintái. Nincs hozzáadott hullámzás; csendben csak vékony pont látszik. A forrás az `AppState.mode`-ból jön.
- A letöltősáv csak a `post(pct, msg)` valós értékét mutatja; `pct < 0` esetén nem mutat százalékot.
- Csökkentett animáció módban a csillanás kimarad, a mérő ritkábban frissül.

### Hátravan
- Platina téma a kezdőképernyőre (`ui/MainActivity.kt`), az átiratokra, diagnosztikára, beállításokra.
- Modellkezelő kártyák (telepített modellek, méret) platina kinézettel.
- Szünet/folytatás a feldolgozásban.
- Build, eszközteszt, képkocka-idő és akku mérése; unit/snapshot tesztek.


---

<!-- forrás: QUALITY_CHECK_HU.md -->

## [QUALITY_CHECK_HU.md]

## Export előtti minőségellenőrzés – Gyémánt Edition

Az új `SrtQualityCheck` a felirat exportálása előtt futtatható, tisztán ellenőrző komponens. Nem módosítja a feliratokat.

- **Hiba (ERROR):** negatív kezdési idő, nem pozitív időtartam vagy nem időrendi bejegyzés. Ezek blokkolhatják az exportot.
- **Figyelmeztetés (WARNING):** üres fordítás, mindkét mező üres, illetve időbeli átfedés. Ezek nem tiltják automatikusan az exportot, mert lehetnek szándékosak.
- **Információ (INFO):** hiányzó forrásszöveg `BOTH` módban, ha van fordítás.

Példa:

```kotlin
val report = SrtQualityCheck.inspect(cues, SrtExporter.Mode.BOTH)
if (report.canExport) {
    // Az export engedélyezhető; a figyelmeztetéseket ettől még érdemes megmutatni.
}
```

A jelenlegi frissítés az ellenőrző komponenst és a teszteket adja hozzá. A teljes Android UI-ba történő bekötés és az eszközteszt külön következő lépés. A Gradle-tesztfuttatás ebben a környezetben nem indult el, mert a Gradle 8.9 disztribúció nem tölthető le hálózati korlátozás miatt.


---

<!-- forrás: QUALITY_CHECK_V17_HU.md -->

## [QUALITY_CHECK_V17_HU.md]

## V17 minőségellenőrzési jegyzőkönyv

### Elvégzett ellenőrzések
- A projekt ZIP tartalma kibontásra került.
- A haladássáv kódjában a megjelenített százalék, a progress animáció és a képernyőolvasó-leírás ugyanazt a 0–100 közé szorított értéket használja.
- Az ismeretlen haladás (`pct < 0`) továbbra sem jelenít meg kitalált százalékot.
- Egységtesztek kerültek a határértékek és a normál értékek ellenőrzésére.

### Még ellenőrizendő
- `:app:testDebugUnitTest`
- `:app:assembleDebug`
- Valódi Android-eszközön: mikrofonengedély, háttérbe lépés, hangszintmérő, fordítás, feliratimport/export.

APK csak sikeres fordítás és telepítési próba után tekinthető ellenőrzöttnek.


---

<!-- forrás: QUALITY_IMPROVEMENTS_HU.md -->

## [QUALITY_IMPROVEMENTS_HU.md]

## AngolMagyar v2.28.7 – minőségi fejlesztések és ellenőrzési terv

### Ebben a verzióban megvalósítva

#### Ellenőrzési prioritás (v2.28.7)
- A „Legrosszabb 10 sor” nézet a jelzések súlyozott súlyossága szerint rendez, nem időrendben.
- A gyenge szókonfidencia nagyobb prioritást kap; a beszéd/csend gyanúja, a töredék és a szokatlan hosszarány közepes súlyú.
- Ez a rendezés csak az ellenőrzési sorrendet módosítja; nem töröl és nem ír át szöveget.

#### Tartalmi hűség
- A `TextPolish.cleanWhisperOutput()` és a nyelvenkénti utófeldolgozás alapból nem távolít el töltelékszavakat.
- A töltelékszó-eltávolítás külön, explicit `removeFillers = true` paraméterrel kérhető.
- A feliratvégi hallucinációs minták csak önálló sorra illeszkednek; a mondat közepén álló kifejezések nem törlődnek.
- A nagyon alacsony logprob önmagában nem elég ok egy sor törlésére.
- A hosszú csendben álló rövid sor megmarad és ellenőrzendőként jelenik meg a minőségellenőrzésben.
- Az ismétlődő szövegek szűrése 30 másodperces ablakra korlátozott, így a távol egymástól elhangzó, valóban ismételt mondatokat nem dobja el.

#### Szókonfidencia és célzott ellenőrzés (v2.28.6)
- A Whisper meglévő tokenenkénti szöveg-, valószínűség- és időadatából szó-szintű, konzervatív jelzés készül.
- Az SRT-szerkesztő a gyenge tokenekhez tartozó forrásszavakat narancssárga aláhúzással mutatja; a sor lejátszásával a megfelelő hangszakasz visszahallgatható.
- A szegmens átlagos logprobja külön marad a szókonfidenciától.
- A no-speech becslés csak figyelmeztet, nem töröl automatikusan.
- Az ellenőrzőpont új formátuma menti a pontszámokat is, de a korábbi, ötoszlopos checkpointok továbbra is betölthetők.

#### Minőségjelzés és mérés
- `QualityRules` közös küszöböket biztosít a minőségjelzéshez és a hallucináció-ellenőrzéshez.
- A fájlfelismerés a meglévő egyéni szótár kanonikus alakjait is átadja a rövid, nyelvhelyes Whisper-promptnak; a hibás bemeneti alakokat nem erősíti meg.
- `WordErrorRate` kiszámítja a szubsztitúciók, törlések, beszúrások számát és a WER-t.
- A WER a kis-/nagybetűt és írásjeleket normalizálja, de a magyar ékezeteket nem tünteti el.
- Új tesztek fedik a tartalommegőrzést, az önálló hallucinációs sorokat, a távoli ismétléseket és a WER-t.

#### Meglévő modulok megtartása
- Megmarad a meglévő Compose Material 3 kezdőlap, animált hullámforma, SRT-szerkesztő, fordítási memória, VAD, Whisper-prompt és online/offline fordítás.
- Nem készült párhuzamos felismerőmotor vagy második UI-architektúra.

### Minőségtesztelési javaslat

1. Készíts 20–50 rövid, kézzel ellenőrzött referenciát különböző hangminőségekkel.
2. Futtasd ugyanazokat a fájlokat a korábbi és az új verzión.
3. Hasonlítsd össze a WER-t és kézzel ellenőrizd a számok, nevek, tagadások, rövid mondatok és mondathatárok hibáit.
4. Külön mérd a feldolgozási időt; az automatikus második felismerési körök számát ne növeld általánosan.
5. Ne tekintsd a WER-t fordításminőségi mutatónak: az csak a referenciához viszonyított felismerési hibát méri.

### Build-ellenőrzés

A `:core` Kotlin-forrásai a kiadás előkészítésekor lefordultak `kotlinc` segítségével. A smoke teszt ellenőrizte, hogy a „hát” és „izé” megmarad, az önálló „Subtitles by …” sor eltávolítható, a valódi mondatban szereplő „thanks for watching” megmarad, az alacsony logprobú sor pedig nem törlődik.

A teljes Android APK-fordítás és a JUnit tesztcsomag futtatása ebben a környezetben nem történt meg. Az eredeti ZIP-ben hiányzik a `gradle/wrapper/gradle-wrapper.jar`, és nincs telepített Android SDK. Android Studio vagy megfelelő SDK-val rendelkező gép esetén futtasd:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug :wear:assembleDebug
```

Ha a wrapper JAR hiányzik, előbb állítsd helyre a projekt Gradle Wrapperét, majd futtasd a parancsokat.


---

<!-- forrás: RELEASE_CHECKLIST_6.0_RC_HU.md -->

## [RELEASE_CHECKLIST_6.0_RC_HU.md]

## Platinum Intelligence 6.0 – RC / stable kiadási checklist

Használd minden release-jelölt előtt. Minden sor: ☐ todo / ☑ kész / ✖ nem alkalmazható.

### A. Forrás és biztonság
- [ ] `python tools/verify_release_security.py` → PASS
- [ ] Nincs új, nem engedélyezett exported komponens a manifestben
- [ ] Nincs API-kulcs / titok a logokban és a forrásban
- [ ] `SecretStore` és `SmartTranslationMemoryStore` regresszió: hiba esetén nincs plaintext, memória blob nem törlődik
- [ ] Release keystore: mind a 4 érték megvan, vagy tudatos unsigned (részleges konfig = hiba)

### B. Automatizált tesztek
- [ ] `./gradlew :core:test`
- [ ] `./gradlew :app:testDebugUnitTest` (TranslationIntelligence, MeetingWorkflow, AccessibilityKit, Sync, Capture, PremiumTranslationCard)
- [ ] `./gradlew :app:assembleDebug`
- [ ] `./gradlew :wear:assembleDebug`
- [ ] (opcionális) `./gradlew :app:assembleRelease` saját kulccsal

### C. Offline funkciók (repülőgép-mód)
- [ ] Élő fordítás / felismerés offline modellel
- [ ] Szókincstár mentés + ismétlés (Phrasebook)
- [ ] ReviewCoach kártyák
- [ ] SRT szerkesztő + ReviewSheet jelzések
- [ ] Meeting összefoglaló minőségpontszámmal
- [ ] Helyi backup / visszaállítás

### D. Adatvédelem
- [ ] Online motor csak explicit opt-in után
- [ ] Sync UI **nem** kínál éles felhőszinkront (NoOp)
- [ ] Kamera/OCR **nem** jelenik meg READY-ként (CaptureRegistry UNAVAILABLE)
- [ ] Exportált fájlok FileProvideren keresztül, visszavonható grant

### E. UI / accessibility
- [ ] Világos / sötét / OLED
- [ ] Nagy betűméret (rendszer skála ≥ 1.3)
- [ ] reduceMotion bekapcsolva: nincs zavaró hurokanimáció
- [ ] TalkBack: fő képernyők címkéi és gombok
- [ ] Diagnosztika → akadálymentesség checklist olvasható

### F. Eszközmátrix (minimum)
- [ ] 1× Android 10/11
- [ ] 1× Android 14/15
- [ ] (ha van) Wear OS debug APK telepítés

### G. Dokumentáció a kiadáshoz
- [ ] `CHANGELOG` / release notes frissítve
- [ ] `BUILD_STATUS` tényleges Gradle eredménnyel
- [ ] `VALIDATION_REPORT` eszközteszt sorokkal kiegészítve
- [ ] APK SHA-256 és aláírási ujjlenyomat rögzítve

### H. Döntés
- [ ] **RC**: A–G kötelező tételek zöldek, ismert korlátok dokumentálva
- [ ] **Stable**: RC + legalább 48 óra smoke / visszajelzés, nincs kritikus regresszió
- [ ] **Nem release**: bármely A/B/C/D blokkoló hiányzik


---

<!-- forrás: RELEASE_NOTES_4.2.3_HU.md -->

## [RELEASE_NOTES_4.2.3_HU.md]

## Kiadási megjegyzések – 4.2.3

Ez a csomag a 4.2.2 forráscsomag biztonsági ellenőrzéseit pontosítja. A cél a release-aláírási regressziók, a manifestben véletlenül publikált komponensek, a backup-beállítás és a fájlmegosztó hozzáférési határainak CI-ben történő korai észlelése.

**Kiadási minősítés:** előzetes forráscsomag. A Gradle build, az automatikus tesztek, az APK-aláírás és a fizikai készülékes validáció még szükséges.


---

<!-- forrás: SECURE_BACKUP_DIAMOND_V2.61.0_HU.md -->

## [SECURE_BACKUP_DIAMOND_V2.61.0_HU.md]

## Platinum Infinity – Secure Backup Diamond v2.61.0

### Elkészült ebben a fejlesztési hullámban

- AES-256-GCM hitelesített titkosítás a hordozható tanulási mentéshez.
- PBKDF2-HMAC-SHA256 kulcsszármaztatás egyedi, véletlen salt-tal.
- Egyedi véletlen IV minden mentéshez; a GCM hitelesítési címke védi a tartalmat a módosítástól.
- Minimum 8 karakteres exportjelszó; a jelszó nem kerül a mentésfájlba.
- Hibás jelszó és manipulált fájl elutasítása.
- Visszaállítás előtti előnézet a mentés dátumával és a szótár-, fordítási, illetve ismétlési rekordszámokkal.
- A visszaállítás csak a jelszóval sikeresen feloldott és a meglévő verziózott formátum-ellenőrzésen átment adatokkal indul.
- Tranzakciós adatcsere Room-adatbázison.

### Biztonsági megjegyzések

- A titkosítási jelszó elvesztése esetén a mentés nem fejthető vissza.
- A jelszót nem tároljuk automatikusan az alkalmazásban.
- A meglévő, korábbi JSON mentési formátum nem kerül automatikusan titkosítottnak tekintésre; az új Diamond export `.pibackup` fájlt készít.

### Ellenőrzés

Új unit tesztek: titkosítási körbejárás, hibás jelszó, módosított payload, minimális jelszóhossz. A Gradle tesztfuttatás ebben a környezetben nem indult el, mert a Gradle 8.9 disztribúció letöltéséhez nincs hálózati hozzáférés (`UnknownHostException: services.gradle.org`). A build ezért nem minősíthető sikeresnek.

### Következő lépések

1. Napi/heti automatikus mentés WorkManagerrel és Android Keystore által védett automatikus kulcskezeléssel.
2. Visszaállítási előnézet bővítése duplikáció- és verzióütközés-jelzéssel.
3. Learning Analytics Diamond és egységes Global Dashboard.
4. AI Conversation Master és hibrid offline/online fordítási útvonal.
5. Teljes regressziós és teljesítménytesztek.


---

<!-- forrás: SECURITY_HARDENING_4.2.1_HU.md -->

## [SECURITY_HARDENING_4.2.1_HU.md]

## Biztonsági hardening – 4.2.1

### Javítások

#### 1. Release aláírási határ

Korábban saját release kulcs hiányában a build a debug kulcsot használta release APK aláírásához. Ez kiadási és kulcskezelési szempontból hibás gyakorlat.

Most:
- Saját release keystore csak `keystore.properties` vagy a négy `KEYSTORE_*` környezeti változó megadásával használható.
- Részleges konfiguráció esetén a Gradle hibával leáll.
- Ha nincs release kulcs, a release APK unsigned marad.
- A debug aláírás továbbra is a külön, csak tesztelési célú `app/debug.keystore` kulcsot használja; ez nem release kulcs.

#### 2. API-kulcsok titkosítása

Korábban az Android Keystore hibája esetén a `SecretStore` visszaesett egyszerű szöveges SharedPreferences tárolásra.

Most:
- AES/GCM/NoPadding, 256 bites Android Keystore kulcs.
- Titkosítási hiba esetén a titok nem kerül plaintextként eltárolásra.
- A régi plaintext érték csak sikeres titkosított migráció után marad meg; sikertelen migráció esetén a régi plaintext bejegyzés eltávolításra kerül.
- Sérült titkosított érték esetén a rendszer üres értéket ad vissza, nem próbálja csendben a plaintextet használni.
- A beállító felület jelzi, ha a biztonságos mentés nem sikerült.

Megjegyzés: ha az Android Keystore hibás vagy a kulcs elveszett, az API-kulcs újbóli megadása szükséges lehet.

#### 3. Egyedi online végpontok

- Távoli egyedi végpontoknál HTTPS kötelező.
- HTTP csak localhost, loopback vagy RFC1918 privát IPv4 címen engedélyezett (például helyi Ollama szerver).
- A végpont ellenőrzése nem végez DNS-feloldást; hibás vagy nem biztonságos URL esetén az online konfiguráció nem készül el.

#### 4. UI és téma

- Forest Graphite prémium paletta került be.
- A Compose prémium színséma a `darkTheme` értéket figyelembe veszi; a prémium téma nem kényszeríti mindig sötét módra a felületet.

### Kiadás előtt kötelező

- Saját release kulcs létrehozása és biztonságos, offline mentése.
- `keystore.properties` kizárása a Gitből.
- Aláírt release build és tanúsítvány-ujjlenyomat rögzítése.
- API-kulcs migráció tesztelése frissítésből.
- Mentés-visszaállítás tesztelése.
- Android 10+ fizikai eszközteszt.

### Nem állítjuk

Ez a hardening nem helyettesíti a teljes penetrációs tesztet, a hálózati forgalom auditját vagy a felhőszinkron végpontok közötti titkosítását. A felhőszinkron a szolgáltató és backend kiválasztásáig nincs aktiválva.


---

<!-- forrás: SILVER_GOLD_ULTIMATE_UPDATE_HU.md -->

## [SILVER_GOLD_ULTIMATE_UPDATE_HU.md]

## Silver & Gold Ultimate Edition – 2.32.0 fejlesztési csomag

### Ebben a csomagban
- Silver & Gold prémium kiemelőszín és világos/sötét paletta.
- Új `SubtitlePostProcessor` a végső átirat-utófeldolgozáshoz.
- A felhasználó által megadott angol/magyar javítólisták és szótár biztonságos alkalmazása.
- Opcionális töltelékszó-szűrés és írásjel-normalizálás.
- Ellenőrzési jelzések bizonytalan (`[unclear]`, `[inaudible]`, `TODO`, `FIXME`) részekhez.
- Egységtesztek az üres bemenet, javítás, szótár, jelölések és írásjelek kezelésére.

### Fontos viselkedési garanciák
- A javítások determinisztikusak; nincs külső szolgáltatás-hívás.
- A töltelékszavak törlése alapértelmezésben ki van kapcsolva.
- A bizonytalan részek nem kerülnek automatikusan kitalált szöveggel helyettesítésre.
- A `reviewRecommended` heurisztikus ellenőrzési javaslat, nem garantált pontossági pontszám.

### Ellenőrzés
A forráscsomag egységteszteket tartalmaz, de ebben a környezetben az Android/Gradle build nem futott le. A teljes alkalmazás telepíthetőségét és a készülékes működést még ellenőrizni kell.


---

<!-- forrás: SOURCE_AUDIT_4.2.6_HU.md -->

## [SOURCE_AUDIT_4.2.6_HU.md]

## Forrásaudit – feltöltött AngolMagyar 4.2.6 ZIP

### Ellenőrzött tények

- A ZIP CRC olvasása és kicsomagolása sikeres.
- 565 fájl szerepel az archívumban.
- A belső gyökérmappa neve 4.2.5, miközben az Android Gradle konfiguráció 4.2.6 / 40406 verziót állít.
- A README 4.2.3 / 40403 forrásverziót említ, tehát több, egymásnak ellentmondó verzióállítás volt.
- A projekt három Gradle modult tartalmaz: app, core és wear.
- A csomagban vannak core és app unit tesztforrások, valamint statikus release/security ellenőrző script.
- A `VALIDATION_REPORT_4.2.6_HU.md` maga is rögzíti, hogy Gradle/Kotlin build és eszközteszt korábban sem volt igazolva.
- A Smart Translation Memory adapter Android Keystore AES-GCM tárolást használ. A korábbi `readEntries()` catch ág eltávolította a titkosított preferences blobot, majd üres listát adott vissza. Ez a későbbi írásoknak adatvesztési kockázatot jelentett.
- A `tools/verify_release_security.py` ellenőrzi a release/debug signing szétválasztást, SecretStore AES-GCM használatot, endpoint policy-t, backup tiltást, exported komponens allowlistet, FileProvider határt és CI bekötést.

### Javítás

A `SmartTranslationMemoryStore.readEntries()` most `null`-t ad vissza visszafejtési/parszolási hibánál, a titkosított blobot megőrzi, és minden módosító művelet megszakad. A `entries()` olvasó API üres listát ad a megjelenítéshez, de nem törli a blobot; a `lookup()` nem ad találatot hiba esetén.

### Környezeti korlát

A futtatókörnyezetben JDK 21 elérhető, de `gradle` parancs nincs telepítve. A `./gradlew --offline :core:test` megkísérlésekor a wrapper a Gradle 8.9 disztribúció letöltését próbálta, majd `UnknownHostException: services.gradle.org` hibával leállt; a helyi cache hiányzik. Az Android SDK/NDK elérhetősége nem igazolt. Emiatt a teljes Gradle build és Kotlin tesztfuttatás nem volt lehetséges. `python3 tools/verify_release_security.py` sikeres; `python3 -m compileall -q tools` sikeres; a 38 XML fájl parse-olása sikeres; az Android verzió/SDK invariánsok ellenőrzése sikeres; a módosított Kotlin memóriaadapter és a core memóriaosztály ideiglenes API-stubokkal végzett szintaxis/típusellenőrzése sikeres (ez nem teljes Android build). A statikus ellenőrzés nem helyettesíti a Kotlin buildet vagy a készüléktesztet.

### Következtetés

A forráscsomag egy részleges, de érdemi biztonsági és verziókonzisztencia-javítást kapott. A teljes 6.0 funkciólista még terv, nem implementált állapot.


---

<!-- forrás: ULTIMATE_2.33.0_HU.md -->

## [ULTIMATE_2.33.0_HU.md]

## AngolMagyar Silver & Gold Ultimate Edition 2.33.0

### Újdonságok
- Új **Platina Gyémánt** kiemelőtéma: platina tónusok kristályos cián és indigó fényekkel.
- `TranslationQualityAudit`: külön, nem romboló EN→HU fordítási ellenőrző a hiányzó fordítás, számeltérés, tulajdonnév/tagadás gyanúja és szélsőséges szöveghossz jelzésére.
- Egységtesztek az ellenőrző fő eseteire.
- Verzió: 2.33.0 (versionCode 3300).

### Pontossági megjegyzés
Az ellenőrző figyelmeztetéseket ad, nem bizonyítja a fordítás helyességét és nem generál „pontossági százalékot”. A természetes nyelvi fordítás minőségéhez továbbra is szükség lehet a forrás és a célszöveg emberi ellenőrzésére. A meglévő fordítómotor viselkedését ez a modul nem módosítja automatikusan.

### Ellenőrzés
A projekt forrása és az új egységtesztek bekerültek a csomagba. Android/Gradle buildet ebben a környezetben nem igazoltunk; a kiadás előtt futtasd az `./gradlew :core:test` és az `./gradlew assembleDebug` parancsokat Android SDK-val és elérhető Gradle-függőségekkel.


---

<!-- forrás: ULTIMATE_2.34.0_HU.md -->

## [ULTIMATE_2.34.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.34.0

### Újdonságok
- A mentett átiratok részletező nézetében soronként megjelenik az ellenőrzési jelzés, ha a heurisztikus EN→HU audit szám-, tulajdonnév-, tagadás- vagy szokatlan hosszeltérést talál.
- A jelzés nem írja át a fordítást, és nem jelent bizonyított hibát; emberi ellenőrzést javasol.
- Verzió: `versionCode 3400`, `versionName 2.34.0`.

### Korlátok és ellenőrzés
Az audit szabályalapú heurisztika, nem teljes nyelvi minőségértékelő, ezért hamis pozitív és hamis negatív jelzések előfordulhatnak. Android buildet és eszközön futtatást ebben a környezetben nem sikerült hitelesen lefuttatni; a csomagolás és forrásellenőrzés nem helyettesíti a buildet.


---

<!-- forrás: ULTIMATE_2.35.0_HU.md -->

## [ULTIMATE_2.35.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.35.0

### Újdonságok
- Az átirat részletező képernyőjének fejlécében megjelenik a heurisztikus audit összesítése: hány sor igényelhet ellenőrzést.
- Ha a nem üres forrás/fordítás sorok között nincs figyelmeztetés, az alkalmazás „Alapellenőrzés kész” állapotot jelez. Ez nem minőségi garancia és nem jelent bizonyított fordítási pontosságot.
- A soronkénti jelzések változatlanul megmaradnak; a rendszer nem írja át automatikusan a fordítást.
- Verzió: `versionCode 3500`, `versionName 2.35.0`.

### Korlátok és ellenőrzés
Az audit szabályalapú heurisztika, ezért hamis pozitív és hamis negatív jelzések előfordulhatnak. Android buildet és eszközön futtatást ebben a környezetben nem sikerült hitelesen lefuttatni; a ZIP ellenőrzése nem helyettesíti a buildet.


---

<!-- forrás: ULTIMATE_2.36.0_HU.md -->

## [ULTIMATE_2.36.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.36.0

### Főbb változások

- Új, kezdőképernyőről elérhető **Fordítási vezérlőpult**: élő fordítási célnyelv-választás és fordítási mód (offline, online, online + offline tartalék).
- Az online mód beállítás hiányában az online szolgáltatás beállító párbeszédablakát nyitja meg; az online fordítás továbbra is a meglévő adatküldési hozzájáruláshoz kötött.
- Az elérhető célnyelvek között nem ajánlja fel a jelenleg beállított forrásnyelvet, és jelzi a forrásnyelvet.
- Új **Akkukímélő animációk** kapcsoló a megjelenés panelen. Bekapcsolva megszünteti a folyamatos aurora-háttérmozgást, a hero-kártya fénycsíkját és az állapotkártyák lebegő animációját.
- Android rendszer akkukímélő módjában ugyanezek a folyamatos dekorációs animációk automatikusan visszafogottak.
- A korábbi Silver & Gold / Platina / Gyémánt témák, az animált lépcsőzetes belépés és a háttérben futó feladatok kezelése megmarad.

### Fordítási és akkumulátor-korlátok

- Az offline fordítás csak akkor érhető el teljes értékűen, ha a szükséges nyelvi modell telepítve van; az első modellletöltéshez internet kell.
- Az online fordítás API-szolgáltatót és felhasználói hozzájárulást igényel. A felismert szöveg elhagyhatja a készüléket; a hangadatok kezelését a kiválasztott felismerési útvonal külön szabályozza.
- Az akkukímélő kapcsoló a felület folyamatos dekorációs animációit csökkenti. Nem kapcsolja le a felhasználó által elindított felvételt vagy fordítási feladatot.
- A Kotlin/Android buildet nem lehetett ellenőrizni, mert a Gradle disztribúció letöltése hálózati DNS-hiba miatt meghiúsult. Eszközön végzett futtatási teszt még szükséges.


---

<!-- forrás: ULTIMATE_2.37.0_HU.md -->

## [ULTIMATE_2.37.0_HU.md]

## AngolMagyar Silver & Gold Ultimate 2.37.0

### CI és közös Compose design rendszer

- GitHub Actions minden push és pull request esetén futtatja a `:core:test`, `:app:testDebugUnitTest` és `:app:assembleDebug` feladatokat.
- Az APK és a tesztjelentések egyetlen letölthető artifactba kerülnek.
- Roborazzi-alapú Compose képernyőkép-smoke-teszt rendereli és rögzíti a prémium komponens képét. A vizuális baseline-összehasonlítást a sikeres első CI-futás után a referenciafájl felülvizsgálatával és verziókezelésbe vételével kell véglegesíteni.
- Új `ui.design` csomag: `PremiumSpacing`, `PremiumMotion`, `LocalSpacing`, `LocalMotion`, `PremiumCard`, `StatusPill`, `PrimaryAction`.
- Verzió: 2.37.0 (`versionCode 3700`).

### Ellenőrzési státusz

A forrás és a workflow frissült. A teljes buildet csak sikeres GitHub Actions-futás és az ott létrejött APK-artifact igazolja; ezt a jelenlegi munkakörnyezetből nem lehet előre bizonyítottnak állítani.


---

<!-- forrás: ULTIMATE_2.38.0_HU.md -->

## [ULTIMATE_2.38.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.38.0

### Premium Design System 2.0

- Központosított vizuális tokenek (`PremiumTokens.kt`): Platinum, Champagne Gold, Graphite és Pearl paletta, valamint közös kártya-/gomb-/pill-geometria.
- A `PremiumCard` most egységes, visszafogott kontúrt, adaptív Material 3 felületszínt és finom mélységet használ.
- Új `PremiumSectionTitle` komponens a következetes, olvasható szekciócímekhez.
- A kezdőképernyő fordítási vezérlőpultja az új prémium kártyát és szekciócímet használja.
- Verzió: `versionCode = 3800`, `versionName = 2.38.0`.

### Ellenőrzés és korlátok

A forráscsomag statikus ellenőrzése és ZIP-integritásvizsgálata elvégezhető ebben a környezetben. A teljes Gradle buildet és teszteket csak olyan környezetben lehet hitelesen igazolni, amely hozzáfér a Gradle-disztribúcióhoz és a függőségekhez. Az előző környezetben a `services.gradle.org` DNS-feloldása sikertelen volt, ezért itt nem állítjuk, hogy a build sikeres.

Javasolt CI-ellenőrzés:

```bash
./gradlew :core:test --stacktrace
./gradlew :app:testDebugUnitTest --stacktrace
./gradlew :app:assembleDebug --stacktrace
```


---

<!-- forrás: ULTIMATE_2.39.0_HU.md -->

## [ULTIMATE_2.39.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.39.0

### Luxury Home és akadálymentesebb mikrointerakciók

- Verzió: `2.39.0` (`versionCode = 3900`).
- A kezdőlap gyorsműveletei külön címet és rövid magyarázatot kaptak, így világosabb a képernyő hierarchiája.
- A fő állapotjelzés udvarias akadálymentességi élő régióként is közli a feldolgozás, készenlét vagy hiba állapotát.
- A kártyák nyomási animációja figyelembe veszi az alkalmazás mozgáscsökkentési beállítását és az energiatakarékos módot.
- Új JVM-egységtesztek ellenőrzik a központi prémium geometriai, térköz- és animációs tokeneket.

### Ellenőrzés

A forráscsomag statikusan ellenőrizhető. A teljes Gradle build és tesztfuttatás csak olyan környezetben tekinthető igazoltnak, ahol a Gradle disztribúció és az Android függőségek elérhetők. Ezt a kiadást nem jelöljük sikeresen lefordítottnak, amíg a CI nem futott végig sikeresen.


---

<!-- forrás: ULTIMATE_2.40.0_HU.md -->

## [ULTIMATE_2.40.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.40.0

### Fő változások

- Az élő fordítás kártyájáról külön másolható az angol felismert szöveg és a magyar fordítás.
- A magyar felirat képernyőolvasó-barát, udvarias élő régiót kapott, így a frissülő eredmény akadálymentesebben követhető.
- A kezdőképernyő inaktív állapotában a hanghullám amplitúdófrissítése 70 ms helyett 300 ms-onként történik, csökkentve a szükségtelen állapotfrissítéseket.
- Verzió: 2.40.0 (versionCode 4000).

### Ellenőrzés

A forrás és a csomag statikus ellenőrzése elvégezhető ebben a környezetben. A Gradle buildet és a teszteket nem jelöljük sikeresnek addig, amíg a Gradle-disztribúció és a függőségek letöltésével a build ténylegesen le nem fut.


---

<!-- forrás: ULTIMATE_2.41.0_HU.md -->

## [ULTIMATE_2.41.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.41.0

### Fő fejlesztés: Premium Translation Experience

- Új, újrafelhasználható `PremiumTranslationCard` Compose-komponens az eredeti és a lefordított szöveg egységes megjelenítéséhez.
- A másolási és felolvasási műveleteket a hívó képernyő adja át callbackeken keresztül; a komponens nem tart meg Activity-referenciát és nem kötődik Android-szolgáltatáshoz.
- Üres szövegnél informatív helyőrző látható, és a megfelelő műveleti gombok letiltódnak.
- Képernyőolvasó számára leíró szöveg és konzisztens vizuális hierarchia.
- Új Robolectric Compose tesztek a szövegek megjelenítésére és a műveleti gombok engedélyezésére.

### Verzió

- `versionName`: `2.41.0`
- `versionCode`: `4100`

### Ellenőrzés

A forráscsomag és a statikus fájlellenőrzések elvégezhetők helyben. A Gradle buildet és a teszteket csak olyan környezetben lehet sikeresnek nyilvánítani, ahol a szükséges Gradle-disztribúciók és függőségek elérhetők; ezek sikeres futása ebben a környezetben nincs igazolva.


---

<!-- forrás: ULTIMATE_2.42.0_HU.md -->

## [ULTIMATE_2.42.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.42.0

### Fő változások

- A `PremiumTranslationCard` most már az élő fordítás kezdőképernyői állapotkártyájába is integrálva van.
- Az angol forrásszöveg és a magyar fordítás egyetlen, egységes komponensben jelenik meg.
- A forrás és a fordítás külön másolható a vágólapra.
- A magyar fordítás udvarias élő régióként jelzi a frissülést a képernyőolvasóknak.
- Verzió: `2.42.0`, verziókód: `4200`.

### Ellenőrzés

A ZIP-archívum és a statikus forrásmódosítások ellenőrizhetők. A Gradle buildet és a teszteket ebben a környezetben nem sikerült lefuttatni, ezért azok sikeressége nincs igazolva. A build ellenőrzéséhez olyan környezet szükséges, amely eléri a Gradle disztribúciót és a projekt függőségeit.


---

<!-- forrás: ULTIMATE_2.43.0_HU.md -->

## [ULTIMATE_2.43.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.43.0

### Cél

A korábbi prémium Compose-felületet tényleges, használható nyelvi funkciókkal bővíti: online LLM-fordítási stílusokkal, helyi mentett kifejezésekkel, a fordítás felolvasásával és célzott tesztekkel.

### Ebben a csomagban megvalósított módosítások

#### 1. Online fordítási stílusok
- Új `TranslationStyle` modell: Természetes, Pontos, Hivatalos, Közvetlen.
- A kiválasztás a meglévő privát beállításokban tárolódik.
- Az `OnlineTranslator` rendszerutasítása tartalmazza a kiválasztott stílus instrukcióját.
- A vezérlőpult csak a támogatott Anthropic/OpenAI-kompatibilis online LLM-fordítóknál mutatja a stílusválasztót. A DeepL és az offline ML Kit működését nem állítja át.

#### 2. Helyi saját szókincstár
- Új `PhrasebookStore` és `SavedPhrase` adatmodell.
- A felhasználó kifejezett Mentés művelete rögzíti a forrás és fordítás párosát.
- Helyi SharedPreferences-tárolás; a szókincstár nem küld adatot hálózatra és nem naplózza a mentett szövegeket.
- Ismétlődő párok deduplikálása, keresés, másolás, egyedi törlés és megerősítést kérő teljes törlés.
- Legfeljebb 2000 elem tárolható.
- Új `PhrasebookActivity`, elérhető a kezdőképernyő gyorsműveleteiből.

#### 3. Felolvasás és hozzáférhetőség
- Az élő fordítási kártya felolvasás művelete Android TextToSpeech szolgáltatást használ magyar nyelvi beállítással.
- A szolgáltatás Compose-életciklus végén leáll és felszabadul.
- Hiányzó magyar beszédhang esetén a felület tájékoztatja a felhasználót.
- A kártya műveleti sora kis képernyőn vízszintesen görgethető.

#### 4. Tesztek
- Core: a fordítási stílus biztonságos alapértéke és a rendszerutasításba kerülő stílusinstrukció.
- App: szókincstár mentés, deduplikálás, törlés és üres bemenet elutasítása.
- Compose: a Mentés gomb megjelenése és engedélyezett állapota.
- A core modul JUnit-függősége explicit módon rögzítve.

#### 5. Build/CI
A meglévő CI feladat továbbra is futtatni próbálja a `:core:test`, `:app:testDebugUnitTest` és `:app:assembleDebug` feladatokat, és feltölti az APK-t, a tesztjelentéseket és a screenshot kimeneteket.

### Ismert korlátok és következő feladatok

- **A build és a tesztek ebben a környezetben nem igazoltak.** A Gradle Wrapper nem tudta letölteni a Gradle 8.9 disztribúciót, mert a `services.gradle.org` névfeloldása hálózati hibával leállt. Ez nem sikeres build.
- A helyi szókincstár nem szinkronizál eszközök között, és jelenleg nem tartalmaz időzített ismétléses tanulóalgoritmust.
- A stílusválasztó az online LLM-fordítási útvonalat befolyásolja; az offline ML Kit fordítás minőségét vagy hangnemét nem módosítja.
- A kontextusmagyarázat, a brit/amerikai kiejtésválasztás, a kiejtés pontozása, az automatikus szókártyagenerálás és a teljes képernyőkön átívelő Compose-migráció további fejlesztést igényel; ezeket nem jelöljük elkészültnek.
- A Roborazzi teszt jelenleg képernyőkép-kimenetet ellenőrző/smoke jellegű teszt. Referencia-képek rögzítése és pixel-eltéréses regressziókapu külön feladat.

### Ellenőrzési parancsok

```bash
./gradlew :core:test --stacktrace
./gradlew :app:testDebugUnitTest --stacktrace
./gradlew :app:assembleDebug --stacktrace
```

A csomag akkor tekinthető kiadásra igazoltnak, ha ezek a parancsok sikeresen lefutnak, az APK települ, és a mikrofonos felolvasási/mentési munkafolyamatot tényleges Android-eszközön is ellenőrizték.


---

<!-- forrás: ULTIMATE_2.44.0_HU.md -->

## [ULTIMATE_2.44.0_HU.md]

## AngolMagyar – Silver & Gold Ultimate 2.44.0

### Újdonság: időzített szókincsismétlés

A saját szókincstár mostantól egyszerű, helyi ismétlési ütemezést is támogat:

- **Gyakorlás** nézetben a rendszer csak az esedékes kifejezéseket mutatja.
- Először a forráskifejezés látszik; a fordítást külön gombbal lehet felfedni.
- A **Tudtam** válasz fokozatosan hosszabb időközt állít be: 1, 3, 7, 14 nap, majd legfeljebb 365 nap.
- A **Nem tudtam** válasz másnapra ütemezi újra a kifejezést.
- A szókincstár megőrzi a korábbi mentéseket; az új ismétlési mezők hiányzó értékei alapértéket kapnak.
- A mentett szavak és az ismétlési adatok továbbra is kizárólag a készüléken tárolódnak.

### Korábbi funkciók

A 2.43.0-ban bevezetett fordítási stílusok, kézi szókincstárba mentés, másolás és felolvasás megmaradtak.

### Ellenőrzési státusz

A forráscsomag és a módosított fájlok statikusan ellenőrizhetők. A teljes Gradle buildet és az Android APK-t ebben a környezetben nem lehet igazolni, amíg a Gradle disztribúció letöltése hálózati/DNS-hiba miatt meghiúsul. Ezért ez a csomag nem állítja, hogy a teljes alkalmazás sikeresen lefordult vagy eszközön tesztelve lett.


---

<!-- forrás: ULTIMATE_ECOSYSTEM_4.0_HU.md -->

## [ULTIMATE_ECOSYSTEM_4.0_HU.md]

## Platinum Infinity Diamond 4.0 – használati útmutató

Az új képernyő a Platinum Intelligence Suite „Ultimate Ecosystem 4.0” szekciójából nyitható meg.

### Modulok
1. Diamond Intelligence Core – helyi CEFR önértékelési csúszka és profilmentés.
2. Platinum Language Mastery – tanulási fókusz és kompetenciafejlesztési útmutató.
3. Infinity Speech Intelligence – Android beszédfelismerő indítása angol nyelvre állítva.
4. Diamond Document Intelligence – szöveg/PDF fájl kiválasztása, szöveges előnézet, szó- és olvasásiidő-becslés.
5. Platinum Memory Universe – egy saját angol kifejezés helyi tárolása.
6. Infinity Scenario Simulator – étterem, állásinterjú, utazás, üzleti tárgyalás és telefonos helyzetek.
7. Platinum Privacy & Security – a modul helyi adatainak törlése és tárolási tájékoztató.
8. Diamond Performance Engine – JVM memóriahasználat pillanatfelvétele.
9. Platinum Global Experience – a meglévő alkalmazástéma és prémium Compose-komponensek használata.
10. Infinity Achievement Universe – teljesített gyakorlások számlálója és mérföldkövei.

### Fontos korlátozások
A CEFR érték önértékelés. A Speech Recognizer külső Android szolgáltatástól függ. A PDF-ből kinyerhető szöveg eszközfüggő; OCR nincs. A dokumentum legfeljebb 12 000 karakteres előnézetet mutat. A képernyő nem állítja, hogy felhő-AI, fonémaszintű kiejtésmérés, biometrikus zár vagy felhőszinkron rendelkezésre áll.


---

<!-- forrás: UPDATE10_HU.md -->

## [UPDATE10_HU.md]

## AngolMagyar v2.30.0 Gyémánt Edition – Update 10

### Hibajegyzék és célzott navigáció

- Az export előtti minőségellenőrzés teljes listában mutatja az összes talált jelzést.
- Bármelyik jelzés kiválasztásával a megfelelő feliratsorhoz lehet ugrani.
- Ha egy aktív keresés elrejti a célzott sort, a keresési szűrő törlődik, így a sor elérhetővé válik.
- A funkció navigációs segítség: nem írja át automatikusan a feliratot vagy az időbélyegeket.

### Ellenőrzési státusz

A ZIP-archívum szerkezeti épsége ellenőrizendő csomagolás után. Android build és készülékes UI-teszt nem történt, ezért a fordíthatóság és futásidejű működés nincs igazolva.


---

<!-- forrás: UPDATE11_HU.md -->

## [UPDATE11_HU.md]

## AngolMagyar – Gyémánt Edition Update 11

### Ebben a csomagban ténylegesen módosult

- Új `GlossaryGovernance` platformfüggetlen Kotlin-modul: terminus-bejegyzések validálása, globális/projekt-hatókör, jóváhagyási állapot, ütközéskeresés, jóváhagyott terminus feloldása, pontos kifejezésalapú hatás-előnézet, TSV import/export és visszavonható archiválást támogató állapotváltás.
- Új `GlossaryGovernanceTest` tesztek: projekt-szótár prioritása, ütközésvizsgálat, hatás-előnézet, TSV körút és hiányzó projektazonosító.
- Új Platina kiemelőszín-téma a meglévő témarendszerben.
- Új részletes magyar fejlesztési és integrációs terv a prémium felülethez, minőségbiztosításhoz, újrafeldolgozáshoz, feliratstúdióhoz és adatvédelemhez.

### Fontos korlátok

A szótárgovernance modul most külön, platformfüggetlen API. Még nincs bekötve az Android felületbe, a meglévő `Prefs`-tárolóba vagy a fordítási pipeline-ba; ezért ebben a kiadásban nem állítható, hogy a teljes automatikus újrafordítási munkafolyamat kész. A modul szándékosan nem ír át szöveget: előnézetet ad, és a tényleges módosításhoz explicit alkalmazás szükséges.

A teljes Android Gradle-build, az alkalmazás- és Wear APK, a JUnit-csomag és a készülékes UI-teszt ebben a környezetben nincs igazolva. A `GlossaryGovernance.kt` önálló Kotlin-fordítása sikeres.


---

<!-- forrás: UPDATE12_HU.md -->

## [UPDATE12_HU.md]

## Angol–Magyar Gyémánt Edition – Update 12 Premium Integration

### Ebben a frissítésben ténylegesen elkészült

- A `GlossaryStore` Androidos tárolóadapter összeköti a `GlossaryGovernance` modult a meglévő `SharedPreferences`-beállításokkal.
- A régi személyes szótár első megnyitáskor átvehető a felügyelt szótárba; a már használt `source=target` formátum továbbra is kompatibilis.
- A Beállítások → Haladó → Javítólisták és szótár részhez bekerült a **Gyémánt szótárközpont**.
- A szótárközpontban a globális, jóváhagyott terminusok szerkeszthetők, menthetők és aktiválhatók a meglévő fordítási pipeline számára.
- Mentés előtt ellenőrzi az ismétlődő forráskifejezéseket, és nem engedi a mentést duplikált kulcsokkal vagy alapvetően hibás bejegyzésekkel.
- A governance modul támogatja a globális/projekt hatókört, a függő/jóváhagyott/elvetett/archivált állapotot, az ütközéskeresést, a pontos kifejezésalapú hatás-előnézetet és a TSV import/exportot.
- A szótár változásai nem írják át automatikusan a korábbi átiratokat. A felhasználó által jóváhagyott globális szótár a jövőbeli fordításokhoz kerül szinkronizálásra a meglévő `customVocab` mezővel.

### Ellenőrzés

- A `GlossaryGovernance.kt` önálló Kotlin-fordítása sikeres.
- A kézi smoke teszt sikeres: jóváhagyott projektterminus prioritása, ütközésészlelés, hatás-előnézet és TSV körút.
- A teljes Gradle/JUnit és Android APK buildet nem sikerült lefuttatni, mert a környezet nem tudta letölteni a Gradle 8.9 disztribúciót (`services.gradle.org` hálózati elérés hiánya). Ezért az Android UI teljes fordíthatósága és eszközös működése még nincs igazolva.

### Következő fejlesztési feladatok

1. Projektazonosító és projekt-szintű szótár kiválasztása a felületen.
2. Korábbi átiratok hatás-előnézete fájlból/projektből, diff nézettel és kézi jóváhagyással.
3. A terminológia alkalmazása mondatszintű újrafordításkor, a kézzel jóváhagyott fordítások védelmével.
4. Szótár-verzióelőzmény, visszaállítás és import előtti soronkénti hibaösszegzés.
5. Teljes Gradle build, JUnit, Android készülékes UI-teszt és APK ellenőrzés olyan környezetben, ahol a buildfüggőségek elérhetők.


---

<!-- forrás: UPDATE13_HU.md -->

## [UPDATE13_HU.md]

## Angol–Magyar Gyémánt Edition – Update 13

### Elkészült: biztonságos újrafordítási tervmotor

- Új `RetranslationPlanner` platformfüggetlen Kotlin-modul.
- Újrafordítási előnézetet készít, de nem írja át automatikusan a szöveget.
- Alapértelmezetten kihagyja a kézzel jóváhagyott fordításokat.
- Csak a felhasználó által kijelölt szegmensek alkalmazhatók.
- Fordítási revízióval védi a közben módosított szövegeket az elavult előnézet felülírásától.
- Tömör, soronkénti diff-előállítás.
- Öt JUnit-teszt az előnézetre, a kézi szövegek védelmére, a kijelölt alkalmazásra, az elavult revízióra és az üres javaslatokra.

### Integrációs határ

Ez a frissítés elkészíti a biztonságos újrafordítási logika alapját. A meglévő képernyőkkel, a valódi fordítószolgáltatásokkal és a projekt-/fájltárolással való teljes UI-integráció, valamint a teljes Android APK build külön ellenőrzést igényel. A modul önmagában nem hív hálózati fordítót, és nem módosít fájlokat.

### Következő lépések

1. A fordítási pipeline candidate map-et adjon a plannernek.
2. UI diff nézet, jelölőnégyzetes jóváhagyás és „kézi fordítások kihagyása” vezérlő.
3. Tartós fordításverziók és visszaállítás.
4. Teljes Gradle/JUnit futtatás és Android készülékes teszt.


---

<!-- forrás: UPDATE8_HU.md -->

## [UPDATE8_HU.md]

## Gyémánt Edition – Update 8

### Változás
Az export előtti minőségellenőrzés a korábban támogatott SRT és WebVTT mellett most a Markdown, TXT, DOCX és PDF export indítása előtt is lefut.

### Működés
- A feliratokat az export aktuális pillanatképéből ellenőrzi.
- A problémákat jelzi, de nem javítja automatikusan a szöveget vagy az időbélyegeket.
- A felhasználó dönthet a folytatásról vagy a megszakításról a meglévő ellenőrző párbeszédben.

### Ellenőrzés
A módosított forráskód bekerült a projektbe. Ebben a körben a teljes Android Gradle-buildet és az eszközön végzett exporttesztet nem futtattuk, ezért a működés teljes körű igazolása még hátravan.


---

<!-- forrás: VALIDATION_REPORT_4.2.2_HU.md -->

## [VALIDATION_REPORT_4.2.2_HU.md]

## Validációs jegyzőkönyv – 4.2.2

| Ellenőrzés | Eredmény |
|---|---|
| Forrás ZIP CRC ellenőrzés | Sikeres |
| Statikus release/security guardrails | Sikeres |
| XML parse | 38/38 sikeres |
| Gradle/Kotlin build | Nem futott: Gradle 8.9 letöltése DNS-hibán elakadt |
| Android SDK build | Nem futott: SDK nincs telepítve |
| Fizikai eszközteszt | Nem történt |

A sikeres statikus ellenőrzés nem jelent sikeres Android buildet. A GitHub Actions futás és a fizikai eszközteszt a következő kötelező kapu.


---

<!-- forrás: VALIDATION_REPORT_4.2.3_HU.md -->

## [VALIDATION_REPORT_4.2.3_HU.md]

## Ellenőrzési jelentés – 4.2.3

| Ellenőrzés | Eredmény |
|---|---|
| `python tools/verify_release_security.py` | PASS |
| AndroidManifest XML parse | PASS |
| `versionName` / `versionCode` | 4.2.3 / 40403 |
| Gradle core/app tesztek | NEM FUTTATHATÓ – környezeti korlát |
| Debug / release / Wear APK build | NEM IGAZOLT |
| Fizikai Android / Wear OS teszt | NEM VÉGZETT |

A PASS kizárólag a statikus ellenőrző script sikerét jelenti. Nem állítja, hogy az alkalmazás lefordult, telepíthető vagy minden futásidejű támadással szemben védett.


---

<!-- forrás: VALIDATION_REPORT_4.2.4_HU.md -->

## [VALIDATION_REPORT_4.2.4_HU.md]

## 4.2.4 ellenőrzési jelentés

- Forrásmódosítások és tesztforrások hozzáadva.
- Verzió: 4.2.4 / versionCode 40404.
- A Gradle/Kotlin tesztek futtatása ebben a környezetben nem igazolt; Android SDK és elérhető Gradle disztribúció szükséges.
- APK build és fizikai eszközteszt nem történt.
- A tesztek a CI-ban futtathatók a meglévő build workflow részeként.


---

<!-- forrás: VALIDATION_REPORT_4.2.5_HU.md -->

## [VALIDATION_REPORT_4.2.5_HU.md]

## 4.2.5 ellenőrzési jelentés

### Elvégzett forrásellenőrzések
- Smart Translation Memory API és kilenc JUnit teszteset hozzáadva.
- Verziószámok egyezése ellenőrizendő a csomagoláskor.
- ZIP-integritás és statikus biztonsági ellenőrzés futtatva a csomagolás után.

### Nem igazolt
- Gradle/Kotlin fordítás és JUnit futtatás: ebben a környezetben nem tekinthető lefuttatottnak.
- Android UI-integráció, titkosított perzisztencia és migráció: nincs készre jelentve.
- APK, Wear OS build, fizikai készülékes és offline teszt: hátravan.

A core API jelenleg javaslatokat ad; a hívó alkalmazásnak kell a felhasználói jóváhagyást és a biztonságos tárolást biztosítania.


---

<!-- forrás: VALIDATION_REPORT_4.2.6_HU.md -->

## [VALIDATION_REPORT_4.2.6_HU.md]

## 4.2.6 + Platinum Intelligence 6.0 Engineering – ellenőrzési jelentés

### Verzió
- `versionName=4.2.6`, `versionCode=40406`
- applicationId: `hu.angolmagyar.fordito`
- minSdk 29 / targetSdk 35 / compileSdk 35

### Statikus kapuk (ebben a környezetben)

| Ellenőrzés | Eredmény |
|---|---|
| Forrás ZIP / csomag integritás | OK |
| `python tools/verify_release_security.py` | **PASS** |
| `python -m compileall -q tools` | PASS (korábbi futások) |
| Android version/SDK invariánsok | PASS |
| SmartTranslationMemoryStore fail-closed | Forrásban igazolt |
| SecretStore plaintext fallback tiltás | Forrásban igazolt |
| Gradle `:core:test` / `:app:test` | **Nem futott** (nincs offline Gradle cache / SDK) |
| APK assemble | **Nem készült** |
| Fizikai eszköz / offline / mikrofon | **Nem futott** |

### Forrásszinten bekerült 6.0 mérnöki tételek

#### P0–P1
- Verzió- és dokumentumkonzisztencia
- Titkosított memória: dekriptálási hiba → blob megmarad, mutáció megszakad
- API-kulcs: fail-closed AES-GCM

#### P2–P3
- `TranslationIntelligence` koordinátor (memória + kontextus + minőség)
- `PremiumTranslationCard` opcionális javaslat / minőség-chippek
- `TranslationIntelligenceTest`

#### P4
- `PhrasebookStore` + `PhrasebookActivity` SpacedRepetition (SM-2) ismétlés
- ReviewCoach változatlanul elérhető

#### P5–P7
- `MeetingWorkflow` (összefoglaló + minőség + tanulási jelöltek, nem auto-save)
- `LiveTranslationHints`
- `TranscriptDetailActivity` összefoglaló minőségpontszám
- `MeetingWorkflowTest`

#### P8–P9 (specifikáció, nem éles)
- `capture/CaptureContracts` – camera/document **UNAVAILABLE**
- `sync/SyncContract` – **NoOp**, nem bekapcsolható

#### P10 (részben)
- `AccessibilityKit` + Diagnosztika checklist
- PremiumMotion reduceMotion, OLED, design tokenek (meglévő + bővítés)

### Blokkoló kapuk a stable / RC előtt

1. `./gradlew :core:test` és `:app:testDebugUnitTest` – minden PASS
2. `./gradlew :app:assembleDebug :wear:assembleDebug`
3. Legalább egy valós eszköz: telepítés, frissítés 4.2.x-ről, offline mód
4. Keystore hiba szimuláció: memória nem veszik el; API-kulcs nem kerül plaintextbe
5. Phrasebook ismétlés + ReviewCoach egy-egy ciklus
6. Meeting összefoglaló + SRT export egy mintafájlon
7. TalkBack / nagy betűméret / reduceMotion smoke
8. Aláírt release saját keystore-ral (vagy tudatos unsigned belső build)
9. P8/P9 **nem** kerülhet „kész” státuszba READY nélkül

### Kiadási osztályozás

**FORRÁSSZINTŰ MÉRNÖKI CSOMAG – NEM STABLE RELEASE, NEM RC**

A csomag a 6.0 terv P0–P7 forrásszintű megvalósítását, P8/P9 biztonságos vázát és P10 a11y alapot tartalmazza. Production kiadás csak a fenti blokkoló kapuk után.
